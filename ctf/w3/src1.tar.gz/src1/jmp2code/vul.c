#include <stdio.h>
#include <string.h>

int main() {
  char buf[100];
  gets(buf);
  puts(buf);
}
