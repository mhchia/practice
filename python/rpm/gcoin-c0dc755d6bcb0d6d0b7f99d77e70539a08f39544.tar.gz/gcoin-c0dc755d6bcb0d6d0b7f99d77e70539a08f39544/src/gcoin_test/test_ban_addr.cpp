// Copyright (c) 2015 The gCoin developers
// Distributed under the MIT/X11 software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.i

#include <boost/test/unit_test.hpp>

#include <stdint.h>

#include <map>
#include <string>

#include "core.h"
#include "init.h"
#include "main.h"
#include "rpcserver.h"
#include "script.h"
#include "wallet.h"


namespace
{

type_transaction_handler::HandlerInterface *handler;


/*!
 * Stores some transactions for unit test.
 */
std::map<uint256, CMutableTransaction> transactions;


/*!
 * @brief An alternate function for `GetTransaction()` in the file main.cpp
 */
bool GetTransaction(
        const uint256 &tx_hash, CTransaction &result,
        uint256 &block_hash, const CBlock *block, bool allow_slow)
{
    std::map<uint256, CMutableTransaction>::iterator it
            = transactions.find(tx_hash);
    if (it == transactions.end()) {
        return false;
    }
    result = CTransaction(it->second);
    return true;
}

bool GetCoinsFromCache(const COutPoint &outpoint,
                       CCoins &coins,
                       bool fUseMempool)
{
    std::map<uint256, CMutableTransaction>::iterator it
            = transactions.find(outpoint.hash);
    if (it == transactions.end()) {
        return false;
    }

    coins = CCoins(CTransaction(it->second), 1);
    return true;
}

/*!
 * @brief Creates an transaction for unit test.
 * @param [in] tx_hash The hash value of the transaction to be created.
 * @param [in] type The type of the transaction.
 * @param [in] color The color of the transaction.
 */
void CreateTransaction(
        const uint256 &tx_hash, const tx_type &type, const type_Color &color)
{
    CMutableTransaction tx;
    tx.type = type;
    tx.color = color;
    transactions[tx_hash] = tx;
}


/*!
 * @brief Connects two transactions for unit test.
 * @param [in] src_hash The hash value of the source transaction.
 * @param [in] dst_hash The hash value of the destination transaction.
 * @param [in] value Amount of coins to transform.
 * @param [in] address The destination address.
 */
void ConnectTransactions(const uint256 &src_hash,
                         const uint256 &dst_hash,
                         int64_t value,
                         const std::string &address)
{
    CScript address_script;
    address_script.SetDestination(CBitcoinAddress(address).Get());

    size_t index = transactions[src_hash].vout.size();

    transactions[src_hash].vout.push_back(CTxOut(value, address_script));
    transactions[dst_hash].vin.push_back(CTxIn(COutPoint(src_hash, index)));
}


/*!
 * @brief Creates a valid bitcoin address.
 */
std::string CreateAddress()
{
    return CBitcoinAddress(CWallet().GenerateNewKey().GetID()).ToString();
}


/*!
 * @brief Creates a valid bitcoin transaction destination.
 */
CTxDestination CreateDestination()
{
    return CBitcoinAddress(CWallet().GenerateNewKey().GetID()).Get();
}


/*!
 * @brief Cleans up and setups the environment.
 */
struct BanAddrSuiteFixture
{
    BanAddrSuiteFixture()
    {
        color_license::RemoveAll();
        ban_address::RemoveAll();
        alliance_member::RemoveAll();
        AlternateFunc_GetTransaction = GetTransaction;
        AlternateFunc_GetCoinsFromCache = GetCoinsFromCache;

        handler = type_transaction_handler::GetHandler(BANADDR);

        transactions.clear();
    }

    ~BanAddrSuiteFixture()
    {
        color_license::RemoveAll();
        ban_address::RemoveAll();
        alliance_member::RemoveAll();
        AlternateFunc_GetTransaction = NULL;
        AlternateFunc_GetCoinsFromCache = NULL;
    }
};

} // namespace

BOOST_FIXTURE_TEST_SUITE(BanAddr, BanAddrSuiteFixture)

BOOST_AUTO_TEST_CASE(Module)
{
    std::string addr1 = CreateAddress();
    std::string addr2 = CreateAddress();
    BOOST_CHECK(ban_address::IsBanned(addr1) == false);
    ban_address::Add(addr1);
    BOOST_CHECK(ban_address::IsBanned(addr1));
    ban_address::Remove(addr1);
    BOOST_CHECK(ban_address::IsBanned(addr1) == false);
    ban_address::Add(addr1);
    ban_address::Add(addr2);
    BOOST_CHECK(ban_address::IsBanned(addr1));
    BOOST_CHECK(ban_address::IsBanned(addr2));
    ban_address::Remove(addr1);
    BOOST_CHECK(ban_address::IsBanned(addr1) == false);
    BOOST_CHECK(ban_address::IsBanned(addr2));
    ban_address::RemoveAll();
    BOOST_CHECK(ban_address::IsBanned(addr2) == false);
}


BOOST_AUTO_TEST_CASE(GeneralCheckValid)
{
    std::string addr1 = CreateAddress();
    std::string addr2 = CreateAddress();
    std::string addr3 = CreateAddress();
    CreateTransaction(1, NORMAL, 5);
    CreateTransaction(2, NORMAL, 5);
    CreateTransaction(3, NORMAL, 5);
    CreateTransaction(4, NORMAL, 5);
    ConnectTransactions(1, 2, 1, addr1);
    ConnectTransactions(2, 3, 1, addr2);
    ConnectTransactions(3, 4, 1, addr3);

    CValidationState state_output, state_input;

    BOOST_CHECK(type_transaction_handler::GeneralCheckValid(
                CTransaction(transactions[2]), state_output, NULL) == true);
    BOOST_CHECK(type_transaction_handler::GeneralCheckValid(
                CTransaction(transactions[3]), state_input, NULL) == true);


    ban_address::Add(addr2);

    bool ret_output_banned = type_transaction_handler::GeneralCheckValid(
            CTransaction(transactions[2]), state_output, NULL);
    bool ret_input_banned = type_transaction_handler::GeneralCheckValid(
            CTransaction(transactions[3]), state_input, NULL);
// check the ban score
    int n_dos;
    BOOST_CHECK(ret_output_banned == false && state_output.IsInvalid(n_dos) && n_dos == 10);
    BOOST_CHECK(ret_input_banned == false && state_input.IsInvalid(n_dos) && n_dos == 50);
}


struct HandlerCheckValidFixture : public BanAddrSuiteFixture
{
    HandlerCheckValidFixture()
    {
        in_hash = 1;
        my_hash = 2;
        out_hash = 3;

        sender = CreateAddress();
        receiver = CreateAddress();

        alliance_member::Add(sender);

        CreateTransaction(in_hash, MINT, 0);
        CreateTransaction(my_hash, BANADDR, 0);
        CreateTransaction(out_hash, NORMAL, 0);
        ConnectTransactions(in_hash, my_hash, COIN, sender);
        ConnectTransactions(my_hash, out_hash, COIN, receiver);

    }

    ~HandlerCheckValidFixture()
    {
        transactions.clear();
    }

    void CheckFalse(int ndos, const std::string &msg)
    {
        CValidationState state;
        bool ret;
        int v;

        ret = handler->CheckValid(
                CTransaction(transactions[my_hash]), state, NULL);
        ret &= handler->CheckFormat(
                CTransaction(transactions[my_hash]), state, NULL);
        BOOST_CHECK_MESSAGE(
                ret == false && state.IsInvalid(v) && v == ndos, msg);
    }

    uint256 in_hash, my_hash, out_hash;
    std::string sender, receiver;

    CValidationState state;
};


BOOST_FIXTURE_TEST_CASE(HandlerCheckValidPass, HandlerCheckValidFixture)
{
    BOOST_CHECK(handler->CheckValid(
                CTransaction(transactions[my_hash]), state, NULL) == true);
}


BOOST_FIXTURE_TEST_CASE(HandlerCheckValidSenderNotAE, HandlerCheckValidFixture)
{
    alliance_member::Remove(sender);
    CheckFalse(100, __func__);
}


BOOST_FIXTURE_TEST_CASE(HandlerCheckValidBanned, HandlerCheckValidFixture)
{
    ban_address::Add(receiver);
    // check the ban score
    CheckFalse(50, __func__);
}


BOOST_FIXTURE_TEST_CASE(HandlerCheckValidBadInput, HandlerCheckValidFixture)
{
    transactions[in_hash].type = NORMAL;
    CheckFalse(100, __func__);

    transactions[in_hash].type = MINT;
    transactions[in_hash].color = 987;
    CheckFalse(100, __func__);
}


BOOST_FIXTURE_TEST_CASE(HandlerCheckValidBadOutput, HandlerCheckValidFixture)
{
    transactions[my_hash].vout[0].nValue += 1;
    CheckFalse(100, __func__);

    CreateTransaction(987, NORMAL, 5);
    ConnectTransactions(my_hash, 987, COIN, CreateAddress());
    CheckFalse(100, __func__);
}


BOOST_AUTO_TEST_CASE(HandlerApply)
{
    CreateTransaction(1, MINT, 0);
    CreateTransaction(2, BANADDR, 0);
    CreateTransaction(3, NORMAL, 0);
    std::string alliance = CreateAddress();
    std::string receiver = CreateAddress();
    ConnectTransactions(1, 2, COIN, alliance);
    ConnectTransactions(2, 3, COIN, receiver);
    BOOST_CHECK(handler->Apply(NULL, CTransaction(transactions[2])) == true);
    BOOST_CHECK(ban_address::IsBanned(receiver));
}


BOOST_AUTO_TEST_CASE(HandlerUndo)
{
    CBlock tmp;
    std::string addr = CreateAddress();
    ban_address::Add(addr);

    CreateTransaction(1, BANADDR, 0);
    CreateTransaction(2, NORMAL, 0);
    ConnectTransactions(1, 2, COIN, addr);
    BOOST_CHECK(handler->Undo(CTransaction(transactions[1]), tmp) == true);
    BOOST_CHECK(ban_address::IsBanned(addr) == false);
}


BOOST_AUTO_TEST_CASE(HandlerCheckRepeated)
{
    CValidationState state;
    int ndos;
    std::string receiver1 = CreateAddress();
    std::string receiver2 = CreateAddress();
    CreateTransaction(1, BANADDR, 0);
    CreateTransaction(2, BANADDR, 0);
    CreateTransaction(3, BANADDR, 0);
    CreateTransaction(4, NORMAL, 0);
    CreateTransaction(5, NORMAL, 0);
    CreateTransaction(6, NORMAL, 0);
    ConnectTransactions(1, 4, COIN, receiver1);
    ConnectTransactions(2, 5, COIN, receiver1);
    ConnectTransactions(3, 6, COIN, receiver2);
    // check the ban score
    BOOST_CHECK(handler->CheckNotRepeated(
                CTransaction(transactions[1]),
                CTransaction(transactions[2]), state) == false &&
            state.IsInvalid(ndos) && ndos == 50);

    BOOST_CHECK(handler->CheckNotRepeated(
                CTransaction(transactions[1]),
                CTransaction(transactions[3]), state));
}


BOOST_AUTO_TEST_SUITE(TestSuite_CWallet)

/*!
 * @brief A class who inherits from CWallet and replaces some methods for test.
 */
class UnitTest_Wallet : public CWallet
{
    public:
        UnitTest_Wallet(int64_t color0_amount) :
            color0_amount_(color0_amount) {}

        int64_t GetColor0Balance() const
        {
            return color0_amount_;
        }

        bool CreateTypeTransaction(
                CScript scriptPubKey, const type_Color send_color, int type,
                CWalletTx& wtxNew, std::string& strFailReason)
        {
            return (type == BANADDR);
        }

        bool CommitTransaction(CWalletTx& wtxNew, CReserveKey& reservekey)
        {
            return true;
        }

    private:
        int64_t color0_amount_;
};


/*!
 * @brief Tests whether the behavior of the function CWallet::BanAddress is good.
 */
BOOST_AUTO_TEST_CASE(TestCase_CWalletBanAddress)
{
    CWalletTx result_tx;
    UnitTest_Wallet test_wallet(COIN + 1);
    std::string err_msg = test_wallet.BanAddress(
            CreateDestination(), result_tx);
    BOOST_CHECK_MESSAGE(err_msg == "", err_msg);
}


/*!
 * @brief Tests whether the behavior of the function CWallet::BanAddress is good.
 */
BOOST_AUTO_TEST_CASE(TestCase_CWalletBanAddress_VoteNotEnough)
{
    CWalletTx result_tx;
    UnitTest_Wallet test_wallet(0);
    std::string err_msg = test_wallet.BanAddress(
            CreateDestination(), result_tx);
    BOOST_CHECK(err_msg != "");
}

BOOST_AUTO_TEST_SUITE_END();  // TestSuite_CWallet


BOOST_AUTO_TEST_SUITE(TestSuite_rpc_banaddr)


    /*!
     * @brief It stores the arugments gived to `BanAddress()` for future checking.
     */
    class UnitTest_CWallet : public CWallet
{
    public:
        UnitTest_CWallet(const mapValue_t &expected_map_values,
                const std::string &return_string) :
            expected_map_values_(expected_map_values),
            return_string_(return_string)
    {
    }

        std::string BanAddress(const CTxDestination &address, CWalletTx& wtxNew)
        {
            address_ = address;

            map_values_equal_ = CheckMapValueExpected_(wtxNew.mapValue);

            return return_string_;
        }

        CTxDestination address() const
        {
            return address_;
        }

        bool map_values_equal() const
        {
            return map_values_equal_;
        }

    private:
        bool CheckMapValueExpected_(const mapValue_t &tx_map_value) {
            if (tx_map_value.size() != expected_map_values_.size()) {
                return false;
            }
            for (mapValue_t::const_iterator it2, it = tx_map_value.begin();
                    it != tx_map_value.end(); ++it) {
                it2 = expected_map_values_.find(it->first);
                if (it2 == expected_map_values_.end() ||
                        it2->second != it->second) {
                    return false;
                }
            }
            return true;
        }

        mapValue_t expected_map_values_;
        std::string return_string_;

        CTxDestination address_;
        bool map_values_equal_;
};


/*!
 * @brief Stores the original pwalletMain, pre-declares some variables.
 */
struct RPCBanAddressFixture
{
    RPCBanAddressFixture()
    {
        old_wallet = pwalletMain;
    }

    ~RPCBanAddressFixture()
    {
        pwalletMain = old_wallet;
    }

    mapValue_t expected_map_values;
    json_spirit::Array params;

    CWallet* old_wallet;
};


/*!
 * @brief Checks whether the rpc banaddress calls CWallet::BanAddress expectly.
 */
BOOST_FIXTURE_TEST_CASE(TestCase_rpc_banaddress, RPCBanAddressFixture)
{
    std::string address = CreateAddress();

    expected_map_values["comment"] = "hi";
    params.push_back(address);
    params.push_back("hi");
    UnitTest_CWallet *test_wallet = new UnitTest_CWallet(
            expected_map_values, "");
    pwalletMain = test_wallet;
    banaddress(params, false);
    BOOST_CHECK(CBitcoinAddress(address).Get() == test_wallet->address());
    BOOST_CHECK(test_wallet->map_values_equal());
    delete test_wallet;
}


/*!
 * @brief Checks whether the rpc banaddress will throw an exception expectly.
 */
BOOST_FIXTURE_TEST_CASE(TestCase_rpc_banaddress_err, RPCBanAddressFixture)
{
    std::string address = CreateAddress();
    std::string err_msg = "some error string";

    expected_map_values["comment"] = "hi";
    params.push_back(address);
    params.push_back("hi");
    UnitTest_CWallet *test_wallet = new UnitTest_CWallet(
            expected_map_values, err_msg);
    pwalletMain = test_wallet;
    bool throwed = false;
    try {
        banaddress(params, false);
    } catch (json_spirit::Object &e) {
        BOOST_CHECK(json_spirit::find_value(e, "message").get_str() == err_msg);
        throwed = true;
    }
    BOOST_CHECK(throwed);
    delete test_wallet;
}

BOOST_AUTO_TEST_SUITE_END();  // TestSuite_rpc_banaddress

BOOST_AUTO_TEST_SUITE_END();  // TestSuite_BanAddress
