// Copyright (c) 2015 The gCoin developers
// Distributed under the MIT/X11 software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.i

#include <boost/test/unit_test.hpp>

#include <stdint.h>

#include <map>
#include <string>

#include "core.h"
#include "init.h"
#include "main.h"
#include "rpcserver.h"
#include "script.h"
#include "wallet.h"


namespace
{

type_transaction_handler::HandlerInterface *handler;


/*!
 * Stores some transactions for unit test.
 */
std::map<uint256, CMutableTransaction> transactions;


/*!
 * @brief An alternate function for `GetTransaction()` in the file main.cpp
 */
bool GetTransaction(
        const uint256 &tx_hash, CTransaction &result,
        uint256 &block_hash, const CBlock *block, bool allow_slow)
{
    std::map<uint256, CMutableTransaction>::iterator it
        = transactions.find(tx_hash);
    if (it == transactions.end()) {
        return false;
    }
    result = CTransaction(it->second);
    return true;
}

bool GetCoinsFromCache(const COutPoint &outpoint,
                       CCoins &coins,
                       bool fUseMempool)
{
    std::map<uint256, CMutableTransaction>::iterator it
            = transactions.find(outpoint.hash);
    if (it == transactions.end()) {
        return false;
    }

    coins = CCoins(CTransaction(it->second), 1);
    return true;
}

/*!
 * @brief Creates an transaction for unit test.
 * @param [in] tx_hash The hash value of the transaction to be created.
 * @param [in] type The type of the transaction.
 * @param [in] color The color of the transaction.
 */
void CreateTransaction(
        const uint256 &tx_hash, const tx_type &type, const type_Color &color)
{
    CMutableTransaction tx;
    tx.type = type;
    tx.color = color;
    transactions[tx_hash] = tx;
}


/*!
 * @brief Connects two transactions for unit test.
 * @param [in] src_hash The hash value of the source transaction.
 * @param [in] dst_hash The hash value of the destination transaction.
 * @param [in] value Amount of coins to transform.
 * @param [in] address The destination address.
 */
void ConnectTransactions(const uint256 &src_hash,
        const uint256 &dst_hash,
        int64_t value,
        const std::string &address)
{
    CScript address_script;
    address_script.SetDestination(CBitcoinAddress(address).Get());

    size_t index = transactions[src_hash].vout.size();

    transactions[src_hash].vout.push_back(CTxOut(value, address_script));
    transactions[dst_hash].vin.push_back(CTxIn(COutPoint(src_hash, index)));
}


/*!
 * @brief Creates a valid bitcoin address.
 */
std::string CreateAddress()
{
    return CBitcoinAddress(CWallet().GenerateNewKey().GetID()).ToString();
}


/*!
 * @brief Creates a valid bitcoin transaction destination.
 */
CTxDestination CreateDestination()
{
    return CBitcoinAddress(CWallet().GenerateNewKey().GetID()).Get();
}


/*!
 * @brief Cleans up and setups the environment.
 */
struct ActListSuiteFixture
{
    ActListSuiteFixture()
    {
        color_license::RemoveAll();
        activate_address_with_color::RemoveAll();
        alliance_member::RemoveAll();
        AlternateFunc_GetTransaction = GetTransaction;
        AlternateFunc_GetCoinsFromCache = GetCoinsFromCache;

        handler = type_transaction_handler::GetHandler(NORMAL);

        transactions.clear();
    }

    ~ActListSuiteFixture()
    {
        color_license::RemoveAll();
        activate_address_with_color::RemoveAll();
        alliance_member::RemoveAll();
        AlternateFunc_GetTransaction = NULL;
        AlternateFunc_GetCoinsFromCache = NULL;
    }
};

} // namespace

BOOST_FIXTURE_TEST_SUITE(ActList, ActListSuiteFixture)

BOOST_AUTO_TEST_CASE(Module)
{
    std::string addr1 = CreateAddress();
    std::string addr2 = CreateAddress();
    std::string addr3 = CreateAddress();
    type_Color color1 = 5;
    type_Color color2 = 6;
    BOOST_CHECK(activate_address_with_color::IsActivated(addr1, color1) == false);
    activate_address_with_color::Activate(addr1, color1);
    activate_address_with_color::Activate(addr2, color2);
    BOOST_CHECK(activate_address_with_color::IsActivated(addr1, color1));
    BOOST_CHECK(activate_address_with_color::IsActivated(addr1, color2) == false);
    activate_address_with_color::Activate(addr1, color1);
    activate_address_with_color::Deactivate(addr1, color1);
    activate_address_with_color::Deactivate(addr2, color2);
    BOOST_CHECK(activate_address_with_color::IsActivated(addr1, color1));
    BOOST_CHECK(activate_address_with_color::IsActivated(addr2, color2) == false);
    activate_address_with_color::RemoveAll();
    BOOST_CHECK(activate_address_with_color::IsActivated(addr2, color2) == false);
}


struct HandlerCheckValidFixture : public ActListSuiteFixture
{
    HandlerCheckValidFixture()
    {
        in_hash = 1;
        member_hash = 3;
        out_hash = 4;

        color = 5;

        member = CreateAddress();
        receiver = CreateAddress();
        activate_address_with_color::Activate(receiver, color);
        color_license::SetOwner(color, CreateAddress());
        CreateTransaction(in_hash, MINT, color);
        CreateTransaction(member_hash, NORMAL, color);
        CreateTransaction(out_hash, NORMAL, color);
        ConnectTransactions(in_hash, member_hash, COIN, member);
        ConnectTransactions(member_hash, out_hash, COIN, receiver);

    }

    ~HandlerCheckValidFixture()
    {
        transactions.clear();
    }

    void CheckFalse(int ndos, const std::string &msg)
    {
        CValidationState state;
        bool ret;
        int v;

        ret = handler->CheckValid(
                CTransaction(transactions[member_hash]), state, NULL);
        ret &= handler->CheckFormat(
                CTransaction(transactions[member_hash]), state, NULL);

        BOOST_CHECK_MESSAGE(
                ret == false && state.IsInvalid(v) && v == ndos, msg);
    }

    uint256 in_hash, member_hash, out_hash;
    std::string member, receiver;
    type_Color color;
    CValidationState state;
};


BOOST_FIXTURE_TEST_CASE(HandlerCheckValidPass, HandlerCheckValidFixture)
{
    BOOST_CHECK(handler->CheckValid(
                CTransaction(transactions[member_hash]), state, NULL) == true);
}


BOOST_FIXTURE_TEST_CASE(HandlerCheckValidInactivatedMember, HandlerCheckValidFixture)
{
    activate_address_with_color::Deactivate(receiver, color);
    CheckFalse(10, __func__);
}


BOOST_FIXTURE_TEST_CASE(HandlerCheckValidInactivatedColor, HandlerCheckValidFixture)
{
    activate_address_with_color::RemoveColor(color);
    CheckFalse(100, __func__);
}


BOOST_AUTO_TEST_CASE(HandlerApply)
{
    type_Color color = 5;
    std::string issuer = CreateAddress();
    std::string member = CreateAddress();
    CreateTransaction(1, MINT, color);
    CreateTransaction(2, NORMAL, color);
    CreateTransaction(3, NORMAL, color);
    ConnectTransactions(1, 2, COIN, issuer);
    ConnectTransactions(2, 3, COIN, member);
    BOOST_CHECK(handler->Apply(NULL, CTransaction(transactions[2])) == false);
    BOOST_CHECK(activate_address_with_color::IsActivated(member, color) == false);

    color_license::SetOwner(color, issuer);
    BOOST_CHECK(handler->Apply(NULL, CTransaction(transactions[2])));
    BOOST_CHECK(activate_address_with_color::IsActivated(member, color));
}


BOOST_AUTO_TEST_CASE(HandlerUndo)
{
    CBlock tmp;
    std::string issuer = CreateAddress();
    std::string member = CreateAddress();
    type_Color color = 5;
    color_license::SetOwner(color, issuer);
    activate_address_with_color::Activate(member, color);
    activate_address_with_color::Activate(member, color);

    CreateTransaction(1, MINT, color);
    CreateTransaction(2, NORMAL, color);
    CreateTransaction(3, NORMAL, color);
    ConnectTransactions(1, 2, COIN, issuer);
    ConnectTransactions(2, 3, COIN, member);
    BOOST_CHECK(handler->Undo(CTransaction(transactions[2]), tmp) == true);
    BOOST_CHECK(activate_address_with_color::IsActivated(member, color));
    BOOST_CHECK(handler->Undo(CTransaction(transactions[2]), tmp) == true);
    BOOST_CHECK(activate_address_with_color::IsActivated(member, color) == false);
}

BOOST_AUTO_TEST_SUITE_END();
