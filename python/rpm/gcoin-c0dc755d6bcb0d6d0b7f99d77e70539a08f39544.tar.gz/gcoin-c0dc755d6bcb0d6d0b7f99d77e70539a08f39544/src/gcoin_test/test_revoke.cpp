// Copyright (c) 2015 The gCoin developers
// Distributed under the MIT/X11 software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.i

#include <boost/test/unit_test.hpp>

#include <stdint.h>

#include <map>
#include <string>

#include "core.h"
#include "init.h"
#include "main.h"
#include "rpcserver.h"
#include "script.h"
#include "wallet.h"

using namespace std;
namespace
{

type_transaction_handler::HandlerInterface *handler;


/*!
 * Stores some transactions for unit test.
 */
std::map<uint256, CMutableTransaction> transactions;


/*!
 * @brief An alternate function for `GetTransaction()` in the file main.cpp
 */
bool GetTransaction(
        const uint256 &tx_hash, CTransaction &result,
        uint256 &block_hash, const CBlock *block, bool allow_slow)
{
    std::map<uint256, CMutableTransaction>::iterator it
        = transactions.find(tx_hash);
    if (it == transactions.end()) {
        return false;
    }
    result = CTransaction(it->second);
    return true;
}

bool GetCoinsFromCache(const COutPoint &outpoint,
                       CCoins &coins,
                       bool fUseMempool)
{
    std::map<uint256, CMutableTransaction>::iterator it
            = transactions.find(outpoint.hash);
    if (it == transactions.end()) {
        return false;
    }

    coins = CCoins(CTransaction(it->second), 1);
    return true;
}

/*!
 * @brief Creates an transaction for unit test.
 * @param [in] tx_hash The hash value of the transaction to be created.
 * @param [in] type The type of the transaction.
 * @param [in] color The color of the transaction.
 */
void CreateTransaction(
        const uint256 &tx_hash, const tx_type &type, const type_Color &color)
{
    CMutableTransaction tx;
    tx.type = type;
    tx.color = color;
    transactions[tx_hash] = tx;
}


/*!
 * @brief Connects two transactions for unit test.
 * @param [in] src_hash The hash value of the source transaction.
 * @param [in] dst_hash The hash value of the destination transaction.
 * @param [in] value Amount of coins to transform.
 * @param [in] address The destination address.
 */
void ConnectTransactions(const uint256 &src_hash,
        const uint256 &dst_hash,
        int64_t value,
        const std::string &address)
{
    CScript address_script;
    address_script.SetDestination(CBitcoinAddress(address).Get());

    size_t index = transactions[src_hash].vout.size();

    transactions[src_hash].vout.push_back(CTxOut(value, address_script));
    transactions[dst_hash].vin.push_back(CTxIn(COutPoint(src_hash, index)));
}


/*!
 * @brief Creates a valid bitcoin address.
 */
std::string CreateAddress()
{
    return CBitcoinAddress(CWallet().GenerateNewKey().GetID()).ToString();
}


/*!
 * @brief Apply a transaction.
 */
bool Apply(CTransaction tx)
{
    return type_transaction_handler::GetHandler(tx.type)->Apply(NULL, tx);
}


/*!
 * @brief Undo a transaction.
 */
bool Undo(CTransaction tx)
{
    CBlock tmp;
    return type_transaction_handler::GetHandler(tx.type)->Undo(tx, tmp);
}

/*!
 * @brief Cleans up and setups the environment.
 */
struct RevokeSuiteFixture
{
    RevokeSuiteFixture()
    {
        color_license::RemoveAll();
        alliance_member::RemoveAll();
        AlternateFunc_GetTransaction = GetTransaction;
        AlternateFunc_GetCoinsFromCache = GetCoinsFromCache;

        handler = type_transaction_handler::GetHandler(REVOKELICENSE);

        transactions.clear();
    }

    ~RevokeSuiteFixture()
    {
        color_license::RemoveAll();
        activate_address_with_color::RemoveAll();
        alliance_member::RemoveAll();
        AlternateFunc_GetTransaction = NULL;
        AlternateFunc_GetCoinsFromCache = NULL;
    }
};

} // namespace

BOOST_FIXTURE_TEST_SUITE(RevokeLicense, RevokeSuiteFixture)

struct HandlerCheckValidFixture : public RevokeSuiteFixture
{
    HandlerCheckValidFixture()
    {
        in_hash = 1;
        my_hash = 2;
        out_hash = 3;
        color = 5;

        sender = CreateAddress();
        receiver = CreateAddress();

        alliance_member::Add(sender);
        color_license::SetOwner(color, receiver);

        CreateTransaction(in_hash, MINT, 0);
        CreateTransaction(my_hash, REVOKELICENSE, color);
        CreateTransaction(out_hash, NORMAL, color);
        ConnectTransactions(in_hash, my_hash, COIN, sender);
        ConnectTransactions(my_hash, out_hash, COIN, receiver);

    }

    ~HandlerCheckValidFixture()
    {
        transactions.clear();
    }

    void CheckFalse(int ndos, const std::string &msg)
    {
        CValidationState state;
        bool ret;
        int v;

        ret = handler->CheckValid(
                CTransaction(transactions[my_hash]), state, NULL);
        ret &= handler->CheckFormat(
                CTransaction(transactions[my_hash]), state, NULL);

        BOOST_CHECK_MESSAGE(
                ret == false && state.IsInvalid(v) && v == ndos, msg);
    }

    uint256 in_hash, my_hash, out_hash;
    std::string sender, receiver;
    type_Color color;
    CValidationState state;
};


BOOST_FIXTURE_TEST_CASE(HandlerCheckValidPass, HandlerCheckValidFixture)
{
    BOOST_CHECK(handler->CheckValid(
                CTransaction(transactions[my_hash]), state, NULL) == true);
}

BOOST_FIXTURE_TEST_CASE(HandlerCheckValidBadValue, HandlerCheckValidFixture)
{
    transactions[my_hash].vout[0].nValue += 1;
    CheckFalse(100, __func__);
}

BOOST_FIXTURE_TEST_CASE(HandlerCheckValidBadOutput, HandlerCheckValidFixture)
{
    CreateTransaction(987, NORMAL, color);
    ConnectTransactions(my_hash, 987, COIN, CreateAddress());
    CheckFalse(100, __func__);
}

BOOST_AUTO_TEST_CASE(HandlerApply)
{
    type_Color color = 5;
    std::string issuer = CreateAddress();

    CreateTransaction(1, REVOKELICENSE, color);

    color_license::SetOwner(color, issuer);
    BOOST_CHECK(color_license::IsOwner(color, issuer));

    BOOST_CHECK(Apply(CTransaction(transactions[1])));
    BOOST_CHECK(color_license::HasOwner(color) == false);
    BOOST_CHECK(color_license::IsExist(color));

}


BOOST_AUTO_TEST_CASE(HandlerUndo)
{
    std::string issuer = CreateAddress();
    type_Color color = 5;
    color_license::SetOwner(color, issuer);

    CreateTransaction(1, MINT, 0);
    CreateTransaction(2, REVOKELICENSE, color);
    CreateTransaction(3, NORMAL, color);
    ConnectTransactions(1, 2, COIN, issuer);
    ConnectTransactions(2, 3, COIN, issuer);
    BOOST_CHECK(Apply(CTransaction(transactions[2])));
    BOOST_CHECK(Undo(CTransaction(transactions[2])));
    BOOST_CHECK(color_license::IsOwner(color, issuer));
}

BOOST_AUTO_TEST_CASE(LicenseCount)
{
    CBlock tmp;
    std::string issuer = CreateAddress();
    std::string issuer2 = CreateAddress();
    type_Color color = 5;

    CreateTransaction(1, MINT, 0);
    CreateTransaction(2, LICENSE, color);
    CreateTransaction(3, LICENSE, color);
    CreateTransaction(4, MINT, 0);
    CreateTransaction(5, REVOKELICENSE, color);
    CreateTransaction(6, NORMAL, color);
    ConnectTransactions(1, 2, COIN, issuer);
    ConnectTransactions(2, 3, COIN, issuer);
    ConnectTransactions(3, 6, COIN, issuer2);

    ConnectTransactions(4, 5, COIN, issuer);
    ConnectTransactions(5, 6, COIN, issuer);

    // Undo Send License First Time
    BOOST_CHECK(Apply(CTransaction(transactions[2]))); // count = 1
    BOOST_CHECK(color_license::IsOwner(color, issuer));
    BOOST_CHECK(Undo(CTransaction(transactions[2]))); // count = 0
    BOOST_CHECK(color_license::IsExist(color) == false);

    // Undo Send License After Revoke
    BOOST_CHECK(Apply(CTransaction(transactions[2]))); // count = 1
    BOOST_CHECK(Apply(CTransaction(transactions[4]))); 
    BOOST_CHECK(Apply(CTransaction(transactions[2]))); // count = 2
    BOOST_CHECK(Undo(CTransaction(transactions[2]))); // count = 1
    BOOST_CHECK(color_license::IsExist(color));

    // Case of License Transfer between Issuers
    BOOST_CHECK(Apply(CTransaction(transactions[3]))); // count = 2
    BOOST_CHECK(Undo(CTransaction(transactions[3]))); // count = 1
    BOOST_CHECK(color_license::IsExist(color));
    
    BOOST_CHECK(Undo(CTransaction(transactions[2]))); // count = 0
    BOOST_CHECK(color_license::IsExist(color) == false);

}

BOOST_AUTO_TEST_SUITE(TestSuite_CWallet)

/*!
 * @brief A class who inherits from CWallet and replaces some methods for test.
 */
class UnitTest_Wallet : public CWallet
{
public:
    UnitTest_Wallet(int64_t color0_amount, type_Color color_to_be_revoked) :
            color0_amount_(color0_amount),
            color_to_be_revoked_(color_to_be_revoked) {}

    int64_t GetColor0Balance() const
    {
        return color0_amount_;
    }

    bool CreateTypeTransaction(
            CScript scriptPubKey, const type_Color send_color, int type,
            CWalletTx& wtxNew, std::string& strFailReason)
    {
        return (type == REVOKELICENSE && send_color == color_to_be_revoked_);
    }

    bool CommitTransaction(CWalletTx& wtxNew, CReserveKey& reservekey)
    {
        return true;
    }

private:
    int64_t color0_amount_;
    type_Color color_to_be_revoked_;
};


/*!
 * @brief Tests whether the behavior of the function CWallet::RevokeLicense is good.
 */
BOOST_AUTO_TEST_CASE(TestCase_CWalletRevokeLicense)
{
    int color_to_be_revoked = 5;
    std::string issuer = CreateAddress();
    color_license::SetOwner(color_to_be_revoked, issuer);
    CWalletTx result_tx;
    UnitTest_Wallet test_wallet(COIN + 1, color_to_be_revoked);
    std::string err_msg = test_wallet.SendRevokeLicense(
            CBitcoinAddress(issuer).Get(), color_to_be_revoked, result_tx);
    BOOST_CHECK_MESSAGE(err_msg == "", err_msg);
}


/*!
 * @brief Tests whether the behavior of the function CWallet::RevokeLicense is good.
 */
BOOST_AUTO_TEST_CASE(TestCase_CWalletRevokeLicense_Color0NotEnought)
{
    int color_to_be_revoked = 5;
    std::string issuer = CreateAddress();
    color_license::SetOwner(color_to_be_revoked, issuer);
    CWalletTx result_tx;
    UnitTest_Wallet test_wallet(0, color_to_be_revoked);
    std::string err_msg = test_wallet.SendRevokeLicense(
            CBitcoinAddress(issuer).Get(), color_to_be_revoked, result_tx);
    BOOST_CHECK(err_msg != "");
}


BOOST_AUTO_TEST_SUITE_END();  // TestSuite_CWallet

BOOST_AUTO_TEST_SUITE(TestSuite_rpc_revoke_license)


/*!
 * @brief It stores the arugments gived to `SendRevokeLicense()` for future checking.
 */
class UnitTest_CWallet : public CWallet
{
public:
    UnitTest_CWallet(const mapValue_t &expected_map_values,
                     const std::string &return_string) :
            expected_map_values_(expected_map_values),
            return_string_(return_string)
    {
    }

    std::string SendRevokeLicense(const CTxDestination &address, const type_Color color,
                         CWalletTx& wtxNew)
    {
        address_ = address;
        color_ = color;

        map_values_equal_ = CheckMapValueExpected_(wtxNew.mapValue);

        return return_string_;
    }

    CTxDestination address() const
    {
        return address_;
    }

    type_Color color() const
    {
        return color_;
    }

    bool map_values_equal() const
    {
        return map_values_equal_;
    }

private:
    bool CheckMapValueExpected_(const mapValue_t &tx_map_value) {
        if (tx_map_value.size() != expected_map_values_.size()) {
            return false;
        }
        for (mapValue_t::const_iterator it2, it = tx_map_value.begin();
             it != tx_map_value.end(); ++it) {
            it2 = expected_map_values_.find(it->first);
            if (it2 == expected_map_values_.end() ||
                it2->second != it->second) {
                return false;
            }
        }
        return true;
    }

    mapValue_t expected_map_values_;
    std::string return_string_;

    CTxDestination address_;
    type_Color color_;
    bool map_values_equal_;
};


/*!
 * @brief Stores the original pwalletMain, pre-declares some variables.
 */
struct RPCRevokeFixture
{
    RPCRevokeFixture()
    {
        old_wallet = pwalletMain;
    }

    ~RPCRevokeFixture()
    {
        pwalletMain = old_wallet;
    }

    mapValue_t expected_map_values;
    json_spirit::Array params;

    CWallet* old_wallet;
};


/*!
 * @brief Checks whether the rpc revokelicenseofaddress calls CWallet::SendRevokeLicense expectly.
 */
BOOST_FIXTURE_TEST_CASE(TestCase_rpc_revoke, RPCRevokeFixture)
{
    type_Color color_to_be_revoked(5);
    std::string address = CreateAddress();

    expected_map_values["comment"] = "hi";
    params.push_back(address);
    params.push_back(static_cast<int>(color_to_be_revoked));
    params.push_back("hi");
    UnitTest_CWallet *test_wallet = new UnitTest_CWallet(
            expected_map_values, "");
    pwalletMain = test_wallet;
    revokelicenseofaddress(params, false);
    BOOST_CHECK(test_wallet->color() == color_to_be_revoked);
    BOOST_CHECK(CBitcoinAddress(address).Get() == test_wallet->address());
    BOOST_CHECK(test_wallet->map_values_equal());
    delete test_wallet;
}


/*!
 * @brief Checks whether the rpc revokelicenseofaddress will throw an exception expectly.
 */
BOOST_FIXTURE_TEST_CASE(TestCase_rpc_revoke_err, RPCRevokeFixture)
{
    type_Color color_to_be_revoked(5);
    std::string address = CreateAddress();
    std::string err_msg = "some error string";

    expected_map_values["comment"] = "hi";
    params.push_back(address);
    params.push_back(static_cast<int>(color_to_be_revoked));
    params.push_back("hi");
    UnitTest_CWallet *test_wallet = new UnitTest_CWallet(
            expected_map_values, err_msg);
    pwalletMain = test_wallet;
    bool throwed = false;
    try {
        revokelicenseofaddress(params, false);
    } catch (json_spirit::Object &e) {
        BOOST_CHECK(json_spirit::find_value(e, "message").get_str() == err_msg);
        throwed = true;
    }
    BOOST_CHECK(throwed);
    delete test_wallet;
}

BOOST_AUTO_TEST_SUITE_END();  // TestSuite_rpc_revoke

BOOST_AUTO_TEST_SUITE_END();  // TestSuite_RevokeLicense
