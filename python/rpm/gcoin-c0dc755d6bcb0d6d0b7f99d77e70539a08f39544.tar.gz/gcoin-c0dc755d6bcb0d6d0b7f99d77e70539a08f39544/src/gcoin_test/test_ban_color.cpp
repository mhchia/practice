// Copyright (c) 2015 The gCoin developers
// Distributed under the MIT/X11 software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#include <boost/test/unit_test.hpp>

#include <stdint.h>

#include <map>
#include <string>

#include "core.h"
#include "init.h"
#include "main.h"
#include "rpcserver.h"
#include "script.h"
#include "wallet.h"


namespace
{

type_transaction_handler::HandlerInterface *handler;


/*!
 * Stores some transactions for unit test.
 */
std::map<uint256, CMutableTransaction> transactions;


/*!
 * @brief An alternate function for `GetTransaction()` in the file main.cpp
 */
bool GetTransaction(
        const uint256 &tx_hash, CTransaction &result,
        uint256 &block_hash, const CBlock *block, bool allow_slow)
{
    std::map<uint256, CMutableTransaction>::iterator it
            = transactions.find(tx_hash);
    if (it == transactions.end()) {
        return false;
    }
    result = CTransaction(it->second);
    return true;
}

bool GetCoinsFromCache(const COutPoint &outpoint,
                       CCoins &coins,
                       bool fUseMempool)
{
    std::map<uint256, CMutableTransaction>::iterator it
            = transactions.find(outpoint.hash);
    if (it == transactions.end()) {
        return false;
    }

    coins = CCoins(CTransaction(it->second), 1);
    return true;
}

/*!
 * @brief Creates an transaction for unit test.
 * @param [in] tx_hash The hash value of the transaction to be created.
 * @param [in] type The type of the transaction.
 * @param [in] color The color of the transaction.
 */
void CreateTransaction(
        const uint256 &tx_hash, const tx_type &type, const type_Color &color)
{
    CMutableTransaction tx;
    tx.type = type;
    tx.color = color;
    transactions[tx_hash] = tx;
}


/*!
 * @brief Connects two transactions for unit test.
 * @param [in] src_hash The hash value of the source transaction.
 * @param [in] dst_hash The hash value of the destination transaction.
 * @param [in] value Amount of coins to transform.
 * @param [in] address The destination address.
 */
void ConnectTransactions(const uint256 &src_hash,
                         const uint256 &dst_hash,
                         int64_t value,
                         const std::string &address)
{
    CScript address_script;
    address_script.SetDestination(CBitcoinAddress(address).Get());

    size_t index = transactions[src_hash].vout.size();

    transactions[src_hash].vout.push_back(CTxOut(value, address_script));
    transactions[dst_hash].vin.push_back(CTxIn(COutPoint(src_hash, index)));
}


/*!
 * @brief Creates a valid bitcoin address.
 */
std::string CreateAddress()
{
    return CBitcoinAddress(CWallet().GenerateNewKey().GetID()).ToString();
}


/*!
 * @brief Creates a valid bitcoin transaction destination.
 */
CTxDestination CreateDestination()
{
    return CBitcoinAddress(CWallet().GenerateNewKey().GetID()).Get();
}


/*!
 * @brief Cleans up and setups the environment.
 */
struct BanColorSuiteFixture
{
    BanColorSuiteFixture()
    {
        color_license::RemoveAll();
        ban_color::RemoveAll();
        alliance_member::RemoveAll();
        AlternateFunc_GetTransaction = GetTransaction;
        AlternateFunc_GetCoinsFromCache = GetCoinsFromCache;

        handler = type_transaction_handler::GetHandler(BANCOLOR);

        transactions.clear();
    }

    ~BanColorSuiteFixture()
    {
        color_license::RemoveAll();
        ban_color::RemoveAll();
        alliance_member::RemoveAll();
        AlternateFunc_GetTransaction = NULL;
        AlternateFunc_GetCoinsFromCache = NULL;
    }
};

}  // namespace


BOOST_FIXTURE_TEST_SUITE(BanColor, BanColorSuiteFixture)

BOOST_AUTO_TEST_CASE(Module)
{
    BOOST_CHECK(ban_color::IsBanned(3) == false);
    ban_color::Add(3);
    BOOST_CHECK(ban_color::IsBanned(3));
    ban_color::Remove(3);
    BOOST_CHECK(ban_color::IsBanned(3) == false);
    ban_color::Add(3);
    ban_color::Add(4);
    BOOST_CHECK(ban_color::IsBanned(3));
    BOOST_CHECK(ban_color::IsBanned(4));
    ban_color::Remove(3);
    BOOST_CHECK(ban_color::IsBanned(3) == false);
    BOOST_CHECK(ban_color::IsBanned(4));
    ban_color::RemoveAll();
    BOOST_CHECK(ban_color::IsBanned(4) == false);
}


BOOST_AUTO_TEST_CASE(GeneralCheckValid)
{
    CreateTransaction(1, NORMAL, 5);
    CreateTransaction(2, NORMAL, 5);
    CreateTransaction(3, NORMAL, 5);
    ConnectTransactions(1, 2, 1, CreateAddress());
    ConnectTransactions(2, 3, 1, CreateAddress());

    CValidationState state;

    BOOST_CHECK(type_transaction_handler::GeneralCheckValid(
            CTransaction(transactions[2]), state, NULL) == true);

    ban_color::Add(5);
    bool ret = type_transaction_handler::GeneralCheckValid(
            CTransaction(transactions[2]), state, NULL);

    int n_dos;
    BOOST_CHECK(ret == false && state.IsInvalid(n_dos) && n_dos == 10);
}


struct HandlerCheckValidFixture : public BanColorSuiteFixture
{
    HandlerCheckValidFixture()
    {
        in_hash = 1;
        my_hash = 2;
        out_hash = 3;
        color = 5;

        sender = CreateAddress();
        receiver = CreateAddress();

        alliance_member::Add(sender);
        color_license::SetOwner(color, receiver);

        CreateTransaction(in_hash, MINT, 0);
        CreateTransaction(my_hash, BANCOLOR, color);
        CreateTransaction(out_hash, NORMAL, 0);
        ConnectTransactions(in_hash, my_hash, COIN, sender);
        ConnectTransactions(my_hash, out_hash, COIN, receiver);
    }

    ~HandlerCheckValidFixture()
    {
        transactions.clear();
    }

    void CheckFalse(int ndos, const std::string &msg)
    {
        CValidationState state;
        bool ret;
        int v;

        ret = handler->CheckValid(
                CTransaction(transactions[my_hash]), state, NULL);
        ret &= handler->CheckFormat(
                CTransaction(transactions[my_hash]), state, NULL);

        BOOST_CHECK_MESSAGE(
                ret == false && state.IsInvalid(v) && v == ndos, msg);
    }

    uint256 in_hash, my_hash, out_hash;
    type_Color color;
    std::string sender, receiver;

    CValidationState state;
};


BOOST_FIXTURE_TEST_CASE(HandlerCheckValidPass, HandlerCheckValidFixture)
{
    BOOST_CHECK(handler->CheckValid(
            CTransaction(transactions[my_hash]), state, NULL) == true);
}


BOOST_FIXTURE_TEST_CASE(HandlerCheckValidSenderNotAE, HandlerCheckValidFixture)
{
    alliance_member::Remove(sender);
    CheckFalse(100, __func__);
}


BOOST_FIXTURE_TEST_CASE(HandlerCheckValidReceiverNotOwner,
                        HandlerCheckValidFixture)
{
    color_license::SetOwner(color, "alaaaaaa");
    CheckFalse(100, __func__);

    color_license::Remove(color);
    CheckFalse(100, __func__);
}


BOOST_FIXTURE_TEST_CASE(HandlerCheckValidBanned, HandlerCheckValidFixture)
{
    ban_color::Add(color);
    CheckFalse(100, __func__);
}


BOOST_FIXTURE_TEST_CASE(HandlerCheckValidBadInput, HandlerCheckValidFixture)
{
    transactions[in_hash].type = NORMAL;
    CheckFalse(100, __func__);

    transactions[in_hash].type = MINT;
    transactions[in_hash].color = 987;
    CheckFalse(100, __func__);
}


BOOST_FIXTURE_TEST_CASE(HandlerCheckValidBadOutput, HandlerCheckValidFixture)
{
    transactions[my_hash].vout[0].nValue += 1;
    CheckFalse(100, __func__);

    CreateTransaction(987, NORMAL, color);
    ConnectTransactions(my_hash, 987, COIN, CreateAddress());
    CheckFalse(100, __func__);
}


BOOST_AUTO_TEST_CASE(HandlerApply)
{
    CreateTransaction(1, BANCOLOR, 3);
    BOOST_CHECK(handler->Apply(NULL, CTransaction(transactions[1])) == false);
    BOOST_CHECK(ban_color::IsBanned(3) == false);

    color_license::SetOwner(3, "wa lala");
    BOOST_CHECK(handler->Apply(NULL, CTransaction(transactions[1])) == true);
    BOOST_CHECK(ban_color::IsBanned(3));
}


BOOST_AUTO_TEST_CASE(HandlerUndo)
{
    CBlock tmp;
    ban_color::Add(3);

    CreateTransaction(1, BANCOLOR, 3);
    BOOST_CHECK(handler->Undo(CTransaction(transactions[1]), tmp) == true);
    BOOST_CHECK(ban_color::IsBanned(3) == false);
}


BOOST_AUTO_TEST_CASE(HandlerCheckRepeated)
{
    CValidationState state;
    int ndos;

    CreateTransaction(1, BANCOLOR, 3);
    CreateTransaction(2, BANCOLOR, 3);
    CreateTransaction(3, BANCOLOR, 4);

    BOOST_CHECK(handler->CheckNotRepeated(
            CTransaction(transactions[1]),
            CTransaction(transactions[2]), state) == false &&
            state.IsInvalid(ndos) && ndos == 50);

    BOOST_CHECK(handler->CheckNotRepeated(
            CTransaction(transactions[1]),
            CTransaction(transactions[3]), state));
}


BOOST_AUTO_TEST_SUITE(TestSuite_CWallet)

/*!
 * @brief A class who inherits from CWallet and replaces some methods for test.
 */
class UnitTest_Wallet : public CWallet
{
public:
    UnitTest_Wallet(int64_t color0_amount, type_Color color_to_be_banned) :
            color0_amount_(color0_amount),
            color_to_be_banned_(color_to_be_banned) {}

    int64_t GetColor0Balance() const
    {
        return color0_amount_;
    }

    bool CreateTypeTransaction(
            CScript scriptPubKey, const type_Color send_color, int type,
            CWalletTx& wtxNew, std::string& strFailReason)
    {
        return (type == BANCOLOR && send_color == color_to_be_banned_);
    }

    bool CommitTransaction(CWalletTx& wtxNew, CReserveKey& reservekey)
    {
        return true;
    }

private:
    int64_t color0_amount_;
    type_Color color_to_be_banned_;
};


/*!
 * @brief Tests whether the behavior of the function CWallet::BanColor is good.
 */
BOOST_AUTO_TEST_CASE(TestCase_CWalletBanColor)
{
    int color_to_be_banned = 5;
    CWalletTx result_tx;
    UnitTest_Wallet test_wallet(COIN + 1, color_to_be_banned);
    std::string err_msg = test_wallet.BanColor(
            CreateDestination(), color_to_be_banned, result_tx);
    BOOST_CHECK_MESSAGE(err_msg == "", err_msg);
}


/*!
 * @brief Tests whether the behavior of the function CWallet::BanColor is good.
 */
BOOST_AUTO_TEST_CASE(TestCase_CWalletBanColor_VoteNotEnought)
{
    int color_to_be_banned = 5;
    CWalletTx result_tx;
    UnitTest_Wallet test_wallet(0, color_to_be_banned);
    std::string err_msg = test_wallet.BanColor(
            CreateDestination(), color_to_be_banned, result_tx);
    BOOST_CHECK(err_msg != "");
}

BOOST_AUTO_TEST_SUITE_END();  // TestSuite_CWallet


BOOST_AUTO_TEST_SUITE(TestSuite_rpc_bancolor)


/*!
 * @brief It stores the arugments gived to `BanColor()` for future checking.
 */
class UnitTest_CWallet : public CWallet
{
public:
    UnitTest_CWallet(const mapValue_t &expected_map_values,
                     const std::string &return_string) :
            expected_map_values_(expected_map_values),
            return_string_(return_string)
    {
    }

    std::string BanColor(const CTxDestination &address, const type_Color color,
                         CWalletTx& wtxNew)
    {
        address_ = address;
        color_ = color;

        map_values_equal_ = CheckMapValueExpected_(wtxNew.mapValue);

        return return_string_;
    }

    CTxDestination address() const
    {
        return address_;
    }

    type_Color color() const
    {
        return color_;
    }

    bool map_values_equal() const
    {
        return map_values_equal_;
    }

private:
    bool CheckMapValueExpected_(const mapValue_t &tx_map_value) {
        if (tx_map_value.size() != expected_map_values_.size()) {
            return false;
        }
        for (mapValue_t::const_iterator it2, it = tx_map_value.begin();
             it != tx_map_value.end(); ++it) {
            it2 = expected_map_values_.find(it->first);
            if (it2 == expected_map_values_.end() ||
                it2->second != it->second) {
                return false;
            }
        }
        return true;
    }

    mapValue_t expected_map_values_;
    std::string return_string_;

    CTxDestination address_;
    type_Color color_;
    bool map_values_equal_;
};


/*!
 * @brief Stores the original pwalletMain, pre-declares some variables.
 */
struct RPCBanColorFixture
{
    RPCBanColorFixture()
    {
        old_wallet = pwalletMain;
    }

    ~RPCBanColorFixture()
    {
        pwalletMain = old_wallet;
    }

    mapValue_t expected_map_values;
    json_spirit::Array params;

    CWallet* old_wallet;
};


/*!
 * @brief Checks whether the rpc bancolor calls CWallet::BanColor expectly.
 */
BOOST_FIXTURE_TEST_CASE(TestCase_rpc_bancolor, RPCBanColorFixture)
{
    type_Color color_to_be_banned(5);
    std::string address = CreateAddress();

    expected_map_values["comment"] = "hi";
    params.push_back(address);
    params.push_back(static_cast<int>(color_to_be_banned));
    params.push_back("hi");
    UnitTest_CWallet *test_wallet = new UnitTest_CWallet(
            expected_map_values, "");
    pwalletMain = test_wallet;
    bancolor(params, false);
    BOOST_CHECK(test_wallet->color() == color_to_be_banned);
    BOOST_CHECK(CBitcoinAddress(address).Get() == test_wallet->address());
    BOOST_CHECK(test_wallet->map_values_equal());
    delete test_wallet;
}


/*!
 * @brief Checks whether the rpc bancolor will throw an exception expectly.
 */
BOOST_FIXTURE_TEST_CASE(TestCase_rpc_bancolor_err, RPCBanColorFixture)
{
    type_Color color_to_be_banned(5);
    std::string address = CreateAddress();
    std::string err_msg = "some error string";

    expected_map_values["comment"] = "hi";
    params.push_back(address);
    params.push_back(static_cast<int>(color_to_be_banned));
    params.push_back("hi");
    UnitTest_CWallet *test_wallet = new UnitTest_CWallet(
            expected_map_values, err_msg);
    pwalletMain = test_wallet;
    bool throwed = false;
    try {
        bancolor(params, false);
    } catch (json_spirit::Object &e) {
        BOOST_CHECK(json_spirit::find_value(e, "message").get_str() == err_msg);
        throwed = true;
    }
    BOOST_CHECK(throwed);
    delete test_wallet;
}

BOOST_AUTO_TEST_SUITE_END();  // TestSuite_rpc_bancolor

BOOST_AUTO_TEST_SUITE_END();  // TestSuite_BanColor
