// Copyright (c) 2012-2014 The Bitcoin Core developers
// Distributed under the MIT/X11 software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.
#include "rpcserver.h"
#include "rpcclient.h"
#include "wallet.h"
#include "core_io.h"

#include <stdint.h>
#include <utility>

#include <boost/algorithm/string.hpp>
#include <boost/test/unit_test.hpp>

using namespace std;
using namespace json_spirit;


/*!
 * @brief Creates a valid bitcoin address.
 */
static string CreateAddress()
{
    return CBitcoinAddress(CWallet().GenerateNewKey().GetID()).ToString();
}


/*!
 * @brief Creates a valid bitcoin transaction destination.
 */
CTxDestination CreateDestination()
{
    return CBitcoinAddress(CWallet().GenerateNewKey().GetID()).Get();
}


static Value CallRPC(string args)
{
    vector<string> vArgs;
    boost::split(vArgs, args, boost::is_any_of(" \t"));
    string strMethod = vArgs[0];
    vArgs.erase(vArgs.begin());
    Array params = RPCConvertValues(strMethod, vArgs);

    rpcfn_type method = tableRPC[strMethod]->actor;
    try {
        Value result = (*method)(params, false);
        return result;
    }
    catch (Object& objError)
    {
        throw runtime_error(find_value(objError, "message").get_str());
    }
}

BOOST_AUTO_TEST_SUITE(txjson_tests)

BOOST_AUTO_TEST_CASE(rpc_createrawtransaction_tests)
{
    Value v;
    BOOST_CHECK_NO_THROW(v = CallRPC(string("createrawtransaction [{\"txid\":\"eb63d5d53cd906b5cf75a014e1bcf1c0198ae58d378d45dbfa15045ac89a38ac\",\"vout\":1}] {\"") + CreateAddress() + string("\":99999999999999999} 3")));

    string rawtx = v.get_str();
    CTransaction tx;
    BOOST_CHECK_NO_THROW(v = CallRPC(string("decoderawtransaction ")+rawtx));
    Array a = find_value(v.get_obj(), "vout").get_array();
    BOOST_CHECK_EQUAL(find_value(a[0].get_obj(), "value").get_int64(), 99999999999999999);

}

BOOST_AUTO_TEST_SUITE_END()
