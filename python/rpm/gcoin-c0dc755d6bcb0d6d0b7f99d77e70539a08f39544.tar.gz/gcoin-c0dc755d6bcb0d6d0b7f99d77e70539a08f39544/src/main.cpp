// Copyright (c) 2009-2010 Satoshi Nakamoto
// Copyright (c) 2009-2014 The Bitcoin developers
// Distributed under the MIT/X11 software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#include "main.h"
#include "base58.h"
#include "addrman.h"
#include "alert.h"
#include "chainparams.h"
#include "checkpoints.h"
#include "checkqueue.h"
#include "init.h"
#include "net.h"
#include "pow.h"
#include "txdb.h"
#include "txmempool.h"
#include "ui_interface.h"
#include "script.h"

#include <sstream>

#include <boost/algorithm/string/replace.hpp>
#include <boost/filesystem.hpp>
#include <boost/filesystem/fstream.hpp>
#include <boost/thread.hpp>
#include <vector>

#ifdef ENABLE_GCOIN
#include <boost/thread/tss.hpp>
#endif  // ENABLE_GCOIN


using std::list;
using std::make_pair;
using std::multimap;
using std::map;
using std::pair;
using std::runtime_error;
using std::sort;
using std::set;
using std::string;
using std::vector;
using std::exception;

#if defined(NDEBUG)
# error "Bitcoin cannot be compiled without assertions."
#endif

//
// Global state
//

CCriticalSection cs_main;

map<uint256, CBlockIndex*> mapBlockIndex;
CChain chainActive;
int64_t nTimeBestReceived = 0;
CWaitableCriticalSection csBestBlock;
CConditionVariable cvBlockChange;
int nScriptCheckThreads = 0;
bool fImporting = false;
bool fReindex = false;
bool fTxIndex = false;
bool fMempoolSync = false;
bool fIsBareMultisigStd = true;
unsigned int nCoinCacheSize = 5000;

#ifdef ENABLE_GCOIN
map<string, vector<map<string, bool> > > VoteList;
map<string, vector<map<string, bool> > > BanVoteList;

bool (*AlternateFunc_GetTransaction)(const uint256 &transaction_hash,
                                     CTransaction &result,
                                     uint256 &block_hash,
                                     const CBlock *block_to_search_first,
                                     bool allow_slow) = NULL;
bool (*AlternateFunc_GetCoinsFromCache)(const COutPoint &outpoint,
                                        CCoins &coins,
                                        bool fUseMempool) = NULL;

#endif // ENABLE_GCOIN
/** Fees smaller than this (in satoshi) are considered zero fee (for relaying and mining) */
CFeeRate minRelayTxFee = CFeeRate(1000);

CTxMemPool mempool(::minRelayTxFee);

struct COrphanBlock {
    uint256 hashBlock;
    uint256 hashPrev;
    vector<unsigned char> vchBlock;
};
map<uint256, COrphanBlock*> mapOrphanBlocks;
multimap<uint256, COrphanBlock*> mapOrphanBlocksByPrev;

map<uint256, CTransaction> mapOrphanTransactions;
map<uint256, set<uint256> > mapOrphanTransactionsByPrev;

// Constant stuff for coinbase transactions we create:
CScript COINBASE_FLAGS;

const string strMessageMagic = "gCoin Signed Message:\n";

// Internal stuff
namespace
{

struct CBlockIndexWorkComparator {
    bool operator()(CBlockIndex *pa, CBlockIndex *pb)
    {
        // First sort by most total work, ...
        if (pa->nChainWork > pb->nChainWork) return false;
        if (pa->nChainWork < pb->nChainWork) return true;

        // ... then by earliest time received, ...
        if (pa->nSequenceId < pb->nSequenceId) return false;
        if (pa->nSequenceId > pb->nSequenceId) return true;

        // Use pointer address as tie breaker (should only happen with blocks
        // loaded from disk, as those all have id 0).
        return (pa > pb);
    }
};

CBlockIndex *pindexBestInvalid;

// The set of all CBlockIndex entries with BLOCK_VALID_TRANSACTIONS or better that are at least
// as good as our current tip. Entries may be failed, though.
set<CBlockIndex*, CBlockIndexWorkComparator> setBlockIndexValid;

CCriticalSection cs_LastBlockFile;
CBlockFileInfo infoLastBlockFile;
int nLastBlockFile = 0;

// Every received block is assigned a unique and increasing identifier, so we
// know which one to give priority in case of a fork.
CCriticalSection cs_nBlockSequenceId;
// Blocks loaded from disk are assigned id 0, so start the counter at 1.
uint32_t nBlockSequenceId = 1;

// Sources of received blocks, to be able to send them reject messages or ban
// them, if processing happens afterwards. Protected by cs_main.
map<uint256, NodeId> mapBlockSource;

// Blocks that are in flight, and that are in the queue to be downloaded.
// Protected by cs_main.
struct QueuedBlock {
    uint256 hash;
    int64_t nTime;  // Time of "getdata" request in microseconds.
    int nQueuedBefore;  // Number of blocks in flight at the time of request.
};
map<uint256, pair<NodeId, list<QueuedBlock>::iterator> > mapBlocksInFlight;
map<uint256, pair<NodeId, list<uint256>::iterator> > mapBlocksToDownload;

} // anon namespace

//////////////////////////////////////////////////////////////////////////////
//
// dispatching functions
//

// These functions dispatch to one or all registered wallets

namespace
{

struct CMainSignals {
    // Notifies listeners of updated transaction data (transaction, and optionally the block it is found in.
    boost::signals2::signal<void (const CTransaction &, const CBlock *)> SyncTransaction;
    // Notifies listeners of an erased transaction (currently disabled, requires transaction replacement).
    boost::signals2::signal<void (const uint256 &)> EraseTransaction;
    // Notifies listeners of an updated transaction without new data (for now: a coinbase potentially becoming visible).
    boost::signals2::signal<void (const uint256 &)> UpdatedTransaction;
    // Notifies listeners of a new active block chain.
    boost::signals2::signal<void (const CBlockLocator &)> SetBestChain;
    // Notifies listeners about an inventory item being seen on the network.
    boost::signals2::signal<void (const uint256 &)> Inventory;
    // Tells listeners to broadcast their data.
    boost::signals2::signal<void ()> Broadcast;
} g_signals;

} // anon namespace

void RegisterWallet(CWalletInterface* pwalletIn)
{
    g_signals.SyncTransaction.connect(boost::bind(&CWalletInterface::SyncTransaction, pwalletIn, _1, _2));
    g_signals.EraseTransaction.connect(boost::bind(&CWalletInterface::EraseFromWallet, pwalletIn, _1));
    g_signals.UpdatedTransaction.connect(boost::bind(&CWalletInterface::UpdatedTransaction, pwalletIn, _1));
    g_signals.SetBestChain.connect(boost::bind(&CWalletInterface::SetBestChain, pwalletIn, _1));
    g_signals.Inventory.connect(boost::bind(&CWalletInterface::Inventory, pwalletIn, _1));
    g_signals.Broadcast.connect(boost::bind(&CWalletInterface::ResendWalletTransactions, pwalletIn));
}

void UnregisterWallet(CWalletInterface* pwalletIn)
{
    g_signals.Broadcast.disconnect(boost::bind(&CWalletInterface::ResendWalletTransactions, pwalletIn));
    g_signals.Inventory.disconnect(boost::bind(&CWalletInterface::Inventory, pwalletIn, _1));
    g_signals.SetBestChain.disconnect(boost::bind(&CWalletInterface::SetBestChain, pwalletIn, _1));
    g_signals.UpdatedTransaction.disconnect(boost::bind(&CWalletInterface::UpdatedTransaction, pwalletIn, _1));
    g_signals.EraseTransaction.disconnect(boost::bind(&CWalletInterface::EraseFromWallet, pwalletIn, _1));
    g_signals.SyncTransaction.disconnect(boost::bind(&CWalletInterface::SyncTransaction, pwalletIn, _1, _2));
}

void UnregisterAllWallets()
{
    g_signals.Broadcast.disconnect_all_slots();
    g_signals.Inventory.disconnect_all_slots();
    g_signals.SetBestChain.disconnect_all_slots();
    g_signals.UpdatedTransaction.disconnect_all_slots();
    g_signals.EraseTransaction.disconnect_all_slots();
    g_signals.SyncTransaction.disconnect_all_slots();
}

void SyncWithWallets(const CTransaction &tx, const CBlock *pblock)
{
    g_signals.SyncTransaction(tx, pblock);
}

//////////////////////////////////////////////////////////////////////////////
//
// Registration of network node signals.
//

namespace
{

struct CBlockReject {
    unsigned char chRejectCode;
    string strRejectReason;
    uint256 hashBlock;
};

// Maintain validation-specific state about nodes, protected by cs_main, instead
// by CNode's own locks. This simplifies asynchronous operation, where
// processing of incoming data is done after the ProcessMessage call returns,
// and we're no longer holding the node's locks.
struct CNodeState {
    // Accumulated misbehaviour score for this peer.
    int nMisbehavior;
    // Whether this peer should be disconnected and banned (unless whitelisted).
    bool fShouldBan;
    // String name of this peer (debugging/logging purposes).
    string name;
    // List of asynchronously-determined block rejections to notify this peer about.
    vector<CBlockReject> rejects;
    // The best known block we know this peer has announced.
    CBlockIndex *pindexBestKnownBlock;
    // The hash of the last unknown block this peer has announced.
    uint256 hashLastUnknownBlock;
    list<QueuedBlock> vBlocksInFlight;
    int nBlocksInFlight;
    list<uint256> vBlocksToDownload;
    int nBlocksToDownload;
    int64_t nLastBlockReceive;
    int64_t nLastBlockProcess;

    CNodeState()
    {
        nMisbehavior = 0;
        fShouldBan = false;
        pindexBestKnownBlock = NULL;
        hashLastUnknownBlock = uint256(0);
        nBlocksToDownload = 0;
        nBlocksInFlight = 0;
        nLastBlockReceive = 0;
        nLastBlockProcess = 0;
    }
};

// Map maintaining per-node state. Requires cs_main.
map<NodeId, CNodeState> mapNodeState;

// Requires cs_main.
CNodeState *State(NodeId pnode)
{
    map<NodeId, CNodeState>::iterator it = mapNodeState.find(pnode);
    if (it == mapNodeState.end())
        return NULL;
    return &it->second;
}

int GetHeight()
{
    LOCK(cs_main);
    return chainActive.Height();
}

void InitializeNode(NodeId nodeid, const CNode *pnode)
{
    LOCK(cs_main);
    CNodeState &state = mapNodeState.insert(make_pair(nodeid, CNodeState())).first->second;
    state.name = pnode->addrName;
}

void FinalizeNode(NodeId nodeid)
{
    LOCK(cs_main);
    CNodeState *state = State(nodeid);

    BOOST_FOREACH(const QueuedBlock& entry, state->vBlocksInFlight)
        mapBlocksInFlight.erase(entry.hash);
    BOOST_FOREACH(const uint256& hash, state->vBlocksToDownload)
        mapBlocksToDownload.erase(hash);

    mapNodeState.erase(nodeid);
}

// Requires cs_main.
void MarkBlockAsReceived(const uint256 &hash, NodeId nodeFrom = -1)
{
    map<uint256, pair<NodeId, list<uint256>::iterator> >::iterator itToDownload = mapBlocksToDownload.find(hash);
    if (itToDownload != mapBlocksToDownload.end()) {
        CNodeState *state = State(itToDownload->second.first);
        state->vBlocksToDownload.erase(itToDownload->second.second);
        state->nBlocksToDownload--;
        mapBlocksToDownload.erase(itToDownload);
    }

    map<uint256, pair<NodeId, list<QueuedBlock>::iterator> >::iterator itInFlight = mapBlocksInFlight.find(hash);
    if (itInFlight != mapBlocksInFlight.end()) {
        CNodeState *state = State(itInFlight->second.first);
        state->vBlocksInFlight.erase(itInFlight->second.second);
        state->nBlocksInFlight--;
        if (itInFlight->second.first == nodeFrom)
            state->nLastBlockReceive = GetTimeMicros();
        mapBlocksInFlight.erase(itInFlight);
    }
}

// Requires cs_main.
bool AddBlockToQueue(NodeId nodeid, const uint256 &hash)
{
    if (mapBlocksToDownload.count(hash) || mapBlocksInFlight.count(hash))
        return false;

    CNodeState *state = State(nodeid);
    if (state == NULL)
        return false;

    list<uint256>::iterator it = state->vBlocksToDownload.insert(state->vBlocksToDownload.end(), hash);
    state->nBlocksToDownload++;
    if (state->nBlocksToDownload > 5000)
        Misbehaving(nodeid, 10);
    mapBlocksToDownload[hash] = make_pair(nodeid, it);
    return true;
}

// Requires cs_main.
void MarkBlockAsInFlight(NodeId nodeid, const uint256 &hash)
{
    CNodeState *state = State(nodeid);
    assert(state != NULL);

    // Make sure it's not listed somewhere already.
    MarkBlockAsReceived(hash);

    QueuedBlock newentry = {hash, GetTimeMicros(), state->nBlocksInFlight};
    if (state->nBlocksInFlight == 0)
        state->nLastBlockReceive = newentry.nTime; // Reset when a first request is sent.
    list<QueuedBlock>::iterator it = state->vBlocksInFlight.insert(state->vBlocksInFlight.end(), newentry);
    state->nBlocksInFlight++;
    mapBlocksInFlight[hash] = make_pair(nodeid, it);
}

/** Check whether the last unknown block a peer advertized is not yet known. */
void ProcessBlockAvailability(NodeId nodeid)
{
    CNodeState *state = State(nodeid);
    assert(state != NULL);

    if (state->hashLastUnknownBlock != 0) {
        map<uint256, CBlockIndex*>::iterator itOld = mapBlockIndex.find(state->hashLastUnknownBlock);
        if (itOld != mapBlockIndex.end() && itOld->second->nChainWork > 0) {
            if (state->pindexBestKnownBlock == NULL || itOld->second->nChainWork >= state->pindexBestKnownBlock->nChainWork)
                state->pindexBestKnownBlock = itOld->second;
            state->hashLastUnknownBlock = uint256(0);
        }
    }
}

/** Update tracking information about which blocks a peer is assumed to have. */
void UpdateBlockAvailability(NodeId nodeid, const uint256 &hash)
{
    CNodeState *state = State(nodeid);
    assert(state != NULL);

    ProcessBlockAvailability(nodeid);

    map<uint256, CBlockIndex*>::iterator it = mapBlockIndex.find(hash);
    if (it != mapBlockIndex.end() && it->second->nChainWork > 0) {
        // An actually better block was announced.
        if (state->pindexBestKnownBlock == NULL || it->second->nChainWork >= state->pindexBestKnownBlock->nChainWork)
            state->pindexBestKnownBlock = it->second;
    } else {
        // An unknown block was announced; just assume that the latest one is the best one.
        state->hashLastUnknownBlock = hash;
    }
}

} // anon namespace

bool GetNodeStateStats(NodeId nodeid, CNodeStateStats &stats)
{
    LOCK(cs_main);
    CNodeState *state = State(nodeid);
    if (state == NULL)
        return false;
    stats.nMisbehavior = state->nMisbehavior;
    stats.nSyncHeight = state->pindexBestKnownBlock ? state->pindexBestKnownBlock->nHeight : -1;
    return true;
}

void RegisterNodeSignals(CNodeSignals& nodeSignals)
{
    nodeSignals.GetHeight.connect(&GetHeight);
    nodeSignals.ProcessMessages.connect(&ProcessMessages);
    nodeSignals.SendMessages.connect(&SendMessages);
    nodeSignals.InitializeNode.connect(&InitializeNode);
    nodeSignals.FinalizeNode.connect(&FinalizeNode);
}

void UnregisterNodeSignals(CNodeSignals& nodeSignals)
{
    nodeSignals.GetHeight.disconnect(&GetHeight);
    nodeSignals.ProcessMessages.disconnect(&ProcessMessages);
    nodeSignals.SendMessages.disconnect(&SendMessages);
    nodeSignals.InitializeNode.disconnect(&InitializeNode);
    nodeSignals.FinalizeNode.disconnect(&FinalizeNode);
}

//////////////////////////////////////////////////////////////////////////////
//
// CChain implementation
//

CBlockIndex *CChain::SetTip(CBlockIndex *pindex)
{
    if (pindex == NULL) {
        vChain.clear();
        return NULL;
    }
    vChain.resize(pindex->nHeight + 1);
    while (pindex && vChain[pindex->nHeight] != pindex) {
        vChain[pindex->nHeight] = pindex;
        pindex = pindex->pprev;
    }
    return pindex;
}

CBlockLocator CChain::GetLocator(const CBlockIndex *pindex) const
{
    int nStep = 1;
    vector<uint256> vHave;
    vHave.reserve(32);

    if (!pindex)
        pindex = Tip();
    while (pindex) {
        vHave.push_back(pindex->GetBlockHash());
        // Stop when we have added the genesis block.
        if (pindex->nHeight == 0)
            break;
        // Exponentially larger steps back, plus the genesis block.
        int nHeight = std::max(pindex->nHeight - nStep, 0);
        if (Contains(pindex)) {
            // Use O(1) CChain index if possible.
            pindex = (*this)[nHeight];
        } else {
            // Otherwise, use O(log n) skiplist.
            pindex = pindex->GetAncestor(nHeight);
        }
        if (vHave.size() > 10)
            nStep *= 2;
    }

    return CBlockLocator(vHave);
}

CBlockIndex *CChain::FindFork(const CBlockLocator &locator) const
{
    // Find the first block the caller has in the main chain
    BOOST_FOREACH(const uint256& hash, locator.vHave) {
        map<uint256, CBlockIndex*>::iterator mi = mapBlockIndex.find(hash);
        if (mi != mapBlockIndex.end()) {
            CBlockIndex* pindex = (*mi).second;
            if (Contains(pindex))
                return pindex;
        }
    }
    return Genesis();
}

const CBlockIndex *CChain::FindFork(const CBlockIndex *pindex) const
{
    if (pindex->nHeight > Height())
        pindex = pindex->GetAncestor(Height());
    while (pindex && !Contains(pindex))
        pindex = pindex->pprev;
    return pindex;
}

CCoinsViewCache *pcoinsTip = NULL;
CBlockTreeDB *pblocktree = NULL;

//////////////////////////////////////////////////////////////////////////////
//
// mapOrphanTransactions
//

bool AddOrphanTx(const CTransaction& tx)
{
    uint256 hash = tx.GetHash();
    if (mapOrphanTransactions.count(hash))
        return false;

    // Ignore big transactions, to avoid a
    // send-big-orphans memory exhaustion attack. If a peer has a legitimate
    // large transaction with a missing parent then we assume
    // it will rebroadcast it later, after the parent transaction(s)
    // have been mined or received.
    // 10,000 orphans, each of which is at most 5,000 bytes big is
    // at most 500 megabytes of orphans:
    unsigned int sz = tx.GetSerializeSize(SER_NETWORK, CTransaction::CURRENT_VERSION);
    if (sz > 5000) {
        LogPrint("mempool", "ignoring large orphan tx (size: %u, hash: %s)\n", sz, hash.ToString());
        return false;
    }

    mapOrphanTransactions[hash] = tx;
    BOOST_FOREACH(const CTxIn& txin, tx.vin)
        mapOrphanTransactionsByPrev[txin.prevout.hash].insert(hash);

    LogPrint("mempool", "stored orphan tx %s (mapsz %u)\n", hash.ToString(),
        mapOrphanTransactions.size());
    return true;
}

void static EraseOrphanTx(uint256 hash)
{
    if (!mapOrphanTransactions.count(hash))
        return;
    const CTransaction& tx = mapOrphanTransactions[hash];
    BOOST_FOREACH(const CTxIn& txin, tx.vin) {
        mapOrphanTransactionsByPrev[txin.prevout.hash].erase(hash);
        if (mapOrphanTransactionsByPrev[txin.prevout.hash].empty())
            mapOrphanTransactionsByPrev.erase(txin.prevout.hash);
    }
    mapOrphanTransactions.erase(hash);
}

unsigned int LimitOrphanTxSize(unsigned int nMaxOrphans)
{
    unsigned int nEvicted = 0;
    while (mapOrphanTransactions.size() > nMaxOrphans) {
        // Evict a random orphan:
        uint256 randomhash = GetRandHash();
        map<uint256, CTransaction>::iterator it = mapOrphanTransactions.lower_bound(randomhash);
        if (it == mapOrphanTransactions.end())
            it = mapOrphanTransactions.begin();
        EraseOrphanTx(it->first);
        ++nEvicted;
    }
    return nEvicted;
}







bool IsStandardTx(const CTransaction& tx, string& reason)
{
    AssertLockHeld(cs_main);
    if (tx.nVersion > CTransaction::CURRENT_VERSION || tx.nVersion < 1) {
        reason = "version";
        return false;
    }

    // Treat non-final transactions as non-standard to prevent a specific type
    // of double-spend attack, as well as DoS attacks. (if the transaction
    // can't be mined, the attacker isn't expending resources broadcasting it)
    // Basically we don't want to propagate transactions that can't be included in
    // the next block.
    //
    // However, IsFinalTx() is confusing... Without arguments, it uses
    // chainActive.Height() to evaluate nLockTime; when a block is accepted, chainActive.Height()
    // is set to the value of nHeight in the block. However, when IsFinalTx()
    // is called within CBlock::AcceptBlock(), the height of the block *being*
    // evaluated is what is used. Thus if we want to know if a transaction can
    // be part of the *next* block, we need to call IsFinalTx() with one more
    // than chainActive.Height().
    //
    // Timestamps on the other hand don't get any special treatment, because we
    // can't know what timestamp the next block will have, and there aren't
    // timestamp applications where it matters.
    if (!IsFinalTx(tx, chainActive.Height() + 1)) {
        reason = "non-final";
        return false;
    }

    // Extremely large transactions with lots of inputs can cost the network
    // almost as much to process as they cost the sender in fees, because
    // computing signature hashes is O(ninputs*txsize). Limiting transactions
    // to MAX_STANDARD_TX_SIZE mitigates CPU exhaustion attacks.
    unsigned int sz = tx.GetSerializeSize(SER_NETWORK, CTransaction::CURRENT_VERSION);
    if (sz >= MAX_STANDARD_TX_SIZE) {
        reason = "tx-size";
        return false;
    }

    BOOST_FOREACH(const CTxIn& txin, tx.vin) {
        // Biggest 'standard' txin is a 15-of-15 P2SH multisig with compressed
        // keys. (remember the 520 byte limit on redeemScript size) That works
        // out to a (15*(33+1))+3=513 byte redeemScript, 513+1+15*(73+1)+3=1627
        // bytes of scriptSig, which we round off to 1650 bytes for some minor
        // future-proofing. That's also enough to spend a 20-of-20
        // CHECKMULTISIG scriptPubKey, though such a scriptPubKey is not
        // considered standard)
        if (txin.scriptSig.size() > 1650) {
            reason = "scriptsig-size";
            return false;
        }
        if (!txin.scriptSig.IsPushOnly()) {
            reason = "scriptsig-not-pushonly";
            return false;
        }
        if (!txin.scriptSig.HasCanonicalPushes()) {
            reason = "scriptsig-non-canonical-push";
            return false;
        }
    }

    unsigned int nDataOut = 0;
    txnouttype whichType;
    BOOST_FOREACH(const CTxOut& txout, tx.vout) {
        if (!::IsStandard(txout.scriptPubKey, whichType)) {
            reason = "scriptpubkey";
            return false;
        }

        if (whichType == TX_NULL_DATA)
            nDataOut++;
        else if ((whichType == TX_MULTISIG) && (!fIsBareMultisigStd)) {
            reason = "bare-multisig";
            return false;
        } else if (txout.IsDust(::minRelayTxFee)) {
            reason = "dust";
            return false;
        }
    }

    // only one OP_RETURN txout is permitted
    if (nDataOut > 1) {
        reason = "multi-op-return";
        return false;
    }

    return true;
}

bool IsFinalTx(const CTransaction &tx, int nBlockHeight, int64_t nBlockTime)
{
    AssertLockHeld(cs_main);
    // Time based nLockTime implemented in 0.1.6
    if (tx.nLockTime == 0)
        return true;
    if (nBlockHeight == 0)
        nBlockHeight = chainActive.Height();
    if (nBlockTime == 0)
        nBlockTime = GetAdjustedTime();
    if ((int64_t)tx.nLockTime < ((int64_t)tx.nLockTime < LOCKTIME_THRESHOLD ? (int64_t)nBlockHeight : nBlockTime))
        return true;
    BOOST_FOREACH(const CTxIn& txin, tx.vin)
        if (!txin.IsFinal())
            return false;
    return true;
}

//
// Check transaction inputs to mitigate two
// potential denial-of-service attacks:
//
// 1. scriptSigs with extra data stuffed into them,
//    not consumed by scriptPubKey (or P2SH script)
// 2. P2SH scripts with a crazy number of expensive
//    CHECKSIG/CHECKMULTISIG operations
//
bool AreInputsStandard(const CTransaction& tx, const CCoinsViewCache& mapInputs)
{
    if (tx.IsCoinBase())
        return true; // Coinbases don't use vin normally

    for (unsigned int i = 0; i < tx.vin.size(); i++) {
        const CTxOut& prev = mapInputs.GetOutputFor(tx.vin[i]);

        vector<vector<unsigned char> > vSolutions;
        txnouttype whichType;
        // get the scriptPubKey corresponding to this input:
        const CScript& prevScript = prev.scriptPubKey;
        if (!Solver(prevScript, whichType, vSolutions))
            return false;
        int nArgsExpected = ScriptSigArgsExpected(whichType, vSolutions);
        if (nArgsExpected < 0)
            return false;

        // Transactions with extra stuff in their scriptSigs are
        // non-standard. Note that this EvalScript() call will
        // be quick, because if there are any operations
        // beside "push data" in the scriptSig
        // IsStandard() will have already returned false
        // and this method isn't called.
        vector<vector<unsigned char> > stack;
        if (!EvalScript(stack, tx.vin[i].scriptSig, tx, i, false, 0))
            return false;

        if (whichType == TX_SCRIPTHASH) {
            if (stack.empty())
                return false;
            CScript subscript(stack.back().begin(), stack.back().end());
            vector<vector<unsigned char> > vSolutions2;
            txnouttype whichType2;
            if (Solver(subscript, whichType2, vSolutions2)) {
                int tmpExpected = ScriptSigArgsExpected(whichType2, vSolutions2);
                if (tmpExpected < 0)
                    return false;
                nArgsExpected += tmpExpected;
            } else {
                // Any other Script with less than 15 sigops OK:
                unsigned int sigops = subscript.GetSigOpCount(true);
                // ... extra data left on the stack after execution is OK, too:
                return (sigops <= MAX_P2SH_SIGOPS);
            }
        }

        if (stack.size() != (unsigned int)nArgsExpected)
            return false;
    }

    return true;
}

unsigned int GetLegacySigOpCount(const CTransaction& tx)
{
    unsigned int nSigOps = 0;
    BOOST_FOREACH(const CTxIn& txin, tx.vin) {
        nSigOps += txin.scriptSig.GetSigOpCount(false);
    }
    BOOST_FOREACH(const CTxOut& txout, tx.vout) {
        nSigOps += txout.scriptPubKey.GetSigOpCount(false);
    }
    return nSigOps;
}

unsigned int GetP2SHSigOpCount(const CTransaction& tx, const CCoinsViewCache& inputs)
{
    if (tx.IsCoinBase())
        return 0;

    unsigned int nSigOps = 0;
    for (unsigned int i = 0; i < tx.vin.size(); i++) {
        const CTxOut &prevout = inputs.GetOutputFor(tx.vin[i]);
        if (prevout.scriptPubKey.IsPayToScriptHash())
            nSigOps += prevout.scriptPubKey.GetSigOpCount(tx.vin[i].scriptSig);
    }
    return nSigOps;
}

int CMerkleTx::SetMerkleBranch(const CBlock* pblock)
{
    AssertLockHeld(cs_main);
    CBlock blockTmp;

    if (pblock == NULL) {
        CCoins coins;
        if (pcoinsTip->GetCoins(GetHash(), coins)) {
            CBlockIndex *pindex = chainActive[coins.nHeight];
            if (pindex) {
                if (!ReadBlockFromDisk(blockTmp, pindex))
                    return 0;
                pblock = &blockTmp;
            }
        }
    }

    if (pblock) {
        // Update the tx's hashBlock
        hashBlock = pblock->GetHash();

        // Locate the transaction
        for (nIndex = 0; nIndex < (int)pblock->vtx.size(); nIndex++)
            if (pblock->vtx[nIndex] == *(CTransaction*)this)
                break;
        if (nIndex == (int)pblock->vtx.size()) {
            vMerkleBranch.clear();
            nIndex = -1;
            LogPrintf("ERROR: %s() : couldn't find tx in block\n", __func__);
            return 0;
        }

        // Fill in merkle branch
        vMerkleBranch = pblock->GetMerkleBranch(nIndex);
    }

    // Is the tx in a block that's in the main chain
    map<uint256, CBlockIndex*>::iterator mi = mapBlockIndex.find(hashBlock);
    if (mi == mapBlockIndex.end())
        return 0;
    CBlockIndex* pindex = (*mi).second;
    if (!pindex || !chainActive.Contains(pindex))
        return 0;

    return chainActive.Height() - pindex->nHeight + 1;
}







bool CheckTransaction(const CTransaction& tx, CValidationState &state)
{
    // Basic checks that don't depend on any context
    if (tx.vin.empty())
        return state.DoS(10, error("%s() : vin empty", __func__),
                         REJECT_INVALID, "bad-txns-vin-empty");
    if (tx.vout.empty())
        return state.DoS(10, error("%s() : vout empty", __func__),
                         REJECT_INVALID, "bad-txns-vout-empty");
    // Size limits
    if (::GetSerializeSize(tx, SER_NETWORK, PROTOCOL_VERSION) > MAX_BLOCK_SIZE)
        return state.DoS(100, error("%s() : size limits failed", __func__),
                         REJECT_INVALID, "bad-txns-oversize");

    // Check for negative or overflow output values
    int64_t nValueOut = 0;
    BOOST_FOREACH(const CTxOut& txout, tx.vout) {
        if (txout.nValue < 0)
            return state.DoS(100, error("%s() : txout.nValue negative", __func__),
                             REJECT_INVALID, "bad-txns-vout-negative");
        if (txout.nValue > MAX_MONEY)
            return state.DoS(100, error("%s() : txout.nValue too high", __func__),
                             REJECT_INVALID, "bad-txns-vout-toolarge");
        nValueOut += txout.nValue;
        if (!MoneyRange(nValueOut))
            return state.DoS(100, error("%s() : txout total out of range", __func__),
                             REJECT_INVALID, "bad-txns-txouttotal-toolarge");
    }

    // Check for duplicate inputs
    set<COutPoint> vInOutPoints;
    BOOST_FOREACH(const CTxIn& txin, tx.vin) {
        if (vInOutPoints.count(txin.prevout))
            return state.DoS(100, error("%s() : duplicate inputs", __func__),
                             REJECT_INVALID, "bad-txns-inputs-duplicate");
        vInOutPoints.insert(txin.prevout);
    }

    if (tx.IsCoinBase()) {
        /* TODO : check here
        if (tx.vin[0].scriptSig.size() < 2 || tx.vin[0].scriptSig.size() > 100)
            return state.DoS(100, error("%s() : coinbase script size", __func__),
                             REJECT_INVALID, "bad-cb-length");
        */
    } else {
        BOOST_FOREACH(const CTxIn& txin, tx.vin)
            if (txin.prevout.IsNull())
                return state.DoS(10, error("%s() : prevout is null", __func__),
                                 REJECT_INVALID, "bad-txns-prevout-null");
    }

    return true;
}

int64_t GetMinRelayFee(const CTransaction& tx, unsigned int nBytes, bool fAllowFree)
{
    {
        LOCK(mempool.cs);
        uint256 hash = tx.GetHash();
        double dPriorityDelta = 0;
        int64_t nFeeDelta = 0;
        mempool.ApplyDeltas(hash, dPriorityDelta, nFeeDelta);
        if (dPriorityDelta > 0 || nFeeDelta > 0)
            return 0;
    }

    int64_t nMinFee = ::minRelayTxFee.GetFee(nBytes);

    if (fAllowFree) {
        // There is a free transaction area in blocks created by most miners,
        // * If we are relaying we allow transactions up to DEFAULT_BLOCK_PRIORITY_SIZE - 1000
        //   to be considered to fall into this category. We don't want to encourage sending
        //   multiple transactions instead of one big transaction to avoid fees.
        if (nBytes < (DEFAULT_BLOCK_PRIORITY_SIZE - 1000))
            nMinFee = 0;
    }

    if (!MoneyRange(nMinFee))
        nMinFee = MAX_MONEY;
    return nMinFee;
}


/**
 * NEW FUNCTION: GetDestination, added by Yen-Chieh
 * Get ScriptPubKey address
 */
string GetDestination(const CScript& tx_scriptPubKey)
{
    vector<CTxDestination> addresses;
    txnouttype tx_type;
    int tx_nRequired;

    if (!ExtractDestinations(tx_scriptPubKey, tx_type, addresses, tx_nRequired))
        return "";

    if (addresses.size() == 0)
        return "";

    return CBitcoinAddress(addresses[0]).ToString();
}

#ifdef ENABLE_GCOIN

namespace color_license
{

namespace
{

struct Owner_
{
    string address;
    int64_t num_of_coins;
    int64_t count;
    Owner_() : address(""), num_of_coins(0), count(0) {}
};

map<type_Color, Owner_> licenses_;

}

void Remove(const type_Color &color)
{
    licenses_.erase(color);
}

void RemoveAll()
{
    licenses_.clear();
}

void SetOwner(const type_Color &color, const string &addr)
{
    licenses_[color].address = addr;
}

void AddLicenseCount(const type_Color &color, int64_t count)
{
    licenses_[color].count += count;
}

void AddNumOfCoins(const type_Color &color, int64_t num_of_coins)
{
    licenses_[color].num_of_coins += num_of_coins;
}

bool IsExist(const type_Color &color)
{
    if (color == 0)
        return true;
    return (licenses_.find(color) != licenses_.end());
}

bool HasOwner(const type_Color &color)
{
    map<type_Color, Owner_>::iterator it = licenses_.find(color);
    return (it != licenses_.end() && it->second.address != "");
}

void RemoveOwner(const type_Color &color)
{
     licenses_[color].address = "";
}

void RemoveLicense(const type_Color &color)
{
    licenses_[color].count--;
    if (licenses_[color].count <= 0)
        Remove(color);
    else
        RemoveOwner(color);
}

bool IsOwner(const type_Color &color, std::string &addr)
{
    if(addr == "")
        return false;
    map<type_Color, Owner_>::iterator it = licenses_.find(color);
    return (it != licenses_.end() && it->second.address == addr);
}

int64_t NumOfCoins(const type_Color &color)
{
    map<type_Color, Owner_>::iterator it = licenses_.find(color);
    if (it == licenses_.end()) {
        return 0;
    }
    return it->second.num_of_coins;
}

map<type_Color, pair<string, int64_t> > ListLicense()
{
    map<type_Color, pair<string, int64_t> > list;
    for (map<type_Color, Owner_>::const_iterator it = licenses_.begin(); it != licenses_.end(); it++) {
        list[it->first] = make_pair(it->second.address, it->second.num_of_coins);
    }
    return list;
}

}  // namespace color_license


namespace alliance_member
{

namespace
{

std::set<std::string> members_;

}  // namespace

void Add(const std::string &addr)
{
    members_.insert(addr);
}

void Remove(const std::string &addr)
{
    members_.erase(addr);
}

void RemoveAll()
{
    members_.clear();
}

bool IsMember(const std::string &addr)
{
    return (members_.find(addr) != members_.end());
}

size_t NumOfMembers()
{
    return members_.size();
}

CIterator IteratorBegin()
{
    return members_.begin();
}

CIterator IteratorEnd()
{
    return members_.end();
}

}  // namespace alliance_member


namespace activate_address_with_color
{

namespace
{

std::map<type_Color, std::map<std::string, int64_t> > activated_dict_;

}  // namespace


void Activate(const std::string &addr, const type_Color &color)
{
    if (IsActivated(addr, color))
        activated_dict_[color][addr]++;
    else
        activated_dict_[color][addr] = 1;
}


void Deactivate(const std::string &addr, const type_Color &color)
{
    if (!IsActivated(addr, color))
        return;
    activated_dict_[color][addr]--;
    if (activated_dict_[color][addr] <= 0)
        RemoveMember(addr, color);
}


bool IsColorExist(const type_Color &color)
{
    return (activated_dict_.find(color) != activated_dict_.end());
}


bool IsActivated(const std::string &addr, const type_Color &color)
{
    std::map<type_Color, std::map<std::string, int64_t> >::iterator it;
    it = activated_dict_.find(color);
    return (it != activated_dict_.end() &&
            it->second.find(addr) != it->second.end());
}


void RemoveMember(const std::string &addr, const type_Color &color)
{
    activated_dict_[color].erase(addr);
}


void RemoveColor(const type_Color &color)
{
    activated_dict_.erase(color);
}


void RemoveAll()
{
    activated_dict_.clear();
}

}  // namespace active_address_with_color


namespace ban_address
{

namespace
{

// TODO(cathook@gmail.com): Removes this global variable.
std::set<std::string> banned_addresses_;

}  // namespace


bool IsBanned(const std::string &addr)
{
    return (banned_addresses_.find(addr) != banned_addresses_.end());
}


void Add(const std::string &addr)
{
    banned_addresses_.insert(addr);
}


void Remove(const std::string &addr)
{
    banned_addresses_.erase(addr);
}

void RemoveAll()
{
    banned_addresses_.clear();
}

}  // namespace ban_address


namespace ban_color
{

namespace
{

// TODO(cathook@gmail.com): Removes this global variable.
std::set<type_Color> banned_colors_;

}  // namespace


bool IsBanned(const type_Color &color)
{
    return (banned_colors_.find(color) != banned_colors_.end());
}


void Add(const type_Color &color)
{
    banned_colors_.insert(color);
}


void Remove(const type_Color &color)
{
    banned_colors_.erase(color);
}


void RemoveAll()
{
    banned_colors_.clear();
}

}  // namespace ban_color


namespace type_transaction_handler
{

namespace
{

const char * const BAD_TXNS_TYPE_ = "bad-txns-type-";


bool RejectInvalidTypeTx_(const tx_type &type,
                          const std::string &func, const std::string &detail,
                          CValidationState &state, int level,
                          std::string reason="")
{
    error("%s: %s transaction invalid (%s)", func, TxType[type], detail);
    if (reason == "") {
        reason = std::string(BAD_TXNS_TYPE_) + TxType[type];
    }
    return state.DoS(level, false, REJECT_INVALID, reason);
}


class HandlerUtility_
{
protected:
    HandlerUtility_(tx_type type) : type_(type) {}

    /*!
     * @brief Setups the state and returns false.
     * @param [in] detail Detail informations about the error.
     * @param [in] state
     * @param [in] level
     * @param [in] reason The reject reason. If it is an empty string, it will
     *         be replaced by "bad-txns-type-SOME_TYPE' in default.
     */
    bool RejectInvalidTypeTx(
            const std::string &detail,
            CValidationState &state, int level, std::string reason="")
    {
        return RejectInvalidTypeTx_(
                type_, "CheckValid()", detail, state, level, reason);
    }

private:
    tx_type type_;
};


class Handler_Normal_ : public HandlerInterface, public HandlerUtility_
{
public:
    Handler_Normal_() : HandlerUtility_(NORMAL) {}

    bool CheckValid(const CTransaction &tx, CValidationState &state,
                    const CBlock *pblock)
    {
        if (!tx.IsCoinBase()) {
            if (!color_license::IsExist(tx.color)) {
                return RejectInvalidTypeTx(
                        strprintf("no license for color %u", tx.color),
                        state, 100);
            }

            string senderAddr = GetTxInputAddr(tx, pblock);
            string receiverAddr = GetTxOutputAddr(tx, 0);
            if (!color_license::IsOwner(tx.color, senderAddr) &&
                !color_license::IsOwner(tx.color, receiverAddr)) {
                if (!activate_address_with_color::IsColorExist(tx.color)) {
                    string error_msg = strprintf(
                            "no activate record for color %u", tx.color);
                    return RejectInvalidTypeTx(error_msg, state, 100);
                }
                if (!activate_address_with_color::IsActivated(
                            receiverAddr, tx.color)) {
                    return RejectInvalidTypeTx(
                            "receiver not record in blockchain",
                            state, 10,
                            std::string(BAD_TXNS_TYPE_) + "not-exist");
                }
            }
        }
        return true;
    };

    bool CheckFormat(const CTransaction &tx, CValidationState &state,
                    const CBlock *pblock)
    {
        if (!tx.IsCoinBase()) {
            if (tx.color <= 0) {
                return RejectInvalidTypeTx("color invalid", state, 100);
            }
        }
        return true;
    }

    bool Apply(CBlock *pblock, const CTransaction &tx)
    {
        if (tx.IsCoinBase())
            return true;
        string senderAddr = GetTxInputAddr(tx, pblock);
        if (color_license::IsExist(tx.color)) {
            if (color_license::IsOwner(tx.color, senderAddr)) {
                if (!HandleActivateTx_(tx, pblock))
                    return error("%s() : Handle Activate failed", __func__);
            }
        } else {
            return error("%s() : No valid Color %d License", __func__, tx.color);
        }
        return true;
    }

    bool Undo(const CTransaction &tx, CBlock &block)
    {
        if (tx.color == 0) {
            return true;
        }
        string senderAddr = GetTxInputAddr(tx, &block);
        string receiverAddr = GetTxOutputAddr(tx, 0);
        if (!color_license::IsOwner(tx.color, senderAddr)) {
            return true;
        } else {
            activate_address_with_color::Deactivate(receiverAddr, tx.color);
            return true;
        }
    }
private:
    bool HandleActivateTx_(CTransaction tx, CBlock *pblock)
    {
        LOCK(cs_main);
        string issuerAddr = GetTxInputAddr(tx, pblock);
        string activateAddr = GetTxOutputAddr(tx, 0);

        activate_address_with_color::Activate(issuerAddr, tx.color);
        activate_address_with_color::Activate(activateAddr, tx.color);
        return true;
    }
};


class Handler_Mint_ : public HandlerInterface, public HandlerUtility_
{
public:
    Handler_Mint_() : HandlerUtility_(MINT) {}

    bool CheckValid(const CTransaction &tx, CValidationState &state,
                    const CBlock *pblock)
    {
        // first check if he is AE or not, AE can MINT color 0 without License
        string addr = GetTxOutputAddr(tx, 0);
        if (tx.color != 0) {
            if (!color_license::IsOwner(tx.color, addr)) {
                return RejectInvalidTypeTx(
                        strprintf("mint color=%u without license", tx.color),
                        state, 100);
            }
        } else {
            if (!alliance_member::IsMember(addr)) {
                return RejectInvalidTypeTx(
                        "not AE but mint color=0", state, 100);
            }
        }

        return true;
    };

    bool CheckFormat(const CTransaction &tx, CValidationState &state,
                    const CBlock *pblock)
    {
        assert(tx.vout.size() > 0);
        if (tx.color == 0) {
            if (tx.vout[0].nValue != COIN) {
                return RejectInvalidTypeTx(
                        "value of color 0 must be 1 COINS", state, 100);
            }
        } else {
            // check if total value of this color meet MAX_MONEY
            if (tx.vout[0].nValue > MAX_MONEY) {
                return RejectInvalidTypeTx(
                        "value bigger than MAX_MONEY", state, 100);
            }
            int64_t num_of_coins = color_license::NumOfCoins(tx.color);
            if (tx.vout[0].nValue > (MAX_MONEY - num_of_coins)) {
                string error_msg = strprintf(
                        "new mint value(%d) + total exist value(%d) "
                        "> MAX_MONEY(%d)",
                        tx.vout[0].nValue, num_of_coins, MAX_MONEY);
                return RejectInvalidTypeTx(error_msg, state, 100);
            }
        }
        return true;
    }

    bool Apply(CBlock *pblock, const CTransaction &tx)
    {
        assert(tx.vout.size() > 0);
        if (!color_license::IsExist(tx.color))
            return error("%s() : no license for color %u", __func__, tx.color);
        color_license::AddNumOfCoins(tx.color, tx.vout[0].nValue);
        return true;
    }

    bool Undo(const CTransaction &tx, CBlock &block)
    {
        assert(tx.vout.size() > 0);
        if (tx.color == 0) {
            return true;
        }
        if (!color_license::IsExist(tx.color)) {
            LogPrintf("%s() fail : no license for color %u\n", __func__, tx.color);
            return false;
        }
        color_license::AddNumOfCoins(tx.color, -tx.vout[0].nValue);
        return true;
    }
};


class Handler_License_ : public HandlerInterface, public HandlerUtility_
{
public:
    Handler_License_() : HandlerUtility_(LICENSE) {}

    bool CheckValid(const CTransaction &tx, CValidationState &state,
                    const CBlock *pblock)
    {
        bool fUseMempool = (pblock == NULL);

        // only AE Member can change license's color
        BOOST_FOREACH(const CTxIn txin, tx.vin) {
            CCoins coins;
            if (!GetCoinsFromCache(txin.prevout, coins, fUseMempool))
                return RejectInvalidTypeTx("fetch input failed", state, 50);
            if (coins.color != tx.color) {
                string addr = GetDestination(
                        coins.vout[txin.prevout.n].scriptPubKey);
                if (!(coins.type == MINT && coins.color == 0) || addr == "" ||
                    !alliance_member::IsMember(addr))
                    return RejectInvalidTypeTx(
                            "change color invalid", state, 100);
            }
        }

        // check if license of this color is used
        if (color_license::HasOwner(tx.color)) {
            string addr_from = GetTxInputAddr(tx, pblock);
            // license owner's address must equal to input address for license
            // transfer case
            if (!color_license::IsOwner(tx.color, addr_from))
                return RejectInvalidTypeTx(
                        "invalid license transfer", state, 100);
        }

        return true;
    };

    bool CheckFormat(const CTransaction &tx, CValidationState &state,
                    const CBlock *pblock)
    {
        if (tx.color <= 0)
            return RejectInvalidTypeTx("color invalid", state, 100);

        // for license, output size must be 1, and vout[0].nValue must be 1
        if (tx.vout.size() == 1) {
            if (tx.vout[0].nValue != COIN)
                return RejectInvalidTypeTx("out[0].nValue != COIN", state, 100);
        } else {
            return RejectInvalidTypeTx("size of output != 1", state, 100);
        }
        return true;
    }

    bool Apply(CBlock *pblock, const CTransaction &tx)
    {
        string receiverAddr = GetTxOutputAddr(tx, 0);
        color_license::SetOwner(tx.color, receiverAddr);
        color_license::AddLicenseCount(tx.color, 1);
        return true;
    }

    bool Undo(const CTransaction &tx, CBlock &block)
    {
        assert(tx.vin.size() > 0);

        CCoins coins;
        if (!GetCoinsFromCache(tx.vin[0].prevout, coins, false))
            return "";

        // erase this license if input was sent by alliance (from mint type tx)
        if (!color_license::IsExist(tx.color)) {
            LogPrintf("%s() fail : no license for color %u\n", __func__, tx.color);
            return false;
        }
        if (coins.color == 0) {
            color_license::RemoveLicense(tx.color);
        } else {
            // case license transfer
            string pre_owner = GetDestination(
                    coins.vout[tx.vin[0].prevout.n].scriptPubKey);
            if (pre_owner == "")
                return error("%s() : can't fetch address of pre tx\n", __func__);
            color_license::AddLicenseCount(tx.color, -1);
            color_license::SetOwner(tx.color, pre_owner);
        }
        return true;
    }

    bool CheckNotRepeated(const CTransaction &tx, const CTransaction &pool_tx,
                          CValidationState &state)
    {
        if (pool_tx.color == tx.color)
            return RejectInvalidTypeTx(
                    strprintf("color %u used : in memory conflict", tx.color),
                    state, 50);
        return true;
    }
};

class Handler_RevokeLicense_ : public HandlerInterface, public HandlerUtility_
{
public:
    Handler_RevokeLicense_() : HandlerUtility_(REVOKELICENSE) {}

    bool CheckValid(const CTransaction &tx, CValidationState &state,
                    const CBlock *pblock)
    {
        bool fUseMempool = (pblock == NULL);

        // only AE Member can revoke license
        BOOST_FOREACH(const CTxIn txin, tx.vin) {
            CCoins coins;
            if (!GetCoinsFromCache(txin.prevout, coins, fUseMempool))
                return RejectInvalidTypeTx("fetch input failed", state, 50);
            string addr = GetDestination(
                    coins.vout[txin.prevout.n].scriptPubKey);
            if (!(coins.type == MINT && coins.color == 0) || addr == "" ||
                !alliance_member::IsMember(addr)) {
                return RejectInvalidTypeTx(
                        "revoke-license invalid", state, 100);
            }
        }

        // check if license of this color is created
        if (!color_license::IsExist(tx.color)) {
            return RejectInvalidTypeTx(
                    "invalid revoke-license", state, 100);
        }

        string receiverAddr = GetTxOutputAddr(tx, 0);
        // license owner's address must equal to output address for license
        if (!color_license::IsOwner(tx.color, receiverAddr)) {
            return RejectInvalidTypeTx(
                    "invalid license owner address", state, 50);
        }

        return true;
    };

    bool CheckFormat(const CTransaction &tx, CValidationState &state,
                    const CBlock *pblock)
    {
        if (tx.color <= 0)
            return RejectInvalidTypeTx("color invalid", state, 100);

        // for revoke-license, output size must be 1, and vout[0].nValue must be 1
        if (tx.vout.size() == 1) {
            if (tx.vout[0].nValue != COIN)
                return RejectInvalidTypeTx("out[0].nValue != COIN", state, 100);
        } else {
            return RejectInvalidTypeTx("size of output != 1", state, 100);
        }

        return true;
    }

    bool Apply(CBlock *pblock, const CTransaction &tx)
    {
        color_license::RemoveOwner(tx.color);
        return true;
    }

    bool Undo(const CTransaction &tx, CBlock &block)
    {
        assert(tx.vin.size() > 0);

        CCoins coins;
        if (!GetCoinsFromCache(tx.vin[0].prevout, coins, false))
            return "";

        if (!color_license::IsExist(tx.color)) {
            LogPrintf("%s() fail : no license for color %u\n", __func__, tx.color);
            return false;
        }

        string pre_owner = GetTxOutputAddr(tx, 0);
        if (pre_owner == ""){
            LogPrintf("%s() : can't fetch address of pre tx\n", __func__);
            return false;
        }

        color_license::SetOwner(tx.color, pre_owner);
        return true;
    }

    bool CheckNotRepeated(const CTransaction &tx, const CTransaction &pool_tx,
                          CValidationState &state)
    {
        if (pool_tx.color == tx.color)
            return RejectInvalidTypeTx(
                    strprintf("color %u revoked : in memory conflict", tx.color),
                    state, 50);
        return true;
    }
};

class Handler_Vote_ : public HandlerInterface, public HandlerUtility_
{
public:
    Handler_Vote_() : HandlerUtility_(VOTE) {}

    bool CheckValid(const CTransaction &tx, CValidationState &state,
                    const CBlock *pblock)
    {
        string senderAddr = GetTxInputAddr(tx, pblock);
        string receiverAddr = GetTxOutputAddr(tx, 0);

        if (!alliance_member::IsMember(senderAddr))
            return RejectInvalidTypeTx("voter not AE member", state, 100);

        map<string, vector<map<string, bool> > >::const_iterator itVList = VoteList.find(receiverAddr);
        if (itVList != VoteList.end() && itVList->second.size() != 0) {
            map<string, bool>::const_iterator itVLVM = itVList->second.back().find(senderAddr);
            if (itVLVM == itVList->second.back().end())
                return RejectInvalidTypeTx("no sender address", state, 100);
            if (itVLVM->second) {
                if (itVList->second.back().size() == alliance_member::NumOfMembers()) {
                    map<string, bool>::const_iterator it_v, it_v_end;
                    alliance_member::CIterator it_m, it_m_end;
                    it_v = itVList->second.back().begin();
                    it_v_end = itVList->second.back().end();
                    it_m = alliance_member::IteratorBegin();
                    it_m_end = alliance_member::IteratorEnd();
                    bool fDiff = false;
                    for ( ; it_m != it_m_end && it_v != it_v_end; ++it_v, ++it_m) {
                        if (*it_m != it_v->first) {
                            fDiff = true;
                            break;
                        }
                    }
                    if (!fDiff) {
                        CCoinsViewCache view(*pcoinsTip, true);
                        if (view.HaveCoins(tx.GetHash())) {
                            LogPrintf("Warning : Already have this vote tx(may cause by block forking).\n");
                        } else {
                            return RejectInvalidTypeTx("voted", state, 100);
                        }
                    }
                }
            }
        }
        return true;
    };

    bool CheckFormat(const CTransaction &tx, CValidationState &state,
                    const CBlock *pblock)
    {
        if (tx.color != 0)
            return RejectInvalidTypeTx("color must be 0", state, 100);

        // for vote type tx, output size must be 1 and
        // vout[0].nValue must be 1
        if (tx.vout.size() == 1) {
            if (tx.vout[0].nValue != COIN)
                return RejectInvalidTypeTx("out[0].nValue != COIN", state, 100);
        } else {
            return RejectInvalidTypeTx("size of output != 1", state, 100);
        }
        return true;
    }

    bool Apply(CBlock *pblock, const CTransaction &tx)
    {
        LOCK(cs_main);
        string candidates = GetTxOutputAddr(tx, 0);
        string voter = GetTxInputAddr(tx, pblock);

        map<string, vector<map<string, bool> > >::iterator itVList = VoteList.find(candidates);
        map<string, bool>::iterator itVLVM;
        if (itVList == VoteList.end()) {
            itVList = CreateTheBilling_(candidates);
        } else {
            if (itVList->second.size() == 0) {
                LogPrintf("%s() fail : VoteList went wrong (this should not happen)\n", __func__);
                return error("%s() : Handle Vote failed", __func__);
            }
            itVLVM = itVList->second.back().find(voter);
            if (itVLVM == itVList->second.back().end()) {
                LogPrintf("%s() fail : voter \"%s\" is not an AE\n", __func__, voter);
                return error("%s() : Handle Vote failed", __func__);
            } else if (itVLVM->second) {
                itVList = CreateTheBilling_(candidates);
            }
        }

        if (itVList->second.size() == 0) {
            LogPrintf("%s() fail : VoteList went wrong (this should not happen)\n", __func__);
            return error("%s() : Handle Vote failed", __func__);
        }

        itVLVM = itVList->second.back().find(voter);
        if (itVLVM == itVList->second.back().end()) {
            LogPrintf("%s() fail : voter \"%s\" is not an AE\n", __func__, voter);
            return error("%s() : Handle Vote failed", __func__);
        }

        itVLVM->second = true;
        // check if vote pass
        uint32_t agree_cnt = 0;
        for (map<string, bool>::iterator it = itVList->second.back().begin(); it != itVList->second.back().end(); it++) {
            if (it->second)
                agree_cnt++;
        }
        // result : pass
        if (agree_cnt >= alliance_member::NumOfMembers() / 2) {
            alliance_member::Add(candidates);
        }
        return true;
    }

    bool Undo(const CTransaction &tx, CBlock &block)
    {
        string candidate = GetTxOutputAddr(tx, 0);
        string voter = GetTxInputAddr(tx, &block);

        // fetch the latest voting result, which is the one that counts.
        map<string, vector<map<string, bool> > >::iterator itVList = VoteList.find(candidate);
        if (itVList == VoteList.end() || itVList->second.size() == 0) {
            LogPrintf("%s () fail : VoteList went wrong (this should not happen)\n", __func__);
            return false;
        }

        map<string, bool> &latestVoting = itVList->second.back();
        map<string, bool>::iterator itVLVM = latestVoting.find(voter);
        if (itVLVM == latestVoting.end()) {
            LogPrintf("%s () fail : latestVoting went wrong (this should not happen)\n", __func__);
            return false;
        }

        // undo the vote in VoteList
        itVLVM->second = false;

        // see how many votes the candidate has received now.
        uint32_t agree_cnt = 0;
        for (map<string, bool>::iterator it = latestVoting.begin(); it != latestVoting.end(); it++)
            if (it->second)
                agree_cnt++;

        // update the MemberList.
        // if agree_cnt <= MemberList.size(),
        // delete the candidate from the MemberList.
        // TODO : confirm the condition to be the in MemberList
        if (agree_cnt <= latestVoting.size() / 2)
            alliance_member::Remove(candidate);
        return true;
    }

    bool CheckNotRepeated(const CTransaction &tx, const CTransaction &pool_tx,
                          CValidationState &state)
    {
        string txSenderAddr = GetTxInputAddr(tx, NULL);
        string txReceiverAddr = GetTxOutputAddr(tx, 0);
        string poolTxSenderAddr = GetTxInputAddr(pool_tx, NULL);
        string poolTxReceiverAddr = GetTxOutputAddr(pool_tx, 0);
        if (txReceiverAddr == poolTxReceiverAddr &&
            txSenderAddr == poolTxSenderAddr)
            return RejectInvalidTypeTx(
                    "voted for same candidate : in memory conflict", state, 50);
        return true;
    }

private:

    map<string, vector<map<string, bool> > >::iterator CreateTheBilling_(string &candidates)
    {
        map<string, vector<map<string, bool> > >::iterator itRet = VoteList.find(candidates);
        if (itRet == VoteList.end()) {
            itRet = (VoteList.insert(make_pair(candidates, vector<map<string, bool> >()))).first;
        }

        map<string, bool> List;
        for (alliance_member::CIterator it = alliance_member::IteratorBegin();
             it != alliance_member::IteratorEnd();
             ++it) {
            List.insert(make_pair(*it, false));
        }

        itRet->second.push_back(List);
        return itRet;
    }
};

class Handler_BanVote_ : public HandlerInterface, public HandlerUtility_
{
public:
    Handler_BanVote_() : HandlerUtility_(BANVOTE) {}

    bool CheckValid(const CTransaction &tx, CValidationState &state,
                    const CBlock *pblock)
    {
        string senderAddr = GetTxInputAddr(tx, pblock);
        string receiverAddr = GetTxOutputAddr(tx, 0);

        if (!alliance_member::IsMember(senderAddr))
            return RejectInvalidTypeTx("voter not AE member", state, 100);

        map<string, vector<map<string, bool> > >::const_iterator itVList = BanVoteList.find(receiverAddr);
        if (itVList != BanVoteList.end() && itVList->second.size() != 0) {
            map<string, bool>::const_iterator itVLVM = itVList->second.back().find(senderAddr);
            if (itVLVM == itVList->second.back().end())
                return RejectInvalidTypeTx("no sender address", state, 100);
            if (itVLVM->second) {
                if (itVList->second.back().size() == alliance_member::NumOfMembers()) {
                    map<string, bool>::const_iterator it_v, it_v_end;
                    alliance_member::CIterator it_m, it_m_end;
                    it_v = itVList->second.back().begin();
                    it_v_end = itVList->second.back().end();
                    it_m = alliance_member::IteratorBegin();
                    it_m_end = alliance_member::IteratorEnd();
                    bool fDiff = false;
                    for ( ; it_m != it_m_end && it_v != it_v_end; ++it_v, ++it_m) {
                        if (*it_m != it_v->first) {
                            fDiff = true;
                            break;
                        }
                    }
                    if (!fDiff) {
                        CCoinsViewCache view(*pcoinsTip, true);
                        if (view.HaveCoins(tx.GetHash())) {
                            LogPrintf("Warning : Already have this ban-vote tx(may cause by block forking).\n");
                        } else {
                            return RejectInvalidTypeTx("ban-voted", state, 100);
                        }
                    }
                }
            }
        }
        return true;
    };

    bool CheckFormat(const CTransaction &tx, CValidationState &state,
                    const CBlock *pblock)
    {
        if (tx.color != 0)
            return RejectInvalidTypeTx("color must be 0", state, 100);

        // for ban-vote type tx, output size must be 1 and
        // vout[0].nValue must be 1
        if (tx.vout.size() == 1) {
            if (tx.vout[0].nValue != COIN)
                return RejectInvalidTypeTx("out[0].nValue != COIN", state, 100);
        } else {
            return RejectInvalidTypeTx("size of output != 1", state, 100);
        }
        return true;
    }

    bool Apply(CBlock *pblock, const CTransaction &tx)
    {
        LOCK(cs_main);
        string candidates = GetTxOutputAddr(tx, 0);
        string voter = GetTxInputAddr(tx, pblock);

        map<string, vector<map<string, bool> > >::iterator itVList = BanVoteList.find(candidates);
        map<string, bool>::iterator itVLVM;
        if (itVList == BanVoteList.end()) {
            itVList = CreateTheBilling_(candidates, BanVoteList);
        } else {
            if (itVList->second.size() == 0) {
                LogPrintf("%s() fail : BanVoteList went wrong (this should not happen)\n", __func__);
                return error("%s() : Handle Vote failed", __func__);
            }
            itVLVM = itVList->second.back().find(voter);
            if (itVLVM == itVList->second.back().end()) {
                LogPrintf("%s() fail : voter \"%s\" is not an AE\n", __func__, voter);
                return error("%s() : Handle Vote failed", __func__);
            } else if (itVLVM->second) {
                itVList = CreateTheBilling_(candidates, BanVoteList);
            }
        }

        if (itVList->second.size() == 0) {
            LogPrintf("%s() fail : BanVoteList went wrong (this should not happen)\n", __func__);
            return error("%s() : Handle Vote failed", __func__);
        }

        itVLVM = itVList->second.back().find(voter);
        if (itVLVM == itVList->second.back().end()) {
            LogPrintf("%s() fail : voter \"%s\" is not an AE\n", __func__, voter);
            return error("%s() : Handle Vote failed", __func__);
        }

        itVLVM->second = true;
        // check if vote pass
        uint32_t agree_cnt = 0;
        for (map<string, bool>::iterator it = itVList->second.back().begin(); it != itVList->second.back().end(); it++) {
            if (it->second)
                agree_cnt++;
        }
        // result : pass
        if (agree_cnt > (alliance_member::NumOfMembers() - 1) / 2) {
            alliance_member::Remove(candidates);
            RemoveVoter_(candidates);
        }
        return true;
    }

    bool Undo(const CTransaction &tx, CBlock &block)
    {
        string candidate = GetTxOutputAddr(tx, 0);
        string voter = GetTxInputAddr(tx, &block);

        // fetch the latest voting result, which is the one that counts.
        map<string, vector<map<string, bool> > >::iterator itVList = BanVoteList.find(candidate);
        if (itVList == BanVoteList.end() || itVList->second.size() == 0) {
            LogPrintf("%s () fail : BanVoteList went wrong (this should not happen)\n", __func__);
            return false;
        }

        map<string, bool> &latestVoting = itVList->second.back();
        map<string, bool>::iterator itVLVM = latestVoting.find(voter);
        if (itVLVM == latestVoting.end()) {
            LogPrintf("%s () fail : latestVoting went wrong (this should not happen)\n", __func__);
            return false;
        }

        // undo the ban-vote in BanVoteList
        itVLVM->second = false;

        // see how many votes the candidate has received now.
        uint32_t agree_cnt = 0;
        for (map<string, bool>::iterator it = latestVoting.begin(); it != latestVoting.end(); it++)
            if (it->second)
                agree_cnt++;

        // update the MemberList.
        // if agree_cnt <= MemberList.size(),
        // delete the candidate from the MemberList.
        // TODO : confirm the condition to be the in MemberList
        if (agree_cnt <= (latestVoting.size() - 1) / 2)
            alliance_member::Add(candidate);
        return true;
    }

    bool CheckNotRepeated(const CTransaction &tx, const CTransaction &pool_tx,
                          CValidationState &state)
    {
        string txSenderAddr = GetTxInputAddr(tx, NULL);
        string txReceiverAddr = GetTxOutputAddr(tx, 0);
        string poolTxSenderAddr = GetTxInputAddr(pool_tx, NULL);
        string poolTxReceiverAddr = GetTxOutputAddr(pool_tx, 0);
        if (txReceiverAddr == poolTxReceiverAddr &&
            txSenderAddr == poolTxSenderAddr)
            return RejectInvalidTypeTx(
                    "voted for same candidate : in memory conflict", state, 50);
        return true;
    }

private:

    map<string, vector<map<string, bool> > >::iterator CreateTheBilling_(string &candidates, map<string, vector<map<string, bool> > > &VList)
    {
        map<string, vector<map<string, bool> > >::iterator itRet = VList.find(candidates);
        if (itRet == VList.end()) {
            itRet = (VList.insert(make_pair(candidates, vector<map<string, bool> >()))).first;
        }

        map<string, bool> List;
        for (alliance_member::CIterator it = alliance_member::IteratorBegin();
             it != alliance_member::IteratorEnd();
             ++it) {
            List.insert(make_pair(*it, false));
        }

        itRet->second.push_back(List);
        return itRet;
    }

    void RemoveVoter_(string &candidate)
    {
        string receiver;
        map<string, vector<map<string, bool> > >::iterator itVList;
        map<string, bool>::iterator itVLVM;
        // Inactivate Votelist contains banned AE as a Candidate
        CreateTheBilling_(candidate, VoteList);
        // Inactivate BanVotelist contains banned AE as a Candidate
        CreateTheBilling_(candidate, BanVoteList);
        // Search and inactivate Votelist contains banned AE as a Voter
        for (itVList = VoteList.begin(); itVList != VoteList.end(); itVList++) {
            for (itVLVM = itVList->second.back().begin(); itVLVM != itVList->second.back().end(); itVLVM++) {
                if (itVLVM->first == candidate) {
                    receiver = itVList->first;
                    itVList = CreateTheBilling_(receiver, VoteList);
                    break;
                }
            }
        }

        // Search and inactivate BanVotelist contains banned AE as a Voter
        for (itVList = BanVoteList.begin(); itVList != BanVoteList.end(); itVList++) {
            for (itVLVM = itVList->second.back().begin(); itVLVM != itVList->second.back().end(); itVLVM++) {
                if (itVLVM->first == candidate) {
                    receiver = itVList->first;
                    itVList = CreateTheBilling_(receiver, BanVoteList);
                    break;
                }
            }
        }
    }
};

class Handler_BanAddr_ : public HandlerInterface, public HandlerUtility_
{
public:
    Handler_BanAddr_() : HandlerUtility_(BANADDR) {}

    bool CheckValid(const CTransaction &tx, CValidationState &state,
                    const CBlock *pblock)
    {
        bool fUseMempool = (pblock == NULL);

        string senderAddr = GetTxInputAddr(tx, pblock);
        string receiverAddr = GetTxOutputAddr(tx, 0);
        if (!alliance_member::IsMember(senderAddr))
            return RejectInvalidTypeTx("sender not AE", state, 100);

        if (ban_address::IsBanned(receiverAddr))
            return RejectInvalidTypeTx("already banned", state, 50);

        // input of BANADDR type must be MINT type and color 0
        BOOST_FOREACH(const CTxIn txin, tx.vin) {
            CCoins coins;
            if (!GetCoinsFromCache(txin.prevout, coins, fUseMempool))
                return RejectInvalidTypeTx("fetch input tx failed", state, 50);
            if (coins.type != MINT || coins.color != 0)
                return RejectInvalidTypeTx(
                        "input must be MINT and color 0", state, 100);
        }
        return true;
    };

    bool CheckFormat(const CTransaction &tx, CValidationState &state,
                    const CBlock *pblock)
    {
        if (tx.color != 0)
            return RejectInvalidTypeTx("color must be 0", state, 100);

        // for ban address type tx, output size must be 1 and
        // vout[0].nValue must be 1
        if (tx.vout.size() == 1) {
            if (tx.vout[0].nValue != COIN)
                return RejectInvalidTypeTx("out[0].nValue != COIN", state, 100);
        } else {
            return RejectInvalidTypeTx("size of output != 1", state, 100);
        }
        return true;
    }

    bool Apply(CBlock *pblock, const CTransaction &tx)
    {
        ban_address::Add(GetTxOutputAddr(tx, 0));
        return true;
    }

    bool Undo(const CTransaction &tx, CBlock &block)
    {
        ban_address::Remove(GetTxOutputAddr(tx, 0));
        return true;
    }

    bool CheckNotRepeated(const CTransaction &tx, const CTransaction &pool_tx,
                          CValidationState &state)
    {
        string txReceiverAddr = GetTxOutputAddr(tx, 0);
        string poolTxReceiverAddr = GetTxOutputAddr(pool_tx, 0);
        if (txReceiverAddr == poolTxReceiverAddr)
            return RejectInvalidTypeTx(
                    "banned for same address " + txReceiverAddr, state, 50);
        return true;
    }
};


class Handler_BanColor_ : public HandlerInterface, public HandlerUtility_
{
public:
    Handler_BanColor_() : HandlerUtility_(BANCOLOR) {}

    bool CheckValid(const CTransaction &tx, CValidationState &state,
                    const CBlock *pblock)
    {
        bool fUseMempool = (pblock == NULL);

        string senderAddr = GetTxInputAddr(tx, pblock);
        string receiverAddr = GetTxOutputAddr(tx, 0);
        if (!alliance_member::IsMember(senderAddr))
            return RejectInvalidTypeTx("sender not AE member", state, 100);

        if (ban_color::IsBanned(tx.color))
            return RejectInvalidTypeTx("already banned", state, 100);

        if (!color_license::IsExist(tx.color)) {
            return RejectInvalidTypeTx("not existing color", state, 100);
        } else if (!color_license::IsOwner(tx.color, receiverAddr)) {
            return RejectInvalidTypeTx(
                    "receiver don't have license", state, 100);
        }

        // input of BANCOLOR type must be MINT type and its color must be 0
        BOOST_FOREACH(const CTxIn txin, tx.vin) {
            CCoins coins;
            if (!GetCoinsFromCache(txin.prevout, coins, fUseMempool))
                return RejectInvalidTypeTx("fetch input tx failed", state, 50);
            if (coins.type != MINT || coins.color != 0)
                return RejectInvalidTypeTx(
                        "input must be MINT type and color 0", state, 100);
        }
        return true;
    };

    bool CheckFormat(const CTransaction &tx, CValidationState &state,
                    const CBlock *pblock)
    {
        // for ban color type tx, output size must be 1, and vout[0].nValue must be 1
        if (tx.vout.size() == 1) {
            if (tx.vout[0].nValue != COIN)
                return RejectInvalidTypeTx("out[0].nValue != COIN", state, 100);
        } else {
            return RejectInvalidTypeTx("size of output != 1", state, 100);
        }
        return true;
    }

    bool Apply(CBlock *pblock, const CTransaction &tx)
    {
        if (!color_license::IsExist(tx.color))
            return error("%s() : not existing color %u", __func__, tx.color);
        ban_color::Add(tx.color);
        return true;
    }

    bool Undo(const CTransaction &tx, CBlock &block)
    {
        ban_color::Remove(tx.color);
        return true;
    }

    bool CheckNotRepeated(const CTransaction &tx, const CTransaction &pool_tx,
                          CValidationState &state)
    {
        if (pool_tx.color == tx.color)
            return RejectInvalidTypeTx(
                    strprintf("color %u banned : in memory conflict", tx.color),
                    state, 50);
        return true;
    }
};


class Handler_InvalidType_ : public HandlerInterface, public HandlerUtility_
{
public:
    Handler_InvalidType_() : HandlerUtility_(UNKNOWN) {}

    bool CheckValid(const CTransaction &tx, CValidationState &state,
                    const CBlock *pblock)
    {
        return false;
    }

    bool CheckFormat(const CTransaction &tx, CValidationState &state,
                    const CBlock *pblock)
    {
        return RejectInvalidTypeTx("", state, 100);
    }

    bool Apply(CBlock *pblock, const CTransaction &tx)
    {
        return false;
    }

    bool Undo(const CTransaction &tx, CBlock &block)
    {
        return false;
    }

    bool CheckNotRepeated(const CTransaction &tx, const CTransaction &pool_tx,
                          CValidationState &state)
    {
        return false;
    }
};


Handler_Normal_ handler_normal_;
Handler_Mint_ handler_mint_;
Handler_License_ handler_license_;
Handler_RevokeLicense_ handler_revoke_license_;
Handler_Vote_ handler_vote_;
Handler_BanAddr_ handler_ban_addr_;
Handler_BanColor_ handler_ban_color_;
Handler_BanVote_ handler_ban_vote_;
Handler_InvalidType_ handler_invalid_type_;

}  // namespace


HandlerInterface *GetHandler(const tx_type &type)
{
    switch (type) {
        case NORMAL:
            return &handler_normal_;
        case MINT:
            return &handler_mint_;
        case LICENSE:
            return &handler_license_;
        case REVOKELICENSE:
            return &handler_revoke_license_;
        case VOTE:
            return &handler_vote_;
        case BANADDR:
            return &handler_ban_addr_;
        case BANCOLOR:
            return &handler_ban_color_;
        case BANVOTE:
            return &handler_ban_vote_;
        default:
            return &handler_invalid_type_;
    }
}


bool GeneralCheckValid(const CTransaction& tx, CValidationState &state,
                       const CBlock *pblock)
{
    string senderAddr = tx.IsCoinBase() ? "" : GetTxInputAddr(tx, pblock);
    string receiverAddr = GetTxOutputAddr(tx, 0);

    if (senderAddr == "" && !tx.IsCoinBase())
        return RejectInvalidTypeTx_(
                tx.type, __func__, "can't fetch sender address", state, 100);

    if (receiverAddr == "")
        return RejectInvalidTypeTx_(
                tx.type, __func__, "can't fetch receiver address", state, 100);

    string banned_reason = string(BAD_TXNS_TYPE_) + "BANNED";

    if (ban_address::IsBanned(senderAddr))
        return RejectInvalidTypeTx_(
                tx.type, __func__,
                strprintf("You(%s) are banned from the network", senderAddr),
                state, 50, banned_reason);

    if (ban_address::IsBanned(receiverAddr))
        return RejectInvalidTypeTx_(
                tx.type, __func__,
                strprintf("Target(%s) are banned from the network", receiverAddr),
                state, 10, banned_reason);

    if (ban_color::IsBanned(tx.color))
        return RejectInvalidTypeTx_(
                tx.type, __func__, "color was banned", state, 10, banned_reason);

    return true;
}

}  // namespace type_transaction_handler


namespace
{

struct CCachedAddress
{
    uint256 tx_hash;
    string address;

    CCachedAddress(uint256 fake_hash_value) : tx_hash(fake_hash_value) {}
};

struct CCachedOutputAddress : CCachedAddress
{
    size_t index;

    CCachedOutputAddress(uint256 fake_hash_value) :
            CCachedAddress(fake_hash_value) {}
};

}  // namespace


string GetTxOutputAddr(const CTransaction& tx, size_t index)
{
    static boost::thread_specific_ptr<CCachedOutputAddress> cache;
    if (index >= tx.vout.size())
        return "";
    if (cache.get() == NULL) {
        cache.reset(new CCachedOutputAddress(~tx.GetHash()));
    }
    if (cache.get()->tx_hash != tx.GetHash() || cache.get()->index != index) {
        cache.get()->tx_hash = tx.GetHash();
        cache.get()->index = index;
        cache.get()->address = GetDestination(tx.vout[index].scriptPubKey);
    }
    return cache.get()->address;
}


string GetTxInputAddr(const CTransaction& tx, const CBlock *pblock)
{
    static boost::thread_specific_ptr<CCachedAddress> cache;
    if (tx.vin.size() == 0)
        return "";
    if (cache.get() == NULL) {
        cache.reset(new CCachedAddress(~tx.GetHash()));
    }

    bool fUseMempool = (pblock == NULL);

    if (cache.get()->tx_hash != tx.GetHash()) {
        cache.get()->tx_hash = tx.GetHash();

        CCoins coins;
        if (!GetCoinsFromCache(tx.vin[0].prevout, coins, fUseMempool)) {
            cache.get()->address = "";
        } else {
            cache.get()->address = GetDestination(
                    coins.vout[tx.vin[0].prevout.n].scriptPubKey);
        }
    }

    return cache.get()->address;
}


/**
 * NEW FUNCTION: CheckTransactionType, added by Yen-Chieh
 * Called by AcceptToMemoryPool and ConnectBlock
 */
bool CheckTransactionType(const CTransaction& tx, CValidationState &state,
                          const CBlock *pblock, bool fNCheckFork)
{

    if (!type_transaction_handler::GeneralCheckValid(tx, state, pblock)) {
        return false;
    }

    if (!type_transaction_handler::GetHandler(tx.type)->CheckFormat(
            tx, state, pblock)) {
        return false;
    }

    if(fNCheckFork)
        return true;

    if (!type_transaction_handler::GetHandler(tx.type)->CheckValid(
            tx, state, pblock)) {
        return false;
    }
    return true;
}


bool CheckRepeatedTypeTransactionInPool(
        CTxMemPool& pool, CValidationState &state, const CTransaction &tx)
{
    typedef map<uint256, CTxMemPoolEntry>::value_type CMapTxIter;
    BOOST_FOREACH(CMapTxIter it, pool.mapTx) {
        if (tx.type != it.second.GetTx().type) {
            continue;
        }
        if (!type_transaction_handler::GetHandler(tx.type)->CheckNotRepeated(
                tx, it.second.GetTx(), state)) {
            return false;
        }
    }
    return true;
}

#endif  // ENABLE_GCOIN

bool AcceptToMemoryPool(CTxMemPool& pool, CValidationState &state, const CTransaction &tx, bool fLimitFree,
                        bool* pfMissingInputs, bool fRejectInsaneFee, bool fDisconnect)
{
    LogPrintf("ACCEPTTOMEMORYPOOL\n");
    AssertLockHeld(cs_main);
    if (pfMissingInputs)
        *pfMissingInputs = false;

    if (!CheckTransaction(tx, state))
        return error("%s: CheckTransaction failed", __func__);

#ifdef ENABLE_GCOIN
    // allow coinbase tx to enable issuer can mint it own coin
    if (tx.IsCoinBase() && tx.type != MINT)
        return state.DoS(100, error("%s: coinbase as individual tx", __func__),
                         REJECT_INVALID, "coinbase");

#else
    if (tx.IsCoinBase())
        return state.DoS(100, error("%s: coinbase as individual tx", __func__),
                         REJECT_INVALID, "coinbase");
#endif // ENABLE_GCOIN

    // Rather not work on nonstandard transactions (unless -testnet/-regtest)
    string reason;
    if (Params().RequireStandard() && !IsStandardTx(tx, reason))
        return state.DoS(0,
                         error("%s: nonstandard transaction: %s", __func__, reason),
                         REJECT_NONSTANDARD, reason);

    // is it already in the memory pool?
    uint256 hash = tx.GetHash();
    if (pool.exists(hash)) {
        LogPrintf("%s: pool exist\n", __func__);
        return false;
    }

    // Check for conflicts with in-memory transactions
    {
        LOCK(pool.cs); // protect pool.mapNextTx
        for (unsigned int i = 0; i < tx.vin.size(); i++) {
            COutPoint outpoint = tx.vin[i].prevout;
            if (pool.mapNextTx.count(outpoint)) {
                LogPrintf("input %d are not avaible now\n",i);
                // Disable replacement feature for now
                return false;
            }
        }

#ifdef  ENABLE_GCOIN
        /**
         *  check if this color license or vote is already in mempool.
         */
        if (!CheckRepeatedTypeTransactionInPool(pool, state, tx)) {
            LogPrintf("%s: CheckRepeatedTypeTransactionInPool fail\n", __func__);
            return false;
        }
#endif  // ENABLE_GCOIN
    }

    {
        CCoinsView dummy;
        CCoinsViewCache view(dummy);

        int64_t nValueIn = 0;
        {
        LOCK(pool.cs);
        CCoinsViewMemPool viewMemPool(*pcoinsTip, pool);
        view.SetBackend(viewMemPool);

        // do we already have it?
        if (view.HaveCoins(hash)) {
            LogPrintf("%s: Already have it\n", __func__);
            return false;
        }

        CTransaction wtx;
        uint256 hashtmp = 0;
        if (tx.type == MINT && !fDisconnect) {
            if (GetTransaction(hash, wtx, hashtmp, NULL, true)) {
                LogPrintf("%s: GetTransaction fail\n", __func__);
                return false;
            }
        }

        CCoins coins;
        bool check = true;
        if (tx.type == NORMAL) {
            BOOST_FOREACH(const CTxIn txin, tx.vin) {
                if (!GetCoinsFromCache(txin.prevout, coins, true)) {
                    if (pfMissingInputs == NULL)
                        return state.DoS(50, error("%s: NORMAL transaction invalid (fetch input failed)", __func__),
                                         REJECT_INVALID, "bad-txns-type-NORMAL");
                    else
                        check = false;
                }
                if (check && coins.color != tx.color)
                    return state.DoS(100, error("%s: NORMAL transaction invalid (color change)", __func__),
                                     REJECT_INVALID, "bad-txns-type-NORMAL");
            }
        }
        if (check && !CheckTransactionType(tx, state))
            return error("%s: CheckTransactionType failed", __func__);

        // do all inputs exist?
        // Note that this does not check for the presence of actual outputs (see the next check for that),
        // only helps filling in pfMissingInputs (to determine missing vs spent).
        // mint tx dont need to check input.
        if (tx.type != MINT) {
            BOOST_FOREACH(const CTxIn txin, tx.vin) {
                if (!view.HaveCoins(txin.prevout.hash)) {
                    if (pfMissingInputs)
                        *pfMissingInputs = true;
                    LogPrintf("%s: input not exist\n", __func__);
                    return false;
                }
            }
        }
        // are the actual inputs available?
        if (!view.HaveInputs(tx))
            return state.Invalid(error("%s: inputs already spent", __func__),
                                 REJECT_DUPLICATE, "bad-txns-inputs-spent");

        // Bring the best block into scope
        view.GetBestBlock();

        nValueIn = view.GetValueIn(tx);

        // we have all inputs cached now, so switch back to dummy, so we don't need to keep lock on mempool
        view.SetBackend(dummy);
        }

        // Check for non-standard pay-to-script-hash in inputs
        if (Params().RequireStandard() && !AreInputsStandard(tx, view))
            return error("%s: nonstandard transaction input", __func__);

        // Check that the transaction doesn't have an excessive number of
        // sigops, making it impossible to mine. Since the coinbase transaction
        // itself can contain sigops MAX_TX_SIGOPS is less than
        // MAX_BLOCK_SIGOPS; we still consider this an invalid rather than
        // merely non-standard transaction.
        unsigned int nSigOps = GetLegacySigOpCount(tx);
        nSigOps += GetP2SHSigOpCount(tx, view);
        if (nSigOps > MAX_TX_SIGOPS)
            return state.DoS(0,
                             error("%s: too many sigops %s, %d > %d",
                                 __func__, hash.ToString(), nSigOps, MAX_TX_SIGOPS),
                             REJECT_NONSTANDARD, "bad-txns-too-many-sigops");

        int64_t nValueOut = tx.GetValueOut();
        int64_t nFees = nValueIn-nValueOut;
        double dPriority = view.GetPriority(tx, chainActive.Height());

        CTxMemPoolEntry entry(tx, nFees, GetTime(), dPriority, chainActive.Height());
        unsigned int nSize = entry.GetTxSize();

        // Don't accept it if it can't get into a block
        int64_t txMinFee = GetMinRelayFee(tx, nSize, true);
        // FIXME:
        // modified by Mai-Hsuan to let the coinbase transaction accepted to mempool
        if (!tx.IsCoinBase()) {
            if (fLimitFree && nFees < txMinFee)
                return state.DoS(0, error("%s: not enough fees %s, %d < %d",
                            __func__, hash.ToString(), nFees, txMinFee),
                        REJECT_INSUFFICIENTFEE, "insufficient fee");
        }

        // Check against previous transactions
        // This is done last to help prevent CPU exhaustion denial-of-service attacks.
        if (!CheckInputs(tx, state, view, true, STANDARD_SCRIPT_VERIFY_FLAGS))
            return error("%s: ConnectInputs failed %s", __func__, hash.ToString());
        // Store transaction in memory
        pool.addUnchecked(hash, entry);
    }

    SyncWithWallets(tx, NULL);

    return true;
}


int CMerkleTx::GetDepthInMainChainINTERNAL(CBlockIndex* &pindexRet) const
{
    if (hashBlock == 0 || nIndex == -1)
        return 0;
    AssertLockHeld(cs_main);

    // Find the block it claims to be in
    map<uint256, CBlockIndex*>::iterator mi = mapBlockIndex.find(hashBlock);
    if (mi == mapBlockIndex.end())
        return 0;
    CBlockIndex* pindex = (*mi).second;
    if (!pindex || !chainActive.Contains(pindex))
        return 0;

    // Make sure the merkle branch connects to this block
    if (!fMerkleVerified) {
        if (CBlock::CheckMerkleBranch(GetHash(), vMerkleBranch, nIndex) != pindex->hashMerkleRoot)
            return 0;
        fMerkleVerified = true;
    }

    pindexRet = pindex;
    return chainActive.Height() - pindex->nHeight + 1;
}

int CMerkleTx::GetDepthInMainChain(CBlockIndex* &pindexRet) const
{
    AssertLockHeld(cs_main);
    int nResult = GetDepthInMainChainINTERNAL(pindexRet);
    if (nResult == 0 && !mempool.exists(GetHash()))
        return -1; // Not in chain, not in mempool

    return nResult;
}

int CMerkleTx::GetBlocksToMaturity() const
{
    if (!IsCoinBase())
        return 0;
    return std::max(0, (COINBASE_MATURITY+1) - GetDepthInMainChain());
}


bool CMerkleTx::AcceptToMemoryPool(bool fLimitFree, bool fRejectInsaneFee)
{
    CValidationState state;
    return ::AcceptToMemoryPool(mempool, state, *this, fLimitFree, NULL, fRejectInsaneFee);
}

/*!
 * @brief Get a CCoins from mempool or utxo database.
 * @param [in] output which you want to get.
 * @param [in] CCoins reference to be filled in.
 * @param [in] flag to indicate whether find the coins from the mempool first.
 * @return True if we successfully get the coins, otherwise False.
 */
bool GetCoinsFromCache(const COutPoint &outpoint, CCoins &coins, bool fUseMempool)
{
#ifdef ENABLE_GCOIN
    if (AlternateFunc_GetCoinsFromCache != NULL) {
        return AlternateFunc_GetCoinsFromCache(outpoint, coins, fUseMempool);
    }
#endif  // ENABLE_GCOIN

    CCoinsView dummy;
    CCoinsViewCache view(dummy);
    {
        LOCK(mempool.cs);

        // setup uxto database and mempool for view and switch view's backend.
        CCoinsViewMemPool viewMempoolAndDatabase(*pcoinsTip, mempool);
        CCoinsViewCache viewDatabaseOnly(*pcoinsTip, true);
        if (fUseMempool)
            view.SetBackend(viewMempoolAndDatabase);
        else
            view.SetBackend(viewDatabaseOnly);

        if (!view.GetCoins(outpoint.hash, coins) || !coins.IsAvailable(outpoint.n))
            return false;

        view.SetBackend(dummy); // switch back.
    }

    return true;
}

// Return transaction in tx, and if it was found inside a block, its hash is placed in hashBlock
bool GetTransaction(const uint256 &hash, CTransaction &txOut, uint256 &hashBlock, const CBlock *pblock,  bool fAllowSlow)
{
#ifdef ENABLE_GCOIN
    if (AlternateFunc_GetTransaction != NULL) {
        return AlternateFunc_GetTransaction(
                hash, txOut, hashBlock, pblock, fAllowSlow);
    }
#endif  // ENABLE_GCOIN
    CBlockIndex *pindexSlow = NULL;
    {
        LOCK(cs_main);
        if (mempool.lookup(hash, txOut))
            return true;

        // pre tx of tx may be collected in same block, so we need to check block
        if (pblock != NULL) {
            BOOST_FOREACH(const CTransaction &tx, pblock->vtx) {
                if (tx.GetHash() == hash) {
                    hashBlock = pblock->GetHash();
                    txOut = tx;
                    return true;
                }
            }
        }
        if (fTxIndex) {
            CDiskTxPos postx;
            if (pblocktree->ReadTxIndex(hash, postx)) {
                CAutoFile file(OpenBlockFile(postx, true), SER_DISK, CLIENT_VERSION);
                CBlockHeader header;
                try {
                    file >> header;
                    fseek(file, postx.nTxOffset, SEEK_CUR);
                    file >> txOut;
                } catch (exception &e) {
                    return error("%s : Deserialize or I/O error - %s", __func__, e.what());
                }
                hashBlock = header.GetHash();
                if (txOut.GetHash() != hash)
                    return error("%s : txid mismatch", __func__);
                return true;
            }
        }

        if (fAllowSlow) { // use coin database to locate block that contains transaction, and scan it
            int nHeight = -1;
            CCoinsViewCache &view = *pcoinsTip;
            CCoins coins;
            if (view.GetCoins(hash, coins))
                nHeight = coins.nHeight;
            if (nHeight > 0)
                pindexSlow = chainActive[nHeight];
        }
    }

    if (pindexSlow) {
        CBlock block;
        if (ReadBlockFromDisk(block, pindexSlow)) {
            BOOST_FOREACH(const CTransaction &tx, block.vtx) {
                if (tx.GetHash() == hash) {
                    txOut = tx;
                    hashBlock = pindexSlow->GetBlockHash();
                    return true;
                }
            }
        }
    } else {
        for (CBlockIndex* pindex = chainActive.Genesis(); pindex; pindex = chainActive.Next(pindex)) {
            CBlock block;
            if (ReadBlockFromDisk(block, pindex)) {
                BOOST_FOREACH(const CTransaction &tx, block.vtx) {
                    if (tx.GetHash() == hash) {
                        txOut = tx;
                        hashBlock = pindex->GetBlockHash();
                        return true;
                    }
                }
            }
        }
    }

    return false;
}






//////////////////////////////////////////////////////////////////////////////
//
// CBlock and CBlockIndex
//

bool WriteBlockToDisk(CBlock& block, CDiskBlockPos& pos)
{
    // Open history file to append
    CAutoFile fileout = CAutoFile(OpenBlockFile(pos), SER_DISK, CLIENT_VERSION);
    if (!fileout)
        return error("%s: OpenBlockFile failed", __func__);

    // Write index header
    unsigned int nSize = fileout.GetSerializeSize(block);
    fileout << FLATDATA(Params().MessageStart()) << nSize;

    // Write block
    long fileOutPos = ftell(fileout);
    if (fileOutPos < 0)
        return error("%s: ftell failed", __func__);
    pos.nPos = (unsigned int)fileOutPos;
    fileout << block;

    // Flush stdio buffers and commit to disk before returning
    fflush(fileout);
    if (!IsInitialBlockDownload())
        FileCommit(fileout);

    return true;
}

bool ReadBlockFromDisk(CBlock& block, const CDiskBlockPos& pos)
{
    block.SetNull();

    // Open history file to read
    CAutoFile filein = CAutoFile(OpenBlockFile(pos, true), SER_DISK, CLIENT_VERSION);
    if (!filein)
        return error("%s: OpenBlockFile failed", __func__);

    // Read block
    try {
        filein >> block;
    } catch (exception &e) {
        return error("%s : Deserialize or I/O error - %s", __func__, e.what());
    }

    // Check the header
    if (!CheckProofOfWork(block.GetHash(), block.nBits))
        return error("%s: Errors in block header", __func__);

    return true;
}

bool ReadBlockFromDisk(CBlock& block, const CBlockIndex* pindex)
{
    if (!ReadBlockFromDisk(block, pindex->GetBlockPos()))
        return false;
    if (block.GetHash() != pindex->GetBlockHash())
        return error("%s(CBlock&, CBlockIndex*) : GetHash() doesn't match index", __func__);
    return true;
}

uint256 static GetOrphanRoot(const uint256& hash)
{
    map<uint256, COrphanBlock*>::iterator it = mapOrphanBlocks.find(hash);
    if (it == mapOrphanBlocks.end())
        return hash;

    // Work back to the first block in the orphan chain
    do {
        map<uint256, COrphanBlock*>::iterator it2 = mapOrphanBlocks.find(it->second->hashPrev);
        if (it2 == mapOrphanBlocks.end())
            return it->first;
        it = it2;
    } while(true);
}

// Remove a random orphan block (which does not have any dependent orphans).
void static PruneOrphanBlocks()
{
    if (mapOrphanBlocksByPrev.size() <= (size_t)std::max((int64_t)0, GetArg("-maxorphanblocks", DEFAULT_MAX_ORPHAN_BLOCKS)))
        return;

    // Pick a random orphan block.
    int pos = insecure_rand() % mapOrphanBlocksByPrev.size();
    multimap<uint256, COrphanBlock*>::iterator it = mapOrphanBlocksByPrev.begin();
    while (pos--) it++;

    // As long as this block has other orphans depending on it, move to one of those successors.
    do {
        multimap<uint256, COrphanBlock*>::iterator it2 = mapOrphanBlocksByPrev.find(it->second->hashBlock);
        if (it2 == mapOrphanBlocksByPrev.end())
            break;
        it = it2;
    } while(1);

    uint256 hash = it->second->hashBlock;
    delete it->second;
    mapOrphanBlocksByPrev.erase(it);
    mapOrphanBlocks.erase(hash);
}

// TODO: Remove this function.
int64_t GetBlockValue(int nHeight, int64_t nFees)
{
    /**
     * now, we have no mining reward except tx fee.
     * and we support multiple minter so we dont need to premine coins anymore.
     */

    /*
    int64_t max_coin = GetArg("-maxmint", 10000000000000000 );
    int64_t nSubsidy = max_coin * COIN;
    int halvings = nHeight / Params().SubsidyHalvingInterval();

    // Force block reward to zero when right shift is undefined.
    if (halvings >= 2)
        return nFees;

    // Subsidy is cut in half every 210,000 blocks which will occur approximately every 4 years.
    //nSubsidy >>= halvings;

    return nSubsidy + nFees;
    */
    return nFees;
}

bool IsInitialBlockDownload()
{
    LOCK(cs_main);
    if (fImporting || fReindex || chainActive.Height() < Checkpoints::GetTotalBlocksEstimate())
        return true;
    static int64_t nLastUpdate;
    static CBlockIndex* pindexLastBest;
    if (chainActive.Tip() != pindexLastBest) {
        pindexLastBest = chainActive.Tip();
        nLastUpdate = GetTime();
    }
    return (GetTime() - nLastUpdate < 10 &&
            chainActive.Tip()->GetBlockTime() < GetTime() - 24 * 60 * 60);
}

bool fLargeWorkForkFound = false;
bool fLargeWorkInvalidChainFound = false;
CBlockIndex *pindexBestForkTip = NULL, *pindexBestForkBase = NULL;

void CheckForkWarningConditions()
{
    AssertLockHeld(cs_main);
    // Before we get past initial download, we cannot reliably alert about forks
    // (we assume we don't get stuck on a fork before the last checkpoint)
    if (IsInitialBlockDownload())
        return;

    // If our best fork is no longer within 72 blocks (+/- 12 hours if no one mines it)
    // of our head, drop it
    if (pindexBestForkTip && chainActive.Height() - pindexBestForkTip->nHeight >= 72)
        pindexBestForkTip = NULL;

    if (pindexBestForkTip || (pindexBestInvalid && pindexBestInvalid->nChainWork > chainActive.Tip()->nChainWork + (chainActive.Tip()->GetBlockWork() * 6))) {
        if (!fLargeWorkForkFound) {
            string strCmd = GetArg("-alertnotify", "");
            if (!strCmd.empty()) {
                string warning = string("'Warning: Large-work fork detected, forking after block ") +
                                      pindexBestForkBase->phashBlock->ToString() + string("'");
                boost::replace_all(strCmd, "%s", warning);
                boost::thread t(runCommand, strCmd); // thread runs free
            }
        }
        if (pindexBestForkTip) {
            LogPrintf("%s: Warning: Large valid fork found\n  forking the chain at height %d (%s)\n  lasting to height %d (%s).\nChain state database corruption likely.\n",
                   __func__,
                   pindexBestForkBase->nHeight, pindexBestForkBase->phashBlock->ToString(),
                   pindexBestForkTip->nHeight, pindexBestForkTip->phashBlock->ToString());
            fLargeWorkForkFound = true;
        } else {
            LogPrintf("%s: Warning: Found invalid chain at least ~6 blocks longer than our best chain.\nChain state database corruption likely.\n", __func__);
            fLargeWorkInvalidChainFound = true;
        }
    } else {
        fLargeWorkForkFound = false;
        fLargeWorkInvalidChainFound = false;
    }
}

void CheckForkWarningConditionsOnNewFork(CBlockIndex* pindexNewForkTip)
{
    AssertLockHeld(cs_main);
    // If we are on a fork that is sufficiently large, set a warning flag
    CBlockIndex* pfork = pindexNewForkTip;
    CBlockIndex* plonger = chainActive.Tip();
    while (pfork && pfork != plonger) {
        while (plonger && plonger->nHeight > pfork->nHeight)
            plonger = plonger->pprev;
        if (pfork == plonger)
            break;
        pfork = pfork->pprev;
    }

    // We define a condition which we should warn the user about as a fork of at least 7 blocks
    // who's tip is within 72 blocks (+/- 12 hours if no one mines it) of ours
    // We use 7 blocks rather arbitrarily as it represents just under 10% of sustained network
    // hash rate operating on the fork.
    // or a chain that is entirely longer than ours and invalid (note that this should be detected by both)
    // We define it this way because it allows us to only store the highest fork tip (+ base) which meets
    // the 7-block condition and from this always have the most-likely-to-cause-warning fork
    if (pfork && (!pindexBestForkTip || (pindexBestForkTip && pindexNewForkTip->nHeight > pindexBestForkTip->nHeight)) &&
            pindexNewForkTip->nChainWork - pfork->nChainWork > (pfork->GetBlockWork() * 7) &&
            chainActive.Height() - pindexNewForkTip->nHeight < 72) {
        pindexBestForkTip = pindexNewForkTip;
        pindexBestForkBase = pfork;
    }

    CheckForkWarningConditions();
}

// Requires cs_main.
void Misbehaving(NodeId pnode, int howmuch)
{
    if (howmuch == 0)
        return;

    CNodeState *state = State(pnode);
    if (state == NULL)
        return;

    state->nMisbehavior += howmuch;
    int banscore = GetArg("-banscore", 100);
    if (state->nMisbehavior >= banscore && state->nMisbehavior - howmuch < banscore) {
        LogPrintf("%s: %s (%d -> %d) BAN THRESHOLD EXCEEDED\n", __func__, state->name, state->nMisbehavior-howmuch, state->nMisbehavior);
        state->fShouldBan = true;
    } else
        LogPrintf("%s: %s (%d -> %d)\n", __func__, state->name, state->nMisbehavior-howmuch, state->nMisbehavior);
}

void static InvalidChainFound(CBlockIndex* pindexNew)
{
    if (!pindexBestInvalid || pindexNew->nChainWork > pindexBestInvalid->nChainWork) {
        pindexBestInvalid = pindexNew;
        uiInterface.NotifyBlocksChanged();
    }
    LogPrintf("%s: invalid block=%s  height=%d  log2_work=%.8g  date=%s\n",
             __func__, pindexNew->GetBlockHash().ToString(), pindexNew->nHeight,
             log(pindexNew->nChainWork.getdouble())/log(2.0),
             DateTimeStrFormat("%Y-%m-%d %H:%M:%S", pindexNew->GetBlockTime()));
    if (chainActive.Tip() != NULL) {
        LogPrintf("%s:  current best=%s  height=%d  log2_work=%.8g  date=%s\n",
                __func__, chainActive.Tip()->GetBlockHash().ToString(), chainActive.Height(),
                log(chainActive.Tip()->nChainWork.getdouble())/log(2.0),
                DateTimeStrFormat("%Y-%m-%d %H:%M:%S", chainActive.Tip()->GetBlockTime()));
    }
    CheckForkWarningConditions();
}

void static InvalidBlockFound(CBlockIndex *pindex, const CValidationState &state) {
    int nDoS = 0;
    if (state.IsInvalid(nDoS)) {
        map<uint256, NodeId>::iterator it = mapBlockSource.find(pindex->GetBlockHash());
        if (it != mapBlockSource.end() && State(it->second)) {
            CBlockReject reject = {state.GetRejectCode(), state.GetRejectReason(), pindex->GetBlockHash()};
            State(it->second)->rejects.push_back(reject);
            if (nDoS > 0)
                Misbehaving(it->second, nDoS);
        }
    }
    if (!state.CorruptionPossible()) {
        pindex->nStatus |= BLOCK_FAILED_VALID;
        pblocktree->WriteBlockIndex(CDiskBlockIndex(pindex));
        setBlockIndexValid.erase(pindex);
        InvalidChainFound(pindex);
    }
}

void UpdateCoins(const CTransaction& tx, CValidationState &state, CCoinsViewCache &inputs, CTxUndo &txundo, int nHeight)
{
    bool ret;
    // mark inputs spent
    if (!tx.IsCoinBase()) {
        BOOST_FOREACH(const CTxIn &txin, tx.vin) {
            CCoins &coins = inputs.GetCoins(txin.prevout.hash);
            CTxInUndo undo;
            ret = coins.Spend(txin.prevout, undo);
            assert(ret);
            txundo.vprevout.push_back(undo);
        }
    }

    // add outputs
    ret = inputs.SetCoins(tx.GetHash(), CCoins(tx, nHeight));
    assert(ret);
}

bool CScriptCheck::operator()() const
{
    const CScript &scriptSig = ptxTo->vin[nIn].scriptSig;
    if (!VerifyScript(scriptSig, scriptPubKey, *ptxTo, nIn, nFlags, nHashType))
        return error("%s() : %s VerifySignature failed", __func__, ptxTo->GetHash().ToString());
    return true;
}

bool VerifySignature(const CCoins& txFrom, const CTransaction& txTo, unsigned int nIn, unsigned int flags, int nHashType)
{
    return CScriptCheck(txFrom, txTo, nIn, flags, nHashType)();
}

bool CheckInputs(const CTransaction& tx, CValidationState &state, const CCoinsViewCache &inputs, bool fScriptChecks, unsigned int flags, vector<CScriptCheck> *pvChecks)
{
    if (!tx.IsCoinBase() || tx.type == MINT) {
        if (tx.type != MINT) {
            if (pvChecks)
                pvChecks->reserve(tx.vin.size());

            // This doesn't trigger the DoS code on purpose; if it did, it would make it easier
            // for an attacker to attempt to split the network.
            if (!inputs.HaveInputs(tx))
                return state.Invalid(error("%s() : %s inputs unavailable", __func__, tx.GetHash().ToString()));

            // While checking, GetBestBlock() refers to the parent block.
            // This is also true for mempool checks.
            CBlockIndex *pindexPrev = mapBlockIndex.find(inputs.GetBestBlock())->second;
            int nSpendHeight = pindexPrev->nHeight + 1;
            int64_t nValueIn = 0;
            int64_t nFees = 0;
            for (unsigned int i = 0; i < tx.vin.size(); i++) {
                const COutPoint &prevout = tx.vin[i].prevout;
                const CCoins &coins = inputs.GetCoins(prevout.hash);

                // If prev is coinbase, check that it's matured
                if (coins.IsCoinBase()) {
                    if (nSpendHeight - coins.nHeight < COINBASE_MATURITY)
                        return state.Invalid(
                            error("%s() : tried to spend coinbase at depth %d", __func__, nSpendHeight - coins.nHeight),
                            REJECT_INVALID, "bad-txns-premature-spend-of-coinbase");
                }

                // Check for negative or overflow input values
                // FIXME: what if prevout.n >= coins.vout.size()?
                nValueIn += coins.vout[prevout.n].nValue;
                if (!MoneyRange(coins.vout[prevout.n].nValue) || !MoneyRange(nValueIn))
                    return state.DoS(100, error("%s() : txin values out of range", __func__),
                                     REJECT_INVALID, "bad-txns-inputvalues-outofrange");

            }

            if (nValueIn < tx.GetValueOut())
                return state.DoS(100, error("%s() : %s value in < value out", __func__, tx.GetHash().ToString()),
                                 REJECT_INVALID, "bad-txns-in-belowout");

            // Tally transaction fees
            int64_t nTxFee = nValueIn - tx.GetValueOut();
            if (nTxFee < 0)
                return state.DoS(100, error("%s() : %s nTxFee < 0", __func__, tx.GetHash().ToString()),
                                 REJECT_INVALID, "bad-txns-fee-negative");
            nFees += nTxFee;
            if (!MoneyRange(nFees))
                return state.DoS(100, error("%s() : nFees out of range", __func__),
                                 REJECT_INVALID, "bad-txns-fee-outofrange");

        }
        // The first loop above does all the inexpensive checks.
        // Only if ALL inputs pass do we perform expensive ECDSA signature checks.
        // Helps prevent CPU exhaustion attacks.

        // Skip ECDSA signature verification when connecting blocks
        // before the last block chain checkpoint. This is safe because block merkle hashes are
        // still computed and checked, and any change will be caught at the next checkpoint.
        if (fScriptChecks) {
            if (tx.type != MINT) {
                for (unsigned int i = 0; i < tx.vin.size(); i++) {
                    const COutPoint &prevout = tx.vin[i].prevout;
                    const CCoins &coins = inputs.GetCoins(prevout.hash);

                    // Verify signature
                    CScriptCheck check(coins, tx, i, flags, 0);
                    if (pvChecks) {
                        pvChecks->push_back(CScriptCheck());
                        check.swap(pvChecks->back());
                    } else if (!check()) {
                        if (flags & STANDARD_NOT_MANDATORY_VERIFY_FLAGS) {
                            // Check whether the failure was caused by a
                            // non-mandatory script verification check, such as
                            // non-standard DER encodings or non-null dummy
                            // arguments; if so, don't trigger DoS protection to
                            // avoid splitting the network between upgraded and
                            // non-upgraded nodes.
                            CScriptCheck check(coins, tx, i,
                                    flags & ~STANDARD_NOT_MANDATORY_VERIFY_FLAGS, 0);
                            if (check())
                                return state.Invalid(false, REJECT_NONSTANDARD, "non-mandatory-script-verify-flag");
                        }
                        // Failures of other flags indicate a transaction that is
                        // invalid in new blocks, e.g. a invalid P2SH. We DoS ban
                        // such nodes as they are not following the protocol. That
                        // said during an upgrade careful thought should be taken
                        // as to the correct behavior - we may want to continue
                        // peering with non-upgraded nodes even after a soft-fork
                        // super-majority vote has passed.
                        return state.DoS(100,false, REJECT_INVALID, "mandatory-script-verify-flag-failed");
                    }
                }
            } else {
                //similiar to above, but coinbase tx has no input so we should adjust it

                // Verify signature
                // FIXME: what if tx.vin.size() and tx.vout.size() == 0?
                const CScript &scriptPubKey = tx.vout[0].scriptPubKey;
                const CScript &scriptSig = tx.vin[0].scriptSig;

                // not sure purpose of pcChecks
                /*
                if (pvChecks) {
                    pvChecks->push_back(CScriptCheck());
                    check.swap(pvChecks->back());
                } else if (!VerifyScript(scriptSig, scriptPubKey, tx, 0, flags, 0)) {
                */
                if (!VerifyScript(scriptSig, scriptPubKey, tx, 0, flags, 0)) {
                    if (flags & STANDARD_NOT_MANDATORY_VERIFY_FLAGS) {
                        // Check whether the failure was caused by a
                        // non-mandatory script verification check, such as
                        // non-standard DER encodings or non-null dummy
                        // arguments; if so, don't trigger DoS protection to
                        // avoid splitting the network between upgraded and
                        // non-upgraded nodes.
                        if (VerifyScript(scriptSig, scriptPubKey, tx, 0, flags & ~STANDARD_NOT_MANDATORY_VERIFY_FLAGS, 0))
                            return state.Invalid(false, REJECT_NONSTANDARD, "non-mandatory-script-verify-flag");
                    }
                    // Failures of other flags indicate a transaction that is
                    // invalid in new blocks, e.g. a invalid P2SH. We DoS ban
                    // such nodes as they are not following the protocol. That
                    // said during an upgrade careful thought should be taken
                    // as to the correct behavior - we may want to continue
                    // peering with non-upgraded nodes even after a soft-fork
                    // super-majority vote has passed.
                    return state.DoS(100,false, REJECT_INVALID, "mandatory-script-verify-flag-failed");
                }
            }
        }
    }

    return true;
}



bool DisconnectBlock(CBlock& block, CValidationState& state, CBlockIndex* pindex, CCoinsViewCache& view, bool* pfClean)
{
    assert(pindex->GetBlockHash() == view.GetBestBlock());
    if (pfClean)
        *pfClean = false;
    bool fClean = true;

    CBlockUndo blockUndo;
    CDiskBlockPos pos = pindex->GetUndoPos();
    if (pos.IsNull())
        return error("%s() : no undo data available", __func__);
    if (!blockUndo.ReadFromDisk(pos, pindex->pprev->GetBlockHash()))
        return error("%s() : failure reading undo data", __func__);
    int CoinBaseCount = 0;
    for (unsigned int i = 0; i < block.vtx.size(); i++) {
        if (block.vtx[i].IsCoinBase())
            CoinBaseCount++;
    }
    if (blockUndo.vtxundo.size() + CoinBaseCount != block.vtx.size())
        return error("%s() : block and undo data inconsistent", __func__);

    // undo transactions in reverse order
    for (int i = block.vtx.size() - 1; i >= 0; i--) {
        const CTransaction &tx = block.vtx[i];
        uint256 hash = tx.GetHash();
        // Check that all outputs are available and match the outputs in the block itself
        // exactly. Note that transactions with only provably unspendable outputs won't
        // have outputs available even in the block itself, so we handle that case
        // specially with outsEmpty.
        CCoins outsEmpty;
        CCoins &outs = view.HaveCoins(hash) ? view.GetCoins(hash) : outsEmpty;
        outs.ClearUnspendable();

        if (tx.IsCoinBase())
            CoinBaseCount--;

#ifdef ENABLE_GCOIN
        // undo the data for VoteList & BanVoteList  & MemberList & LicenseList
        if (!type_transaction_handler::GetHandler(tx.type)->Undo(tx, block)) {
            return false;
        }
#endif  // ENABLE_GCOIN

        CCoins outsBlock = CCoins(tx, pindex->nHeight);
        // The CCoins serialization does not serialize negative numbers.
        // No network rules currently depend on the version here, so an inconsistency is harmless
        // but it must be corrected before txout nversion ever influences a network rule.
        if (outsBlock.nVersion < 0)
            outs.nVersion = outsBlock.nVersion;
        if (outs != outsBlock)
            fClean = fClean && error("%s() : added transaction mismatch? database corrupted, __func__");

        // remove outputs
        outs = CCoins();

        // restore inputs
        if (!tx.IsCoinBase()) { // not coinbases
            const CTxUndo &txundo = blockUndo.vtxundo[i-CoinBaseCount];
            if (txundo.vprevout.size() != tx.vin.size())
                return error("%s() : transaction and undo data inconsistent", __func__);
            for (unsigned int j = tx.vin.size(); j-- > 0;) {
                const COutPoint &out = tx.vin[j].prevout;
                const CTxInUndo &undo = txundo.vprevout[j];
                CCoins coins;
                view.GetCoins(out.hash, coins); // this can fail if the prevout was already entirely spent
                if (undo.nHeight != 0) {
                    // undo data contains height: this is the last output of the prevout tx being spent
                    if (!coins.IsPruned())
                        fClean = fClean && error("%s() : undo data overwriting existing transaction", __func__);
                    coins = CCoins();
                    coins.fCoinBase = undo.fCoinBase;
                    coins.nHeight = undo.nHeight;
                    coins.nVersion = undo.nVersion;
#ifdef ENABLE_GCOIN
                    coins.color = undo.color;
                    coins.type = undo.type;
#endif
                } else {
                    if (coins.IsPruned())
                        fClean = fClean && error("%s() : undo data adding output to missing transaction", __func__);
                }
                if (coins.IsAvailable(out.n))
                    fClean = fClean && error("%s() : undo data overwriting existing output", __func__);
                if (coins.vout.size() < out.n + 1)
                    coins.vout.resize(out.n + 1);
                coins.vout[out.n] = undo.txout;
                if (!view.SetCoins(out.hash, coins))
                    return error("%s() : cannot restore coin inputs", __func__);
            }
        }
    }

    // move best block pointer to prevout block
    view.SetBestBlock(pindex->pprev->GetBlockHash());

    if (pfClean) {
        *pfClean = fClean;
        return true;
    } else
        return fClean;
}


void static FlushBlockFile(bool fFinalize = false)
{
    LOCK(cs_LastBlockFile);

    CDiskBlockPos posOld(nLastBlockFile, 0);

    FILE *fileOld = OpenBlockFile(posOld);
    if (fileOld) {
        if (fFinalize)
            TruncateFile(fileOld, infoLastBlockFile.nSize);
        FileCommit(fileOld);
        fclose(fileOld);
    }

    fileOld = OpenUndoFile(posOld);
    if (fileOld) {
        if (fFinalize)
            TruncateFile(fileOld, infoLastBlockFile.nUndoSize);
        FileCommit(fileOld);
        fclose(fileOld);
    }
}

bool FindUndoPos(CValidationState &state, int nFile, CDiskBlockPos &pos, unsigned int nAddSize);

static CCheckQueue<CScriptCheck> scriptcheckqueue(128);

void ThreadScriptCheck()
{
    RenameThread("bitcoin-scriptch");
    scriptcheckqueue.Thread();
}

static int64_t nTimeVerify = 0;
static int64_t nTimeConnect = 0;
static int64_t nTimeIndex = 0;
static int64_t nTimeCallbacks = 0;
static int64_t nTimeTotal = 0;


/// get total input value of this tx
int64_t nGetValueIn(const CTransaction& tx, map<uint256, CTransaction>& txpool)
{
    int64_t value = 0;
    bool color_0 = false;
    for (unsigned int i = 0; i < tx.vin.size(); i++) {
        CCoins coins;
        if (!GetCoinsFromCache(tx.vin[i].prevout, coins, false)) {
            LogPrintf("Cant find input[%d]\n",i);
            return -1;
        }
        if (coins.color != 0 && coins.color != tx.color) {
            LogPrintf("Illegal color at vin[%d]  tx color:%d   vin color:%d  \n", i, tx.color, coins.color);
            return -1;
        }
        if (coins.color == 0)
            color_0 = true;

        value += coins.vout[tx.vin[i].prevout.n].nValue;
    }
    if (color_0)
        return 0;
    return value;
}

/// check coinbase transaction of each color
bool CheckCoinBaseTransactions(CBlock& block)
{
    map<int, int64_t> CoinBase, TX;
    map<uint256, CTransaction> txpool;
    BOOST_FOREACH(const CTransaction& tx, block.vtx) {
        txpool[tx.GetHash()] = tx;
    }
    BOOST_FOREACH(const CTransaction& tx, block.vtx) {
        if (tx.IsCoinBase()) {
            if (tx.type == MINT)
                continue;
            CoinBase[tx.color] = tx.vout[0].nValue;
        } else if (tx.type == LICENSE) {
            continue;
        } else {
            int64_t VIN = nGetValueIn(tx, txpool);
            if (VIN < 0)
                return false;
            // input color == 0 , no need to charge tx fees
            if (VIN == 0)
                continue;
            int64_t Fees = VIN - tx.GetValueOut();
            LogPrintf("color : %d  Fees : %d\n", tx.color, Fees);

            if (tx.out_itself) {
                if (Fees != (int64_t)((tx.GetValueOut() - tx.vout[tx.vout.size() - 1].nValue) * nFeeRate) && tx.color != 0) {
                    LogPrintf("Illegal Transaction Fee : %d  expect : %d\n", VIN, (int64_t) ((tx.GetValueOut() - tx.vout[tx.vout.size() - 1].nValue) * nFeeRate));
                    return false;
                }
            } else if (Fees != (int64_t) (tx.GetValueOut() * nFeeRate) && tx.color != 0) {
                LogPrintf("Illegal Transaction Fee : %d  expect : %d\n", VIN, (int64_t) (tx.GetValueOut() * nFeeRate));
                return false;
            }

            if (Fees == 0) continue;
            if (TX.find(tx.color) != TX.end())
                TX[tx.color] += Fees;
            else
                TX[tx.color] = Fees;
        }
    }
    if (CoinBase.size() != TX.size() + 1 && CoinBase.size() != TX.size()) {
        LogPrintf("SIZE not equal :  %d   %d\n", CoinBase.size(), TX.size());
        return false;
    }

    for (map<int, int64_t>::iterator it = CoinBase.begin(); it != CoinBase.end(); it++) {
        if (it->first == 0)
            continue;
        if (TX[it->first] != it->second) {
            LogPrintf("Fees not match : %d   %d\n", TX[it->first], it->second);
            return false;
        }
    }
    return true;
}


bool ConnectBlock(CBlock& block, CValidationState& state, CBlockIndex* pindex, CCoinsViewCache& view, bool fJustCheck, bool fMiningPool)
{
    AssertLockHeld(cs_main);

    // Check it again in case a previous version let a bad block in
    // dont check genesis block
    if (!CheckBlock(block, state, !fJustCheck, !fJustCheck))
        return false;

    // verify that the view's current state corresponds to the previous block
    uint256 hashPrevBlock = pindex->pprev == NULL ? uint256(0) : pindex->pprev->GetBlockHash();
    assert(hashPrevBlock == view.GetBestBlock());

    // Special case for the genesis block, skipping connection of its transactions
    // (its coinbase is unspendable)
    if (block.GetHash() == Params().HashGenesisBlock()) {
        view.SetBestBlock(pindex->GetBlockHash());
        return true;
    }

    bool fScriptChecks = pindex->nHeight >= Checkpoints::GetTotalBlocksEstimate();

    // Do not allow blocks that contain transactions which 'overwrite' older transactions,
    // unless those are already completely spent.
    // If such overwrites are allowed, coinbases and transactions depending upon those
    // can be duplicated to remove the ability to spend the first instance -- even after
    // being sent to another address.
    // See BIP30 and http://r6.ca/blog/20120206T005236Z.html for more information.
    // This logic is not necessary for memory pool transactions, as AcceptToMemoryPool
    // already refuses previously-known transaction ids entirely.
    // This rule was originally applied all blocks whose timestamp was after March 15, 2012, 0:00 UTC.
    // Now that the whole chain is irreversibly beyond that time it is applied to all blocks except the
    // two in the chain that violate it. This prevents exploiting the issue against nodes in their
    // initial block download.
    bool fEnforceBIP30 = (!pindex->phashBlock);
    if (fEnforceBIP30) {
        BOOST_FOREACH(const CTransaction& tx, block.vtx) {
            const uint256& hash = tx.GetHash();
            if (view.HaveCoins(hash) && !view.GetCoins(hash).IsPruned())
                return state.DoS(100, error("%s() : tried to overwrite transaction", __func__),
                                 REJECT_INVALID, "bad-txns-BIP30");
        }
    }

    // BIP16 didn't become active until Apr 1 2012
    int64_t nBIP16SwitchTime = 1333238400;
    bool fStrictPayToScriptHash = (pindex->GetBlockTime() >= nBIP16SwitchTime);

    unsigned int flags = SCRIPT_VERIFY_NOCACHE |
                         (fStrictPayToScriptHash ? SCRIPT_VERIFY_P2SH : SCRIPT_VERIFY_NONE);

    CBlockUndo blockundo;

    CCheckQueueControl<CScriptCheck> control(fScriptChecks && nScriptCheckThreads ? &scriptcheckqueue : NULL);

    int64_t nTimeStart = GetTimeMicros();
    int64_t nFees = 0;
    int nInputs = 0;
    unsigned int nSigOps = 0;
    CDiskTxPos pos(pindex->GetBlockPos(), GetSizeOfCompactSize(block.vtx.size()));
    vector<pair<uint256, CDiskTxPos> > vPos;
    vPos.reserve(block.vtx.size());
    for (unsigned int i = 0; i < block.vtx.size(); i++) {
        const CTransaction &tx = block.vtx[i];

        nInputs += tx.vin.size();
        nSigOps += GetLegacySigOpCount(tx);
        if (nSigOps > MAX_BLOCK_SIGOPS)
            return state.DoS(100, error("%s() : too many sigops", __func__),
                             REJECT_INVALID, "bad-blk-sigops");

        vector<CScriptCheck> vChecks;

        if (!tx.IsCoinBase()) {
            if (!view.HaveInputs(tx))
                return state.DoS(100, error("%s() : inputs missing/spent", __func__),
                                 REJECT_INVALID, "bad-txns-inputs-missingorspent");

            if (fStrictPayToScriptHash) {
                // Add in sigops done by pay-to-script-hash inputs;
                // this is to prevent a "rogue miner" from creating
                // an incredibly-expensive-to-validate block.
                nSigOps += GetP2SHSigOpCount(tx, view);
                if (nSigOps > MAX_BLOCK_SIGOPS)
                    return state.DoS(100, error("%s() : too many sigops", __func__),
                                     REJECT_INVALID, "bad-blk-sigops");
            }

            nFees += view.GetValueIn(tx)-tx.GetValueOut();

            if (!CheckInputs(tx, state, view, fScriptChecks, flags, nScriptCheckThreads ? &vChecks : NULL))
                return false;
            control.Add(vChecks);
        } else if (!CheckInputs(tx, state, view, fScriptChecks, flags, nScriptCheckThreads ? &vChecks : NULL))
            return false;

#ifdef ENABLE_GCOIN
        if (i != 0 && !CheckTransactionType(tx, state, &block, false))
            return error("%s() : CheckTransactionType failed", __func__);
#endif // ENABLE_GCOIN

        CTxUndo txundo;
        UpdateCoins(tx, state, view, txundo, pindex->nHeight);
        if (!tx.IsCoinBase())
            blockundo.vtxundo.push_back(txundo);

        vPos.push_back(make_pair(tx.GetHash(), pos));
        pos.nTxOffset += ::GetSerializeSize(tx, SER_DISK, CLIENT_VERSION);
    }
    int64_t nTime1 = GetTimeMicros(); nTimeConnect += nTime1 - nTimeStart;
    LogPrint("bench", "      - Connect %u transactions: %.2fms (%.3fms/tx, %.3fms/txin) [%.2fs]\n",
            (unsigned)block.vtx.size(), 0.001 * (nTime1 - nTimeStart),
            0.001 * (nTime1 - nTimeStart) / block.vtx.size(), nInputs <= 1 ? 0 : 0.001 * (nTime1 - nTimeStart) / (nInputs-1),
            nTimeConnect * 0.000001);

    if (block.vtx[0].GetValueOut() > GetBlockValue(pindex->nHeight, nFees))
        return state.DoS(100,
                         error("%s() : coinbase pays too much (actual=%d vs limit=%d)", __func__,
                               block.vtx[0].GetValueOut(), GetBlockValue(pindex->nHeight, nFees)),
                               REJECT_INVALID, "bad-cb-amount");

    // Check if coin base transaction meet the transaction fees of each color
    if (!CheckCoinBaseTransactions(block))
        return state.DoS(100, error("%s() : CheckCoinBaseTransactions", __func__));
    if (!control.Wait())
        return state.DoS(100, false);
    int64_t nTime2 = GetTimeMicros();
    nTimeVerify += nTime2 - nTimeStart;
    LogPrint("bench", "    - Verify %u txins: %.2fms (%.3fms/txin) [%.2fs]\n",
            nInputs - 1, 0.001 * (nTime2 - nTimeStart),
            nInputs <= 1 ? 0 : 0.001 * (nTime2 - nTimeStart) / (nInputs-1),
            nTimeVerify * 0.000001);

    if (fJustCheck)
        return true;

    // Correct transaction counts.
    pindex->nTx = block.vtx.size();
    if (pindex->pprev)
        pindex->nChainTx = pindex->pprev->nChainTx + block.vtx.size();

    // Write undo information to disk
    if (pindex->GetUndoPos().IsNull() || !pindex->IsValid(BLOCK_VALID_SCRIPTS)) {
        if (pindex->GetUndoPos().IsNull()) {
            CDiskBlockPos pos;
            if (!FindUndoPos(state, pindex->nFile, pos, ::GetSerializeSize(blockundo, SER_DISK, CLIENT_VERSION) + 40))
                return error("%s() : FindUndoPos failed", __func__);
            if (!blockundo.WriteToDisk(pos, pindex->pprev->GetBlockHash()))
                return state.Abort(_("Failed to write undo data"));

            // update nUndoPos in block index
            pindex->nUndoPos = pos.nPos;
            pindex->nStatus |= BLOCK_HAVE_UNDO;
        }

        pindex->RaiseValidity(BLOCK_VALID_SCRIPTS);

        CDiskBlockIndex blockindex(pindex);
        if (!pblocktree->WriteBlockIndex(blockindex))
            return state.Abort(_("Failed to write block index"));
    }

    if (fTxIndex)
        if (!pblocktree->WriteTxIndex(vPos))
            return state.Abort(_("Failed to write transaction index"));

    // add this block to the view's block chain
    bool ret;
    ret = view.SetBestBlock(pindex->GetBlockHash());
    assert(ret);

    int64_t nTime3 = GetTimeMicros();
    nTimeIndex += nTime3 - nTime2;
    LogPrint("bench", "    - Index writing: %.2fms [%.2fs]\n", 0.001 * (nTime3 - nTime2), nTimeIndex * 0.000001);

    // Watch for changes to the previous coinbase transaction.
    static uint256 hashPrevBestCoinBase;
    g_signals.UpdatedTransaction(hashPrevBestCoinBase);
    hashPrevBestCoinBase = block.vtx[0].GetHash();

    int64_t nTime4 = GetTimeMicros(); nTimeCallbacks += nTime4 - nTime3;
    LogPrint("bench", "    - Callbacks: %.2fms [%.2fs]\n", 0.001 * (nTime4 - nTime3), nTimeCallbacks * 0.000001);
    return true;
}

// Update the on-disk chain state.
bool static WriteChainState(CValidationState &state)
{
    static int64_t nLastWrite = 0;
    if (pcoinsTip->GetCacheSize() > nCoinCacheSize || (!IsInitialBlockDownload() && GetTimeMicros() > nLastWrite + 600*1000000)) {
        // Typical CCoins structures on disk are around 100 bytes in size.
        // Pushing a new one to the database can cause it to be written
        // twice (once in the log, and once in the tables). This is already
        // an overestimation, as most will delete an existing entry or
        // overwrite one. Still, use a conservative safety factor of 2.
        if (!CheckDiskSpace(100 * 2 * 2 * pcoinsTip->GetCacheSize()))
            return state.Error("out of disk space");
        FlushBlockFile();
        pblocktree->Sync();
        if (!pcoinsTip->Flush())
            return state.Abort(_("Failed to write to coin database"));
        nLastWrite = GetTimeMicros();
    }
    return true;
}

// Update chainActive and related internal data structures.
void static UpdateTip(CBlockIndex *pindexNew)
{
    LOCK(cs_main);
    chainActive.SetTip(pindexNew);

    // Update best block in wallet (so we can detect restored wallets)
    bool fIsInitialDownload = IsInitialBlockDownload();
    if ((chainActive.Height() % 20160) == 0 || (!fIsInitialDownload && (chainActive.Height() % 144) == 0))
        g_signals.SetBestChain(chainActive.GetLocator());

    // New best block
    nTimeBestReceived = GetTime();
    mempool.AddTransactionsUpdated(1);

    LogPrintf("%s: new best=%s  height=%d  log2_work=%.8g  tx=%lu  date=%s progress=%f\n",
        __func__,
        chainActive.Tip()->GetBlockHash().ToString(),
        chainActive.Height(),
        log(chainActive.Tip()->nChainWork.getdouble())/log(2.0),
        (unsigned long)chainActive.Tip()->nChainTx,
        DateTimeStrFormat("%Y-%m-%d %H:%M:%S", chainActive.Tip()->GetBlockTime()),
        Checkpoints::GuessVerificationProgress(chainActive.Tip()));

    cvBlockChange.notify_all();

    // Check the version of the last 100 blocks to see if we need to upgrade:
    if (!fIsInitialDownload) {
        int nUpgraded = 0;
        const CBlockIndex* pindex = chainActive.Tip();
        for (int i = 0; i < 100 && pindex != NULL; i++) {
            if (pindex->nVersion > CBlock::CURRENT_VERSION)
                ++nUpgraded;
            pindex = pindex->pprev;
        }
        if (nUpgraded > 0)
            LogPrintf("%s: %d of last 100 blocks above version %d\n", __func__, nUpgraded, (int)CBlock::CURRENT_VERSION);
        if (nUpgraded > 100/2)
            // strMiscWarning is read by GetWarnings(), called by Qt and the JSON-RPC code to warn the user:
            strMiscWarning = _("Warning: This version is obsolete, upgrade required!");
    }
}

// Disconnect chainActive's tip.
bool static DisconnectTip(CValidationState &state)
{
    CBlockIndex *pindexDelete = chainActive.Tip();
    assert(pindexDelete);
    mempool.check(pcoinsTip);
    // Read block from disk.
    CBlock block;
    if (!ReadBlockFromDisk(block, pindexDelete))
        return state.Abort(_("Failed to read block"));
    // Apply the block atomically to the chain state.
    int64_t nStart = GetTimeMicros();
    {
        CCoinsViewCache view(*pcoinsTip, true);
        if (!DisconnectBlock(block, state, pindexDelete, view))
            return error("%s() : DisconnectBlock %s failed", __func__, pindexDelete->GetBlockHash().ToString());
        assert(view.Flush());
    }
    LogPrint("bench", "- Disconnect block: %.2fms\n", (GetTimeMicros() - nStart) * 0.001);
    // Write the chain state to disk, if necessary.
    if (!WriteChainState(state))
        return false;
    // Resurrect mempool transactions from the disconnected block.
    BOOST_FOREACH(const CTransaction &tx, block.vtx) {
        // ignore validation errors in resurrected transactions
        list<CTransaction> removed;
        CValidationState stateDummy;
        if (!tx.IsCoinBase() || tx.type == MINT)
            if (!AcceptToMemoryPool(mempool, stateDummy, tx, false, NULL, false, true)) {
                mempool.remove(tx, removed, true);
            }
    }
    mempool.check(pcoinsTip);
    // Update chainActive and related variables.
    UpdateTip(pindexDelete->pprev);
    // Let wallets know transactions went from 1-confirmed to
    // 0-confirmed or conflicted:
    BOOST_FOREACH(const CTransaction &tx, block.vtx) {
        SyncWithWallets(tx, NULL);
    }

    return true;
}

static int64_t nTimeReadFromDisk = 0;
static int64_t nTimeConnectTotal = 0;
static int64_t nTimeFlush = 0;
static int64_t nTimeChainState = 0;
static int64_t nTimePostConnect = 0;

// Connect a new block to chainActive. pblock is either NULL or a pointer to a CBlock
// corresponding to pindexNew, to bypass loading it again from disk.
bool static ConnectTip(CValidationState &state, CBlockIndex *pindexNew, CBlock *pblock)
{
    assert(pindexNew->pprev == chainActive.Tip());
    mempool.check(pcoinsTip);
    // Read block from disk.
    int64_t nTime1 = GetTimeMicros();
    CBlock block;
    if (!pblock) {
        if (!ReadBlockFromDisk(block, pindexNew))
            return state.Abort(_("Failed to read block"));
        pblock = &block;
    }
    // Apply the block atomically to the chain state.
    int64_t nTime2 = GetTimeMicros(); nTimeReadFromDisk += nTime2 - nTime1;
    int64_t nTime3;
    LogPrint("bench", "  - Load block from disk: %.2fms [%.2fs]\n", (nTime2 - nTime1) * 0.001, nTimeReadFromDisk * 0.000001);
    {
        CCoinsViewCache view(*pcoinsTip, true);
        CInv inv(MSG_BLOCK, pindexNew->GetBlockHash());
        if (!ConnectBlock(*pblock, state, pindexNew, view)) {
            if (state.IsInvalid())
                InvalidBlockFound(pindexNew, state);
            return error("%s() : ConnectBlock %s failed", __func__, pindexNew->GetBlockHash().ToString());
        }
#ifdef ENABLE_GCOIN
        else {
            BOOST_FOREACH(const CTransaction &tx, pblock->vtx) {
                if (!type_transaction_handler::GetHandler(tx.type)->Apply(
                        pblock, tx))  {
                    return false;
                }
            }
        }
#endif // ENABLE_GCOIN
        mapBlockSource.erase(inv.hash);
        nTime3 = GetTimeMicros(); nTimeConnectTotal += nTime3 - nTime2;
        LogPrint("bench", "  - Connect total: %.2fms [%.2fs]\n", (nTime3 - nTime2) * 0.001, nTimeConnectTotal * 0.000001);
        assert(view.Flush());
    }
    int64_t nTime4 = GetTimeMicros(); nTimeFlush += nTime4 - nTime3;
    LogPrint("bench", "  - Flush: %.2fms [%.2fs]\n", (nTime4 - nTime3) * 0.001, nTimeFlush * 0.000001);
    // Write the chain state to disk, if necessary.
    if (!WriteChainState(state))
        return false;
    int64_t nTime5 = GetTimeMicros(); nTimeChainState += nTime5 - nTime4;
    LogPrint("bench", "  - Writing chainstate: %.2fms [%.2fs]\n", (nTime5 - nTime4) * 0.001, nTimeChainState * 0.000001);
    // Remove conflicting transactions from the mempool.
    list<CTransaction> txConflicted;
    mempool.removeForBlock(pblock->vtx, pindexNew->nHeight, txConflicted);
    mempool.check(pcoinsTip);
    // Update chainActive & related variables.
    UpdateTip(pindexNew);
    // Tell wallet about transactions that went from mempool
    // to conflicted:
    BOOST_FOREACH(const CTransaction &tx, txConflicted) {
        SyncWithWallets(tx, NULL);
    }
    // ... and about transactions that got confirmed:
    BOOST_FOREACH(const CTransaction &tx, pblock->vtx) {
        SyncWithWallets(tx, pblock);
    }
    int64_t nTime6 = GetTimeMicros(); nTimePostConnect += nTime6 - nTime5; nTimeTotal += nTime6 - nTime1;
    LogPrint("bench", "  - Connect postprocess: %.2fms [%.2fs]\n", (nTime6 - nTime5) * 0.001, nTimePostConnect * 0.000001);
    LogPrint("bench", "- Connect block: %.2fms [%.2fs]\n", (nTime6 - nTime1) * 0.001, nTimeTotal * 0.000001);
    return true;
}

// Return the tip of the chain with the most work in it, that isn't
// known to be invalid (it's however far from certain to be valid).
static CBlockIndex* FindMostWorkChain()
{
    do {
        CBlockIndex *pindexNew = NULL;

        // Find the best candidate header.
        {
            set<CBlockIndex*, CBlockIndexWorkComparator>::reverse_iterator it = setBlockIndexValid.rbegin();
            if (it == setBlockIndexValid.rend())
                return NULL;
            pindexNew = *it;
        }

        // Check whether all blocks on the path between the currently active chain and the candidate are valid.
        // Just going until the active chain is an optimization, as we know all blocks in it are valid already.
        CBlockIndex *pindexTest = pindexNew;
        bool fInvalidAncestor = false;
        while (pindexTest && !chainActive.Contains(pindexTest)) {
            if (pindexTest->nStatus & BLOCK_FAILED_MASK) {
                // Candidate has an invalid ancestor, remove entire chain from the set.
                if (pindexBestInvalid == NULL || pindexNew->nChainWork > pindexBestInvalid->nChainWork)
                    pindexBestInvalid = pindexNew;
                CBlockIndex *pindexFailed = pindexNew;
                while (pindexTest != pindexFailed) {
                    pindexFailed->nStatus |= BLOCK_FAILED_CHILD;
                    setBlockIndexValid.erase(pindexFailed);
                    pindexFailed = pindexFailed->pprev;
                }
                setBlockIndexValid.erase(pindexTest);
                fInvalidAncestor = true;
                break;
            }
            pindexTest = pindexTest->pprev;
        }
        if (!fInvalidAncestor)
            return pindexNew;
    } while(true);
}

// Try to make some progress towards making pindexMostWork the active block.
// pblock is either NULL or a pointer to a CBlock corresponding to pindexMostWork.
static bool ActivateBestChainStep(CValidationState &state, CBlockIndex *pindexMostWork, CBlock *pblock)
{
    AssertLockHeld(cs_main);
    bool fInvalidFound = false;
    const CBlockIndex *pindexOldTip = chainActive.Tip();
    const CBlockIndex *pindexFork = chainActive.FindFork(pindexMostWork);

    // Disconnect active blocks which are no longer in the best chain.
    while (chainActive.Tip() && chainActive.Tip() != pindexFork) {
        if (!DisconnectTip(state))
            return false;
    }

    // Build list of new blocks to connect.
    vector<CBlockIndex*> vpindexToConnect;
    vpindexToConnect.reserve(pindexMostWork->nHeight - (pindexFork ? pindexFork->nHeight : -1));
    CBlockIndex *pindexIter = pindexMostWork;
    while (pindexIter && pindexIter != pindexFork) {
        vpindexToConnect.push_back(pindexIter);
        pindexIter = pindexIter->pprev;
    }

    // Connect new blocks.
    BOOST_REVERSE_FOREACH(CBlockIndex *pindexConnect, vpindexToConnect) {
        if (!ConnectTip(state, pindexConnect, pindexConnect == pindexMostWork ? pblock : NULL)) {
            if (state.IsInvalid()) {
                // The block violates a consensus rule.
                if (!state.CorruptionPossible())
                    InvalidChainFound(vpindexToConnect.back());
                state = CValidationState();
                fInvalidFound = true;
                break;
            } else {
                // A system error occurred (disk space, database error, ...).
                return false;
            }
        } else {
            // Delete all entries in setBlockIndexValid that are worse than our new current block.
            // Note that we can't delete the current block itself, as we may need to return to it later in case a
            // reorganization to a better block fails.
            set<CBlockIndex*, CBlockIndexWorkComparator>::iterator it = setBlockIndexValid.begin();
            while (setBlockIndexValid.value_comp()(*it, chainActive.Tip())) {
                setBlockIndexValid.erase(it++);
            }
            // Either the current tip or a successor of it we're working towards is left in setBlockIndexValid.
            assert(!setBlockIndexValid.empty());
            if (!pindexOldTip || chainActive.Tip()->nChainWork > pindexOldTip->nChainWork) {
                // We're in a better position than we were. Return temporarily to release the lock.
                break;
            }
        }
    }

    // Callbacks/notifications for a new best chain.
    if (fInvalidFound)
        CheckForkWarningConditionsOnNewFork(vpindexToConnect.back());
    else
        CheckForkWarningConditions();

    if (!pblocktree->Flush())
        return state.Abort(_("Failed to sync block index"));

    return true;
}

// Make the best chain active, in multiple steps. The result is either failure
// or an activated best chain. pblock is either NULL or a pointer to a block
// that is already loaded (to avoid loading it again from disk).
bool ActivateBestChain(CValidationState &state, CBlock *pblock)
{
    CBlockIndex *pindexNewTip = NULL;
    CBlockIndex *pindexMostWork = NULL;
    do {
        boost::this_thread::interruption_point();

        bool fInitialDownload;
        {
            LOCK(cs_main);
            pindexMostWork = FindMostWorkChain();

            // Whether we have anything to do at all.
            if (pindexMostWork == NULL || pindexMostWork == chainActive.Tip())
                return true;

            if (!ActivateBestChainStep(state, pindexMostWork, pblock && pblock->GetHash() == pindexMostWork->GetBlockHash() ? pblock : NULL))
                return false;

            pindexNewTip = chainActive.Tip();
            fInitialDownload = IsInitialBlockDownload();
        }
        // When we reach this point, we switched to a new tip (stored in pindexNewTip).
        // Notifications/callbacks that can run without cs_main
        if (!fInitialDownload) {
            uint256 hashNewTip = pindexNewTip->GetBlockHash();
            // Relay inventory, but don't relay old inventory during initial block download.
            int nBlockEstimate = Checkpoints::GetTotalBlocksEstimate();
            LOCK(cs_vNodes);
            BOOST_FOREACH(CNode* pnode, vNodes)
                if (chainActive.Height() > (pnode->nStartingHeight != -1 ? pnode->nStartingHeight - 2000 : nBlockEstimate))
                    pnode->PushInventory(CInv(MSG_BLOCK, hashNewTip));

            string strCmd = GetArg("-blocknotify", "");
            if (!strCmd.empty()) {
                boost::replace_all(strCmd, "%s", hashNewTip.GetHex());
                boost::thread t(runCommand, strCmd); // thread runs free
            }
        }
        uiInterface.NotifyBlocksChanged();
    } while(pindexMostWork != chainActive.Tip());

    return true;
}

CBlockIndex* AddToBlockIndex(CBlockHeader& block)
{
    // Check for duplicate
    uint256 hash = block.GetHash();
    map<uint256, CBlockIndex*>::iterator it = mapBlockIndex.find(hash);
    if (it != mapBlockIndex.end())
        return it->second;

    // Construct new block index object
    CBlockIndex* pindexNew = new CBlockIndex(block);
    assert(pindexNew);
    {
         LOCK(cs_nBlockSequenceId);
         pindexNew->nSequenceId = nBlockSequenceId++;
    }
    map<uint256, CBlockIndex*>::iterator mi = mapBlockIndex.insert(make_pair(hash, pindexNew)).first;
    pindexNew->phashBlock = &((*mi).first);
    map<uint256, CBlockIndex*>::iterator miPrev = mapBlockIndex.find(block.hashPrevBlock);
    if (miPrev != mapBlockIndex.end()) {
        pindexNew->pprev = (*miPrev).second;
        pindexNew->nHeight = pindexNew->pprev->nHeight + 1;
        pindexNew->BuildSkip();
    }
    pindexNew->nChainWork = (pindexNew->pprev ? pindexNew->pprev->nChainWork : 0) + pindexNew->GetBlockWork();
    pindexNew->RaiseValidity(BLOCK_VALID_TREE);

    return pindexNew;
}

// Mark a block as having its data received and checked (up to BLOCK_VALID_TRANSACTIONS).
bool ReceivedBlockTransactions(const CBlock &block, CValidationState& state, CBlockIndex *pindexNew, const CDiskBlockPos& pos)
{
    pindexNew->nTx = block.vtx.size();
    if (pindexNew->pprev) {
        // Not the genesis block.
        if (pindexNew->pprev->nChainTx) {
            // This parent's block's total number transactions is known, so compute outs.
            pindexNew->nChainTx = pindexNew->pprev->nChainTx + pindexNew->nTx;
        } else {
            // The total number of transactions isn't known yet.
            // We will compute it when the block is connected.
            pindexNew->nChainTx = 0;
        }
    } else {
        // Genesis block.
        pindexNew->nChainTx = pindexNew->nTx;
    }
    pindexNew->nFile = pos.nFile;
    pindexNew->nDataPos = pos.nPos;
    pindexNew->nUndoPos = 0;
    pindexNew->nStatus |= BLOCK_HAVE_DATA;

    if (pindexNew->RaiseValidity(BLOCK_VALID_TRANSACTIONS))
        setBlockIndexValid.insert(pindexNew);

    if (!pblocktree->WriteBlockIndex(CDiskBlockIndex(pindexNew)))
        return state.Abort(_("Failed to write block index"));

    return true;
}

bool FindBlockPos(CValidationState &state, CDiskBlockPos &pos, unsigned int nAddSize, unsigned int nHeight, uint64_t nTime, bool fKnown = false)
{
    bool fUpdatedLast = false;

    LOCK(cs_LastBlockFile);

    if (fKnown) {
        if (nLastBlockFile != pos.nFile) {
            nLastBlockFile = pos.nFile;
            infoLastBlockFile.SetNull();
            pblocktree->ReadBlockFileInfo(nLastBlockFile, infoLastBlockFile);
            fUpdatedLast = true;
        }
    } else {
        while (infoLastBlockFile.nSize + nAddSize >= MAX_BLOCKFILE_SIZE) {
            LogPrintf("Leaving block file %i: %s\n", nLastBlockFile, infoLastBlockFile.ToString());
            FlushBlockFile(true);
            nLastBlockFile++;
            infoLastBlockFile.SetNull();
            pblocktree->ReadBlockFileInfo(nLastBlockFile, infoLastBlockFile); // check whether data for the new file somehow already exist; can fail just fine
            fUpdatedLast = true;
        }
        pos.nFile = nLastBlockFile;
        pos.nPos = infoLastBlockFile.nSize;
    }

    infoLastBlockFile.nSize += nAddSize;
    infoLastBlockFile.AddBlock(nHeight, nTime);

    if (!fKnown) {
        unsigned int nOldChunks = (pos.nPos + BLOCKFILE_CHUNK_SIZE - 1) / BLOCKFILE_CHUNK_SIZE;
        unsigned int nNewChunks = (infoLastBlockFile.nSize + BLOCKFILE_CHUNK_SIZE - 1) / BLOCKFILE_CHUNK_SIZE;
        if (nNewChunks > nOldChunks) {
            if (CheckDiskSpace(nNewChunks * BLOCKFILE_CHUNK_SIZE - pos.nPos)) {
                FILE *file = OpenBlockFile(pos);
                if (file) {
                    LogPrintf("Pre-allocating up to position 0x%x in blk%05u.dat\n", nNewChunks * BLOCKFILE_CHUNK_SIZE, pos.nFile);
                    AllocateFileRange(file, pos.nPos, nNewChunks * BLOCKFILE_CHUNK_SIZE - pos.nPos);
                    fclose(file);
                }
            } else
                return state.Error("out of disk space");
        }
    }

    if (!pblocktree->WriteBlockFileInfo(nLastBlockFile, infoLastBlockFile))
        return state.Abort(_("Failed to write file info"));
    if (fUpdatedLast)
        pblocktree->WriteLastBlockFile(nLastBlockFile);

    return true;
}

bool FindUndoPos(CValidationState &state, int nFile, CDiskBlockPos &pos, unsigned int nAddSize)
{
    pos.nFile = nFile;

    LOCK(cs_LastBlockFile);

    unsigned int nNewSize;
    if (nFile == nLastBlockFile) {
        pos.nPos = infoLastBlockFile.nUndoSize;
        nNewSize = (infoLastBlockFile.nUndoSize += nAddSize);
        if (!pblocktree->WriteBlockFileInfo(nLastBlockFile, infoLastBlockFile))
            return state.Abort(_("Failed to write block info"));
    } else {
        CBlockFileInfo info;
        if (!pblocktree->ReadBlockFileInfo(nFile, info))
            return state.Abort(_("Failed to read block info"));
        pos.nPos = info.nUndoSize;
        nNewSize = (info.nUndoSize += nAddSize);
        if (!pblocktree->WriteBlockFileInfo(nFile, info))
            return state.Abort(_("Failed to write block info"));
    }

    unsigned int nOldChunks = (pos.nPos + UNDOFILE_CHUNK_SIZE - 1) / UNDOFILE_CHUNK_SIZE;
    unsigned int nNewChunks = (nNewSize + UNDOFILE_CHUNK_SIZE - 1) / UNDOFILE_CHUNK_SIZE;
    if (nNewChunks > nOldChunks) {
        if (CheckDiskSpace(nNewChunks * UNDOFILE_CHUNK_SIZE - pos.nPos)) {
            FILE *file = OpenUndoFile(pos);
            if (file) {
                LogPrintf("Pre-allocating up to position 0x%x in rev%05u.dat\n", nNewChunks * UNDOFILE_CHUNK_SIZE, pos.nFile);
                AllocateFileRange(file, pos.nPos, nNewChunks * UNDOFILE_CHUNK_SIZE - pos.nPos);
                fclose(file);
            }
        } else
            return state.Error("out of disk space");
    }

    return true;
}

#ifdef ENABLE_GCOIN
bool CheckBlockHeaderSignature(const CBlock& block, CValidationState& state)
{
    CBlockIndex *tmp = chainActive.Tip();
    if (tmp != NULL && tmp->nHeight != 0) {
        if (block.vtx.size() == 0 || block.vtx[0].vout.size() == 0)
            return state.DoS(50, error("%s() : no block vtx[0] or no block vtx[0] vout[0]", __func__),
                             REJECT_INVALID, "high-hash");

        if (!VerifyScript(block.scriptSig, block.vtx[0].vout[0].scriptPubKey, block, STANDARD_SCRIPT_VERIFY_FLAGS, 0))
            return state.DoS(50, error("%s() : verify blockheader signature error", __func__),
                             REJECT_INVALID, "high-hash");
    }
    return true;
}
#endif  // ENABLE_GCOIN

bool CheckBlockHeader(const CBlockHeader& block, CValidationState& state, bool fCheckPOW)
{
    // Check proof of work matches claimed amount
    if (fCheckPOW && !CheckProofOfWork(block.GetHash(), block.nBits))
        return state.DoS(50, error("%s() : proof of work failed", __func__),
                         REJECT_INVALID, "high-hash");

    // Check timestamp
    if (block.GetBlockTime() > GetAdjustedTime() + 2 * 60 * 60)
        return state.Invalid(error("%s() : block timestamp too far in the future", __func__),
                             REJECT_INVALID, "time-too-new");

    return true;
}

#ifdef ENABLE_GCOIN

bool EnableMining(const CBlock& block, bool& fMissPreBlock) {
    LogPrintf("%s\n",block.GetHash().ToString());
    LOCK(cs_main);

    map<uint256, CBlockIndex*>::const_iterator it = mapBlockIndex.find(block.hashPrevBlock);
    if (it == mapBlockIndex.end()) {
        fMissPreBlock = true;
        LogPrintf("Warning : %s() can't fetch preindex of block hash %s\n", __func__, block.GetHash().ToString());
        return true;
    }

    if (block.vtx.size() > 1)
        return true;

    const CBlockIndex* pindex = it->second;
    if (pindex->nHeight == 0)
        return true;
    for (int i = 0; i < COINBASE_MATURITY && pindex; i++) {
        CBlock BLOCK;
        if (!ReadBlockFromDisk(BLOCK, pindex)) {
            LogPrintf("ERROR : %s() Read block fail at block hash %s\n", __func__, pindex->GetBlockHash().ToString());
            return false;
        }
        if (BLOCK.vtx.size() > 1) {
            LogPrintf("%s() have transaction at block hash %s\n", __func__, pindex->GetBlockHash().ToString());
            return true;
        }
        pindex = pindex->pprev;
    }

    LogPrintf("ERROR : %s() Can't mining now at block height %d\n", __func__, it->second->nHeight + 1);
    return false;
}

#endif  // ENABLE_GCOIN

bool CheckBlock(const CBlock& block, CValidationState& state, bool fCheckPOW, bool fCheckMerkleRoot, bool fNCheckFork)
{

    // These are checks that are independent of context
    // that can be verified before saving an orphan block.
    if (!CheckBlockHeader(block, state, fCheckPOW))
        return false;
#ifdef ENABLE_GCOIN
    // add creater of first block to AE member List
    // TODO : erase if this first block fail.
    if (GetHeight() >= 0) {
        string addr = GetTxOutputAddr(block.vtx[0], 0);
        if (alliance_member::NumOfMembers() == 0) {
            alliance_member::Add(addr);
        }
        if (!alliance_member::IsMember(addr)) {
              LogPrintf("%s() fail : block address %s Not AE Member\n", __func__, addr);
            return false;
        }
    }
    // we don't check when verify DB now
    bool fMissPreBlock = false;
    if (block.hashPrevBlock != 0)
        if (!EnableMining(block, fMissPreBlock)) {
            LogPrintf("%s() fail : Can't Mining now\n", __func__);
            return false;
        }
#endif // ENABLE_GCOIN
    // Size limits
    if (block.vtx.empty() || block.vtx.size() > MAX_BLOCK_SIZE || ::GetSerializeSize(block, SER_NETWORK, PROTOCOL_VERSION) > MAX_BLOCK_SIZE)
        return state.DoS(100, error("%s() : size limits failed", __func__),
                         REJECT_INVALID, "bad-blk-length");

    // First transaction must be coinbase, the rest must not be
    if (block.vtx.empty() || !block.vtx[0].IsCoinBase())
        return state.DoS(100, error("%s() : first tx is not coinbase", __func__),
                         REJECT_INVALID, "bad-cb-missing");
/*    for (unsigned int i = 1; i < block.vtx.size(); i++)
        if (block.vtx[i].IsCoinBase())
            return state.DoS(100, error("%s() : more than one coinbase", __func__),
                             REJECT_INVALID, "bad-cb-multiple");
*/
    // Check transactions
    BOOST_FOREACH(const CTransaction& tx, block.vtx)
    {
        if (!CheckTransaction(tx, state))
            return error("%s() : CheckTransaction failed", __func__);
    }
    // Check for duplicate txids. This is caught by ConnectInputs(),
    // but catching it earlier avoids a potential DoS attack:
    set<uint256> uniqueTx;
    BOOST_FOREACH(const CTransaction &tx, block.vtx) {
        uniqueTx.insert(tx.GetHash());
    }
    if (uniqueTx.size() != block.vtx.size())
        return state.DoS(100, error("%s() : duplicate transaction", __func__),
                         REJECT_INVALID, "bad-txns-duplicate", true);

    unsigned int nSigOps = 0;
    BOOST_FOREACH(const CTransaction& tx, block.vtx) {
        nSigOps += GetLegacySigOpCount(tx);
    }
    if (nSigOps > MAX_BLOCK_SIGOPS)
        return state.DoS(100, error("%s() : out-of-bounds SigOpCount", __func__),
                         REJECT_INVALID, "bad-blk-sigops", true);

    // Check merkle root
    if (fCheckMerkleRoot && block.hashMerkleRoot != block.BuildMerkleTree())
        return state.DoS(100, error("%s() : hashMerkleRoot mismatch", __func__),
                         REJECT_INVALID, "bad-txnmrklroot", true);

    return true;
}

bool AcceptBlockHeader(CBlockHeader& block, CValidationState& state, CBlockIndex** ppindex)
{
    AssertLockHeld(cs_main);
    // Check for duplicate
    uint256 hash = block.GetHash();
    map<uint256, CBlockIndex*>::iterator miSelf = mapBlockIndex.find(hash);
    CBlockIndex *pindex = NULL;
    if (miSelf != mapBlockIndex.end()) {
        pindex = miSelf->second;
        if (pindex->nStatus & BLOCK_FAILED_MASK)
            return state.Invalid(error("%s() : block is marked invalid", __func__), 0, "duplicate");
    }

    CBlockIndex* pcheckpoint = Checkpoints::GetLastCheckpoint(mapBlockIndex);
    if (pcheckpoint && block.hashPrevBlock != (chainActive.Tip() ? chainActive.Tip()->GetBlockHash() : uint256(0))) {
        // Extra checks to prevent "fill up memory by spamming with bogus blocks"
        int64_t deltaTime = block.GetBlockTime() - pcheckpoint->GetBlockTime();
        if (deltaTime < 0) {
            return state.DoS(100, error("%s() : block with timestamp before last checkpoint", __func__),
                             REJECT_CHECKPOINT, "time-too-old");
        }
        if (!CheckMinWork(block.nBits, pcheckpoint->nBits, deltaTime)) {
            return state.DoS(100, error("%s() : block with too little proof-of-work", __func__),
                             REJECT_INVALID, "bad-diffbits");
        }
    }

    // Get prev block index
    CBlockIndex* pindexPrev = NULL;
    int nHeight = 0;
    if (hash != Params().HashGenesisBlock()) {
        map<uint256, CBlockIndex*>::iterator mi = mapBlockIndex.find(block.hashPrevBlock);
        if (mi == mapBlockIndex.end())
            return state.DoS(10, error("%s() : prev block not found", __func__), 0, "bad-prevblk");
        pindexPrev = (*mi).second;
        nHeight = pindexPrev->nHeight+1;

        // Check proof of work
        if (block.nBits != GetNextWorkRequired(pindexPrev, &block))
            return state.DoS(100, error("%s() : incorrect proof of work", __func__),
                             REJECT_INVALID, "bad-diffbits");

        // Check timestamp against prev
        if (block.GetBlockTime() <= pindexPrev->GetMedianTimePast())
            return state.Invalid(error("%s() : block's timestamp is too early", __func__),
                                 REJECT_INVALID, "time-too-old");


        // Check that the block chain matches the known block chain up to a checkpoint
        if (!Checkpoints::CheckBlock(nHeight, hash))
            return state.DoS(100, error("%s() : rejected by checkpoint lock-in at %d", __func__, nHeight),
                             REJECT_CHECKPOINT, "checkpoint mismatch");

        // Don't accept any forks from the main chain prior to last checkpoint
        CBlockIndex* pcheckpoint = Checkpoints::GetLastCheckpoint(mapBlockIndex);
        if (pcheckpoint && nHeight < pcheckpoint->nHeight)
            return state.DoS(100, error("%s() : forked chain older than last checkpoint (height %d)", __func__, nHeight));

        // Reject block.nVersion=1 blocks when 95% (75% on testnet) of the network has upgraded:
        if (block.nVersion < 2 &&
            CBlockIndex::IsSuperMajority(2, pindexPrev, Params().RejectBlockOutdatedMajority())) {
            return state.Invalid(error("%s() : rejected nVersion=1 block", __func__),
                                 REJECT_OBSOLETE, "bad-version");
        }
    }

    if (pindex == NULL)
        pindex = AddToBlockIndex(block);

    if (ppindex)
        *ppindex = pindex;

    return true;
}

bool AcceptBlock(CBlock& block, CValidationState& state, CBlockIndex** ppindex, CDiskBlockPos* dbp)
{
    AssertLockHeld(cs_main);
    CBlockIndex *&pindex = *ppindex;
    if (!AcceptBlockHeader(block, state, &pindex))
        return false;

    if (!CheckBlock(block, state, true, true, true)) {
        if (state.IsInvalid() && !state.CorruptionPossible())
            pindex->nStatus |= BLOCK_FAILED_VALID;
        return false;
    }

#ifdef ENABLE_GCOIN
    if (!CheckBlockHeaderSignature(block, state))
        return false;
#endif

    int nHeight = pindex->nHeight;

    // Check that all transactions are finalized
    BOOST_FOREACH(const CTransaction& tx, block.vtx)
        if (!IsFinalTx(tx, nHeight, block.GetBlockTime())) {
            pindex->nStatus |= BLOCK_FAILED_VALID;
            return state.DoS(10, error("%s() : contains a non-final transaction", __func__),
                             REJECT_INVALID, "bad-txns-nonfinal");
        }

    // Write block to history file
    try {
        unsigned int nBlockSize = ::GetSerializeSize(block, SER_DISK, CLIENT_VERSION);
        CDiskBlockPos blockPos;
        if (dbp != NULL)
            blockPos = *dbp;
        if (!FindBlockPos(state, blockPos, nBlockSize+8, nHeight, block.GetBlockTime(), dbp != NULL))
            return error("%s() : FindBlockPos failed", __func__);
        if (dbp == NULL)
            if (!WriteBlockToDisk(block, blockPos))
                return state.Abort(_("Failed to write block"));
        if (!ReceivedBlockTransactions(block, state, pindex, blockPos))
            return error("%s() : ReceivedBlockTransactions failed", __func__);
    } catch(std::runtime_error &e) {
        return state.Abort(_("System error: ") + e.what());
    }

    return true;
}

bool CBlockIndex::IsSuperMajority(int minVersion, const CBlockIndex* pstart, unsigned int nRequired)
{
    unsigned int nToCheck = Params().ToCheckBlockUpgradeMajority();
    unsigned int nFound = 0;
    for (unsigned int i = 0; i < nToCheck && nFound < nRequired && pstart != NULL; i++) {
        if (pstart->nVersion >= minVersion)
            ++nFound;
        pstart = pstart->pprev;
    }
    return (nFound >= nRequired);
}

/** Turn the lowest '1' bit in the binary representation of a number into a '0'. */
int static inline InvertLowestOne(int n) { return n & (n - 1); }

/** Compute what height to jump back to with the CBlockIndex::pskip pointer. */
int static inline GetSkipHeight(int height)
{
    if (height < 2)
        return 0;

    // Determine which height to jump back to. Any number strictly lower than height is acceptable,
    // but the following expression seems to perform well in simulations (max 110 steps to go back
    // up to 2**18 blocks).
    return (height & 1) ? InvertLowestOne(InvertLowestOne(height - 1)) + 1 : InvertLowestOne(height);
}

CBlockIndex* CBlockIndex::GetAncestor(int height)
{
    if (height > nHeight || height < 0)
        return NULL;

    CBlockIndex* pindexWalk = this;
    int heightWalk = nHeight;
    while (heightWalk > height) {
        int heightSkip = GetSkipHeight(heightWalk);
        int heightSkipPrev = GetSkipHeight(heightWalk - 1);
        if (heightSkip == height ||
            (heightSkip > height && !(heightSkipPrev < heightSkip - 2 &&
                                      heightSkipPrev >= height))) {
            // Only follow pskip if pprev->pskip isn't better than pskip->pprev.
            pindexWalk = pindexWalk->pskip;
            heightWalk = heightSkip;
        } else {
            pindexWalk = pindexWalk->pprev;
            heightWalk--;
        }
    }
    return pindexWalk;
}

const CBlockIndex* CBlockIndex::GetAncestor(int height) const
{
    return const_cast<CBlockIndex*>(this)->GetAncestor(height);
}

void CBlockIndex::BuildSkip()
{
    if (pprev)
        pskip = pprev->GetAncestor(GetSkipHeight(nHeight));
}

void PushGetBlocks(CNode* pnode, CBlockIndex* pindexBegin, uint256 hashEnd)
{
    AssertLockHeld(cs_main);
    // Filter out duplicate requests
    if (pindexBegin == pnode->pindexLastGetBlocksBegin && hashEnd == pnode->hashLastGetBlocksEnd)
        return;

    pnode->pindexLastGetBlocksBegin = pindexBegin;
    pnode->hashLastGetBlocksEnd = hashEnd;

    pnode->PushMessage("getblocks", chainActive.GetLocator(pindexBegin), hashEnd);
}

bool ProcessBlock(CValidationState &state, CNode* pfrom, CBlock* pblock, CDiskBlockPos *dbp)
{
    // Check for duplicate
    uint256 hash = pblock->GetHash();

    LOCK(cs_main);
    if (mapBlockIndex.count(hash))
        return state.Invalid(error("%s() : already have block %d %s", __func__, mapBlockIndex[hash]->nHeight, hash.ToString()), 0, "duplicate");
    if (mapOrphanBlocks.count(hash))
        return state.Invalid(error("%s() : already have block (orphan) %s", __func__, hash.ToString()), 0, "duplicate");

    // Preliminary checks
    if (!CheckBlock(*pblock, state, true, true, true))
        return error("%s() : CheckBlock FAILED", __func__);

    // If we don't already have its previous block (with full data), shunt it off to holding area until we get it
    map<uint256, CBlockIndex*>::iterator it = mapBlockIndex.find(pblock->hashPrevBlock);
    if (pblock->hashPrevBlock != 0 && (it == mapBlockIndex.end() || !(it->second->nStatus & BLOCK_HAVE_DATA))) {
        LogPrintf("%s() : ORPHAN BLOCK %lu, prev=%s\n", __func__, (unsigned long)mapOrphanBlocks.size(), pblock->hashPrevBlock.ToString());

        // Accept orphans as long as there is a node to request its parents from
        if (pfrom) {
            PruneOrphanBlocks();
            COrphanBlock* pblock2 = new COrphanBlock();

            CDataStream ss(SER_DISK, CLIENT_VERSION);
            ss << *pblock;
            pblock2->vchBlock = vector<unsigned char>(ss.begin(), ss.end());
            pblock2->hashBlock = hash;
            pblock2->hashPrev = pblock->hashPrevBlock;
            mapOrphanBlocks.insert(make_pair(hash, pblock2));
            mapOrphanBlocksByPrev.insert(make_pair(pblock2->hashPrev, pblock2));
            // Ask this guy to fill in what we're missing
            PushGetBlocks(pfrom, chainActive.Tip(), GetOrphanRoot(hash));
        }
        return true;
    }

    // Store to disk
    CBlockIndex *pindex = NULL;
    bool ret = AcceptBlock(*pblock, state, &pindex, dbp);
    if (!ret)
        return error("%s() : AcceptBlock FAILED", __func__);

    // Recursively process any orphan blocks that depended on this one
    vector<uint256> vWorkQueue;
    vWorkQueue.push_back(hash);
    for (unsigned int i = 0; i < vWorkQueue.size(); i++) {
        uint256 hashPrev = vWorkQueue[i];
        for (multimap<uint256, COrphanBlock*>::iterator mi = mapOrphanBlocksByPrev.lower_bound(hashPrev);
             mi != mapOrphanBlocksByPrev.upper_bound(hashPrev);
             ++mi) {
            CBlock block;

            CDataStream ss(mi->second->vchBlock, SER_DISK, CLIENT_VERSION);
            ss >> block;

            block.BuildMerkleTree();
            // Use a dummy CValidationState so someone can't setup nodes to counter-DoS based on orphan resolution (that is, feeding people an invalid block based on LegitBlockX in order to get anyone relaying LegitBlockX banned)
            CValidationState stateDummy;
            CBlockIndex *pindexChild = NULL;
            if (AcceptBlock(block, stateDummy, &pindexChild))
                vWorkQueue.push_back(mi->second->hashBlock);
            mapOrphanBlocks.erase(mi->second->hashBlock);
            delete mi->second;
        }
        mapOrphanBlocksByPrev.erase(hashPrev);
    }


    if (!ActivateBestChain(state, pblock))
        return error("%s() : ActivateBestChain failed", __func__);

    return true;
}








CMerkleBlock::CMerkleBlock(const CBlock& block, CBloomFilter& filter)
{
    header = block.GetBlockHeader();

    vector<bool> vMatch;
    vector<uint256> vHashes;

    vMatch.reserve(block.vtx.size());
    vHashes.reserve(block.vtx.size());

    for (unsigned int i = 0; i < block.vtx.size(); i++) {
        const uint256& hash = block.vtx[i].GetHash();
        if (filter.IsRelevantAndUpdate(block.vtx[i])) {
            vMatch.push_back(true);
            vMatchedTxn.push_back(make_pair(i, hash));
        } else
            vMatch.push_back(false);
        vHashes.push_back(hash);
    }

    txn = CPartialMerkleTree(vHashes, vMatch);
}








uint256 CPartialMerkleTree::CalcHash(int height, unsigned int pos, const vector<uint256> &vTxid)
{
    if (height == 0) {
        // hash at height 0 is the txids themself
        return vTxid[pos];
    } else {
        // calculate left hash
        uint256 left = CalcHash(height-1, pos*2, vTxid), right;
        // calculate right hash if not beyong the end of the array - copy left hash otherwise1
        if (pos*2+1 < CalcTreeWidth(height-1))
            right = CalcHash(height-1, pos*2+1, vTxid);
        else
            right = left;
        // combine subhashes
        return Hash(BEGIN(left), END(left), BEGIN(right), END(right));
    }
}

void CPartialMerkleTree::TraverseAndBuild(int height, unsigned int pos, const vector<uint256> &vTxid, const vector<bool> &vMatch)
{
    // determine whether this node is the parent of at least one matched txid
    bool fParentOfMatch = false;
    for (unsigned int p = pos << height; p < (pos+1) << height && p < nTransactions; p++)
        fParentOfMatch |= vMatch[p];
    // store as flag bit
    vBits.push_back(fParentOfMatch);
    if (height==0 || !fParentOfMatch) {
        // if at height 0, or nothing interesting below, store hash and stop
        vHash.push_back(CalcHash(height, pos, vTxid));
    } else {
        // otherwise, don't store any hash, but descend into the subtrees
        TraverseAndBuild(height-1, pos*2, vTxid, vMatch);
        if (pos*2+1 < CalcTreeWidth(height-1))
            TraverseAndBuild(height-1, pos*2+1, vTxid, vMatch);
    }
}

uint256 CPartialMerkleTree::TraverseAndExtract(int height, unsigned int pos, unsigned int &nBitsUsed, unsigned int &nHashUsed, vector<uint256> &vMatch)
{
    if (nBitsUsed >= vBits.size()) {
        // overflowed the bits array - failure
        fBad = true;
        return 0;
    }
    bool fParentOfMatch = vBits[nBitsUsed++];
    if (height==0 || !fParentOfMatch) {
        // if at height 0, or nothing interesting below, use stored hash and do not descend
        if (nHashUsed >= vHash.size()) {
            // overflowed the hash array - failure
            fBad = true;
            return 0;
        }
        const uint256 &hash = vHash[nHashUsed++];
        if (height==0 && fParentOfMatch) // in case of height 0, we have a matched txid
            vMatch.push_back(hash);
        return hash;
    } else {
        // otherwise, descend into the subtrees to extract matched txids and hashes
        uint256 left = TraverseAndExtract(height-1, pos*2, nBitsUsed, nHashUsed, vMatch), right;
        if (pos*2+1 < CalcTreeWidth(height-1))
            right = TraverseAndExtract(height-1, pos*2+1, nBitsUsed, nHashUsed, vMatch);
        else
            right = left;
        // and combine them before returning
        return Hash(BEGIN(left), END(left), BEGIN(right), END(right));
    }
}

CPartialMerkleTree::CPartialMerkleTree(const vector<uint256> &vTxid, const vector<bool> &vMatch) : nTransactions(vTxid.size()), fBad(false)
{
    // reset state
    vBits.clear();
    vHash.clear();

    // calculate height of tree
    int nHeight = 0;
    while (CalcTreeWidth(nHeight) > 1)
        nHeight++;

    // traverse the partial tree
    TraverseAndBuild(nHeight, 0, vTxid, vMatch);
}

CPartialMerkleTree::CPartialMerkleTree() : nTransactions(0), fBad(true) {}

uint256 CPartialMerkleTree::ExtractMatches(vector<uint256> &vMatch)
{
    vMatch.clear();
    // An empty set will not work
    if (nTransactions == 0)
        return 0;
    // check for excessively high numbers of transactions
    if (nTransactions > MAX_BLOCK_SIZE / 60) // 60 is the lower bound for the size of a serialized CTransaction
        return 0;
    // there can never be more hashes provided than one for every txid
    if (vHash.size() > nTransactions)
        return 0;
    // there must be at least one bit per node in the partial tree, and at least one node per hash
    if (vBits.size() < vHash.size())
        return 0;
    // calculate height of tree
    int nHeight = 0;
    while (CalcTreeWidth(nHeight) > 1)
        nHeight++;
    // traverse the partial tree
    unsigned int nBitsUsed = 0, nHashUsed = 0;
    uint256 hashMerkleRoot = TraverseAndExtract(nHeight, 0, nBitsUsed, nHashUsed, vMatch);
    // verify that no problems occured during the tree traversal
    if (fBad)
        return 0;
    // verify that all bits were consumed (except for the padding caused by serializing it as a byte sequence)
    if ((nBitsUsed+7)/8 != (vBits.size()+7)/8)
        return 0;
    // verify that all hashes were consumed
    if (nHashUsed != vHash.size())
        return 0;
    return hashMerkleRoot;
}







bool AbortNode(const string &strMessage)
{
    strMiscWarning = strMessage;
    LogPrintf("*** %s\n", strMessage);
    uiInterface.ThreadSafeMessageBox(strMessage, "", CClientUIInterface::MSG_ERROR);
    StartShutdown();
    return false;
}

bool CheckDiskSpace(uint64_t nAdditionalBytes)
{
    uint64_t nFreeBytesAvailable = boost::filesystem::space(GetDataDir()).available;

    // Check for nMinDiskSpace bytes (currently 50MB)
    if (nFreeBytesAvailable < nMinDiskSpace + nAdditionalBytes)
        return AbortNode(_("Error: Disk space is low!"));

    return true;
}

FILE* OpenDiskFile(const CDiskBlockPos &pos, const char *prefix, bool fReadOnly)
{
    if (pos.IsNull())
        return NULL;
    boost::filesystem::path path = GetDataDir() / "blocks" / strprintf("%s%05u.dat", prefix, pos.nFile);
    boost::filesystem::create_directories(path.parent_path());
    FILE* file = fopen(path.string().c_str(), "rb+");
    if (!file && !fReadOnly)
        file = fopen(path.string().c_str(), "wb+");
    if (!file) {
        LogPrintf("Unable to open file %s\n", path.string());
        return NULL;
    }
    if (pos.nPos) {
        if (fseek(file, pos.nPos, SEEK_SET)) {
            LogPrintf("Unable to seek to position %u of %s\n", pos.nPos, path.string());
            fclose(file);
            return NULL;
        }
    }
    return file;
}

FILE* OpenBlockFile(const CDiskBlockPos &pos, bool fReadOnly)
{
    return OpenDiskFile(pos, "blk", fReadOnly);
}

FILE* OpenUndoFile(const CDiskBlockPos &pos, bool fReadOnly)
{
    return OpenDiskFile(pos, "rev", fReadOnly);
}

CBlockIndex * InsertBlockIndex(uint256 hash)
{
    if (hash == 0)
        return NULL;

    // Return existing
    map<uint256, CBlockIndex*>::iterator mi = mapBlockIndex.find(hash);
    if (mi != mapBlockIndex.end())
        return (*mi).second;

    // Create new
    CBlockIndex* pindexNew = new CBlockIndex();
    if (!pindexNew)
        throw runtime_error(_(__func__) + "() : new CBlockIndex failed");
    mi = mapBlockIndex.insert(make_pair(hash, pindexNew)).first;
    pindexNew->phashBlock = &((*mi).first);

    return pindexNew;
}

bool static LoadBlockIndexDB()
{
    if (!pblocktree->LoadBlockIndexGuts())
        return false;

    boost::this_thread::interruption_point();

    // Calculate nChainWork
    vector<pair<int, CBlockIndex*> > vSortedByHeight;
    vSortedByHeight.reserve(mapBlockIndex.size());
    BOOST_FOREACH(const PAIRTYPE(uint256, CBlockIndex*)& item, mapBlockIndex) {
        CBlockIndex* pindex = item.second;
        vSortedByHeight.push_back(make_pair(pindex->nHeight, pindex));
    }
    sort(vSortedByHeight.begin(), vSortedByHeight.end());
    BOOST_FOREACH(const PAIRTYPE(int, CBlockIndex*)& item, vSortedByHeight) {
        CBlockIndex* pindex = item.second;
        pindex->nChainWork = (pindex->pprev ? pindex->pprev->nChainWork : 0) + pindex->GetBlockWork();
        pindex->nChainTx = (pindex->pprev ? pindex->pprev->nChainTx : 0) + pindex->nTx;
        if (pindex->IsValid(BLOCK_VALID_TRANSACTIONS))
            setBlockIndexValid.insert(pindex);
        if (pindex->nStatus & BLOCK_FAILED_MASK && (!pindexBestInvalid || pindex->nChainWork > pindexBestInvalid->nChainWork))
            pindexBestInvalid = pindex;
        if (pindex->pprev)
            pindex->BuildSkip();
    }

    // Load block file info
    pblocktree->ReadLastBlockFile(nLastBlockFile);
    LogPrintf("%s(): last block file = %i\n", __func__, nLastBlockFile);
    if (pblocktree->ReadBlockFileInfo(nLastBlockFile, infoLastBlockFile))
        LogPrintf("%s(): last block file info: %s\n", __func__, infoLastBlockFile.ToString());

    // Check presence of blk files
    LogPrintf("Checking all blk files are present...\n");
    set<int> setBlkDataFiles;
    BOOST_FOREACH(const PAIRTYPE(uint256, CBlockIndex*)& item, mapBlockIndex) {
        CBlockIndex* pindex = item.second;
        if (pindex->nStatus & BLOCK_HAVE_DATA) {
            setBlkDataFiles.insert(pindex->nFile);
        }
    }
    for (set<int>::iterator it = setBlkDataFiles.begin(); it != setBlkDataFiles.end(); it++) {
        CDiskBlockPos pos(*it, 0);
        if (!CAutoFile(OpenBlockFile(pos, true), SER_DISK, CLIENT_VERSION)) {
            return false;
        }
    }

    // Check whether we need to continue reindexing
    bool fReindexing = false;
    pblocktree->ReadReindexing(fReindexing);
    fReindex |= fReindexing;

    // Check whether we have a transaction index
    pblocktree->ReadFlag("txindex", fTxIndex);
    LogPrintf("%s(): transaction index %s\n", __func__, fTxIndex ? "enabled" : "disabled");

    // Load pointer to end of best chain
    map<uint256, CBlockIndex*>::iterator it = mapBlockIndex.find(pcoinsTip->GetBestBlock());
    if (it == mapBlockIndex.end())
        return true;
    chainActive.SetTip(it->second);
    LogPrintf("%s(): hashBestChain=%s height=%d date=%s progress=%f\n",
        __func__,
        chainActive.Tip()->GetBlockHash().ToString(), chainActive.Height(),
        DateTimeStrFormat("%Y-%m-%d %H:%M:%S", chainActive.Tip()->GetBlockTime()),
        Checkpoints::GuessVerificationProgress(chainActive.Tip()));

    return true;
}

CVerifyDB::CVerifyDB()
{
    uiInterface.ShowProgress(_("Verifying blocks..."), 0);
}

CVerifyDB::~CVerifyDB()
{
    uiInterface.ShowProgress("", 100);
}


#ifdef ENABLE_GCOIN

// Reconstruct MemberList, VoteList, BanVoteList and LicenseList.
// it needed when we restart bitcoind
bool UpdateList(const CBlockIndex *pindex, bool& fInitial)
{
    LogPrintf("UpdateList\n");
    if (fInitial) {
        alliance_member::RemoveAll();
        VoteList.clear();
        BanVoteList.clear();
        color_license::RemoveAll();
        fInitial = false;
    }
    // scan the best_chain's block
    CBlock block;
    // Question: if ReadBlockFromDisk fail, should we put error message and reject?
    // Now: ignore ReadFail Block and continue checking.
    if (!ReadBlockFromDisk(block, pindex))
        return true;
    // creater of first block must be AE
    if (pindex->nHeight == 1 && alliance_member::NumOfMembers() == 0) {
        string addr = GetTxOutputAddr(block.vtx[0], 0);
        alliance_member::Add(addr);
    }
    // scan all transaction (no need to check vtx[0])
    for (unsigned int i = 1; i < block.vtx.size(); ++i) {
        if (!type_transaction_handler::GetHandler(block.vtx[i].type)->Apply(
                &block, block.vtx[i])) {
            return false;
        }
    }
    return true;
}
#endif // ENABLE_GCOIN
bool CVerifyDB::VerifyDB(int nCheckLevel, int nCheckDepth)
{
    LOCK(cs_main);
    if (chainActive.Tip() == NULL || chainActive.Tip()->pprev == NULL)
        return true;
    // Verify blocks in the best chain
    if (nCheckDepth <= 0)
        nCheckDepth = 1000000000; // suffices until the year 19000
    if (nCheckDepth > chainActive.Height())
        nCheckDepth = chainActive.Height();
    nCheckLevel = std::max(0, std::min(4, nCheckLevel));
    LogPrintf("Verifying last %i blocks at level %i\n", nCheckDepth, nCheckLevel);
    CCoinsViewCache coins(*pcoinsTip, true);
    CBlockIndex* pindexState = chainActive.Tip();
    CBlockIndex* pindexFailure = NULL;
    int nGoodTransactions = 0;
    CValidationState state;
    bool fInitial = true;
    bool fCheck = false;
    for (CBlockIndex* pindex = chainActive.Genesis(); pindex; pindex = chainActive.Next(pindex)) {
        if (pindex == chainActive.Genesis()) continue;
        boost::this_thread::interruption_point();
        uiInterface.ShowProgress(_("Verifying blocks..."), std::max(1, std::min(99, (int)(((double)(chainActive.Height() - pindex->nHeight)) / (double)nCheckDepth * (nCheckLevel >= 4 ? 50 : 100)))));
        if (pindex->nHeight >= chainActive.Height() - nCheckDepth)
            fCheck = true;

        CBlock block;
        // check level 0: read from disk
        if (!ReadBlockFromDisk(block, pindex))
            return error("%s() : *** ReadBlockFromDisk failed at %d, hash=%s", __func__, pindex->nHeight, pindex->GetBlockHash().ToString());

        // check level 1: verify block validity
        if (fCheck && nCheckLevel >= 1 && !CheckBlock(block, state, true, true))
            return error("%s() : *** found bad block at %d, hash=%s\n", __func__, pindex->nHeight, pindex->GetBlockHash().ToString());
#ifdef ENABLE_GCOIN
        if (!UpdateList(pindex, fInitial))
            return false;
#endif // ENABLE_GCOIN
        // check level 2: verify undo validity
        if (fCheck && nCheckLevel >= 2 && pindex) {
            CBlockUndo undo;
            CDiskBlockPos pos = pindex->GetUndoPos();
            if (!pos.IsNull()) {
                if (!undo.ReadFromDisk(pos, pindex->pprev->GetBlockHash()))
                    return error("%s() : *** found bad undo data at %d, hash=%s\n", __func__, pindex->nHeight, pindex->GetBlockHash().ToString());
            }
        }
        // check level 3: check for inconsistencies during memory-only disconnect of tip blocks
        if (fCheck && nCheckLevel >= 3 && pindex == pindexState && (coins.GetCacheSize() + pcoinsTip->GetCacheSize()) <= nCoinCacheSize) {
            bool fClean = true;
            if (!DisconnectBlock(block, state, pindex, coins, &fClean))
                return error("%s() : *** irrecoverable inconsistency in block data at %d, hash=%s", __func__, pindex->nHeight, pindex->GetBlockHash().ToString());
            pindexState = pindex->pprev;
            if (!fClean) {
                nGoodTransactions = 0;
                pindexFailure = pindex;
            } else
                nGoodTransactions += block.vtx.size();
        }
    }
    if (pindexFailure)
        return error("%s() : *** coin database inconsistencies found (last %i blocks, %i good transactions before that)\n", __func__,
                     chainActive.Height() - pindexFailure->nHeight + 1, nGoodTransactions);

    // check level 4: try reconnecting blocks
    if (fCheck && nCheckLevel >= 4) {
        CBlockIndex *pindex = pindexState;
        while (pindex != chainActive.Tip()) {
            boost::this_thread::interruption_point();
            uiInterface.ShowProgress(_("Verifying blocks..."), std::max(1, std::min(99, 100 - (int)(((double)(chainActive.Height() - pindex->nHeight)) / (double)nCheckDepth * 50))));
            pindex = chainActive.Next(pindex);
            CBlock block;
            if (!ReadBlockFromDisk(block, pindex))
                return error("%s() : *** ReadBlockFromDisk failed at %d, hash=%s", __func__, pindex->nHeight, pindex->GetBlockHash().ToString());
            if (!ConnectBlock(block, state, pindex, coins))
                return error("%s() : *** found unconnectable block at %d, hash=%s", __func__, pindex->nHeight, pindex->GetBlockHash().ToString());
        }
    }

    LogPrintf("No coin database inconsistencies in last %i blocks (%i transactions)\n", chainActive.Height() - pindexState->nHeight, nGoodTransactions);

    return true;
}

void UnloadBlockIndex()
{
    mapBlockIndex.clear();
    setBlockIndexValid.clear();
    chainActive.SetTip(NULL);
    pindexBestInvalid = NULL;
}

bool LoadBlockIndex()
{
    // Load block index from databases
    if (!fReindex && !LoadBlockIndexDB())
        return false;
    return true;
}


bool InitBlockIndex() {
    LOCK(cs_main);
    // Check whether we're already initialized
    if (chainActive.Genesis() != NULL)
        return true;

    // Use the provided setting for -txindex in the new database
    fTxIndex = GetBoolArg("-txindex", false);
    pblocktree->WriteFlag("txindex", fTxIndex);
    LogPrintf("Initializing databases...\n");

    // Only add the genesis block if not reindexing (in which case we reuse the one already on disk)
    if (!fReindex) {
        try {
            CBlock &block = const_cast<CBlock&>(Params().GenesisBlock());
            // Start new block file
            unsigned int nBlockSize = ::GetSerializeSize(block, SER_DISK, CLIENT_VERSION);
            CDiskBlockPos blockPos;
            CValidationState state;
            if (!FindBlockPos(state, blockPos, nBlockSize+8, 0, block.GetBlockTime()))
                return error("%s() : FindBlockPos failed", __func__);
            if (!WriteBlockToDisk(block, blockPos))
                return error("%s() : writing genesis block to disk failed", __func__);
            CBlockIndex *pindex = AddToBlockIndex(block);
            if (!ReceivedBlockTransactions(block, state, pindex, blockPos))
                return error("%s() : genesis block not accepted", __func__);
            if (!ActivateBestChain(state, &block))
                return error("%s() : genesis block cannot be activated", __func__);
        } catch(std::runtime_error &e) {
            return error("%s() : failed to initialize block database: %s", __func__, e.what());
        }
    }

    return true;
}



void PrintBlockTree()
{
    AssertLockHeld(cs_main);
    // pre-compute tree structure
    map<CBlockIndex*, vector<CBlockIndex*> > mapNext;
    for (map<uint256, CBlockIndex*>::iterator mi = mapBlockIndex.begin(); mi != mapBlockIndex.end(); ++mi) {
        CBlockIndex* pindex = (*mi).second;
        mapNext[pindex->pprev].push_back(pindex);
        // test
        //while (rand() % 3 == 0)
        //    mapNext[pindex->pprev].push_back(pindex);
    }

    vector<pair<int, CBlockIndex*> > vStack;
    vStack.push_back(make_pair(0, chainActive.Genesis()));

    int nPrevCol = 0;
    while (!vStack.empty()) {
        int nCol = vStack.back().first;
        CBlockIndex* pindex = vStack.back().second;
        vStack.pop_back();

        // print split or gap
        if (nCol > nPrevCol) {
            for (int i = 0; i < nCol-1; i++)
                LogPrintf("| ");
            LogPrintf("|\\\n");
        } else if (nCol < nPrevCol) {
            for (int i = 0; i < nCol; i++)
                LogPrintf("| ");
            LogPrintf("|\n");
       }
        nPrevCol = nCol;

        // print columns
        for (int i = 0; i < nCol; i++)
            LogPrintf("| ");

        // print item
        CBlock block;
        ReadBlockFromDisk(block, pindex);
        LogPrintf("%d (blk%05u.dat:0x%x)  %s  tx %u\n",
            pindex->nHeight,
            pindex->GetBlockPos().nFile, pindex->GetBlockPos().nPos,
            DateTimeStrFormat("%Y-%m-%d %H:%M:%S", block.GetBlockTime()),
            block.vtx.size());

        // put the main time-chain first
        vector<CBlockIndex*>& vNext = mapNext[pindex];
        for (unsigned int i = 0; i < vNext.size(); i++)
            if (chainActive.Next(vNext[i])) {
                std::swap(vNext[0], vNext[i]);
                break;
            }


        // iterate children
        for (unsigned int i = 0; i < vNext.size(); i++)
            vStack.push_back(make_pair(nCol+i, vNext[i]));
    }
}

bool LoadExternalBlockFile(FILE* fileIn, CDiskBlockPos *dbp)
{
    int64_t nStart = GetTimeMillis();

    int nLoaded = 0;
    try {
        CBufferedFile blkdat(fileIn, 2*MAX_BLOCK_SIZE, MAX_BLOCK_SIZE+8, SER_DISK, CLIENT_VERSION);
        uint64_t nStartByte = 0;
        if (dbp) {
            // (try to) skip already indexed part
            CBlockFileInfo info;
            if (pblocktree->ReadBlockFileInfo(dbp->nFile, info)) {
                nStartByte = info.nSize;
                blkdat.Seek(info.nSize);
            }
        }
        uint64_t nRewind = blkdat.GetPos();
        while (!blkdat.eof()) {
            boost::this_thread::interruption_point();

            blkdat.SetPos(nRewind);
            nRewind++; // start one byte further next time, in case of failure
            blkdat.SetLimit(); // remove former limit
            unsigned int nSize = 0;
            try {
                // locate a header
                unsigned char buf[MESSAGE_START_SIZE];
                blkdat.FindByte(Params().MessageStart()[0]);
                nRewind = blkdat.GetPos()+1;
                blkdat >> FLATDATA(buf);
                if (memcmp(buf, Params().MessageStart(), MESSAGE_START_SIZE))
                    continue;
                // read size
                blkdat >> nSize;
                if (nSize < 80 || nSize > MAX_BLOCK_SIZE)
                    continue;
            } catch (exception &e) {
                // no valid block header found; don't complain
                break;
            }
            try {
                // read block
                uint64_t nBlockPos = blkdat.GetPos();
                blkdat.SetLimit(nBlockPos + nSize);
                CBlock block;
                blkdat >> block;
                nRewind = blkdat.GetPos();

                // process block
                if (nBlockPos >= nStartByte) {
                    if (dbp)
                        dbp->nPos = nBlockPos;
                    CValidationState state;
                    if (ProcessBlock(state, NULL, &block, dbp))
                        nLoaded++;
                    if (state.IsError())
                        break;
                }
            } catch (exception &e) {
                LogPrintf("%s : Deserialize or I/O error - %s", __func__, e.what());
            }
        }
        fclose(fileIn);
    } catch(std::runtime_error &e) {
        AbortNode(_("Error: system error: ") + e.what());
    }
    if (nLoaded > 0)
        LogPrintf("Loaded %i blocks from external file in %dms\n", nLoaded, GetTimeMillis() - nStart);
    return nLoaded > 0;
}

//////////////////////////////////////////////////////////////////////////////
//
// CAlert
//

string GetWarnings(string strFor)
{
    int nPriority = 0;
    string strStatusBar;
    string strRPC;

    if (GetBoolArg("-testsafemode", false))
        strRPC = "test";

    if (!CLIENT_VERSION_IS_RELEASE)
        strStatusBar = _("This is a pre-release test build - use at your own risk - do not use for mining or merchant applications");

    // Misc warnings like out of disk space and clock is wrong
    if (strMiscWarning != "") {
        nPriority = 1000;
        strStatusBar = strMiscWarning;
    }

    if (fLargeWorkForkFound) {
        nPriority = 2000;
        strStatusBar = strRPC = _("Warning: The network does not appear to fully agree! Some miners appear to be experiencing issues.");
    } else if (fLargeWorkInvalidChainFound) {
        nPriority = 2000;
        strStatusBar = strRPC = _("Warning: We do not appear to fully agree with our peers! You may need to upgrade, or other nodes may need to upgrade.");
    }

    // Alerts
    {
        LOCK(cs_mapAlerts);
        BOOST_FOREACH(PAIRTYPE(const uint256, CAlert)& item, mapAlerts) {
            const CAlert& alert = item.second;
            if (alert.AppliesToMe() && alert.nPriority > nPriority) {
                nPriority = alert.nPriority;
                strStatusBar = alert.strStatusBar;
            }
        }
    }

    if (strFor == "statusbar")
        return strStatusBar;
    else if (strFor == "rpc")
        return strRPC;
    assert(!"GetWarnings() : invalid parameter");
    return "error";
}








//////////////////////////////////////////////////////////////////////////////
//
// Messages
//


bool static AlreadyHave(const CInv& inv)
{
    switch (inv.type) {
    case MSG_TX:
        {
            bool txInMap = false;
            txInMap = mempool.exists(inv.hash);
            return txInMap || mapOrphanTransactions.count(inv.hash) ||
                pcoinsTip->HaveCoins(inv.hash);
        }
    case MSG_BLOCK:
        return mapBlockIndex.count(inv.hash) ||
               mapOrphanBlocks.count(inv.hash);
    }
    // Don't know what it is, just say we already got one
    return true;
}


void static ProcessGetData(CNode* pfrom)
{
    std::deque<CInv>::iterator it = pfrom->vRecvGetData.begin();

    vector<CInv> vNotFound;

    LOCK(cs_main);

    while (it != pfrom->vRecvGetData.end()) {
        // Don't bother if send buffer is too full to respond anyway
        if (pfrom->nSendSize >= SendBufferSize())
            break;

        const CInv &inv = *it;
        {
            boost::this_thread::interruption_point();
            it++;

            if (inv.type == MSG_BLOCK || inv.type == MSG_FILTERED_BLOCK) {
                bool send = false;
                map<uint256, CBlockIndex*>::iterator mi = mapBlockIndex.find(inv.hash);
                if (mi != mapBlockIndex.end()) {
                    // If the requested block is at a height below our last
                    // checkpoint, only serve it if it's in the checkpointed chain
                    int nHeight = mi->second->nHeight;
                    CBlockIndex* pcheckpoint = Checkpoints::GetLastCheckpoint(mapBlockIndex);
                    if (pcheckpoint && nHeight < pcheckpoint->nHeight) {
                        if (!chainActive.Contains(mi->second))
                            LogPrintf("%s(): ignoring request for old block that isn't in the main chain\n", __func__);
                        else
                            send = true;
                    } else
                        send = true;
                }
                if (send) {
                    // Send block from disk
                    CBlock block;
                    if (!ReadBlockFromDisk(block, (*mi).second))
                        assert(!"cannot load block from disk");
                    if (inv.type == MSG_BLOCK)
                        pfrom->PushMessage("block", block);
                    else { // MSG_FILTERED_BLOCK)
                        LOCK(pfrom->cs_filter);
                        if (pfrom->pfilter) {
                            CMerkleBlock merkleBlock(block, *pfrom->pfilter);
                            pfrom->PushMessage("merkleblock", merkleBlock);
                            // CMerkleBlock just contains hashes, so also push any transactions in the block the client did not see
                            // This avoids hurting performance by pointlessly requiring a round-trip
                            // Note that there is currently no way for a node to request any single transactions we didnt send here -
                            // they must either disconnect and retry or request the full block.
                            // Thus, the protocol spec specified allows for us to provide duplicate txn here,
                            // however we MUST always provide at least what the remote peer needs
                            typedef pair<unsigned int, uint256> PairType;
                            BOOST_FOREACH(PairType& pair, merkleBlock.vMatchedTxn)
                                if (!pfrom->setInventoryKnown.count(CInv(MSG_TX, pair.second)))
                                    pfrom->PushMessage("tx", block.vtx[pair.first]);
                        }
                        // else
                            // no response
                    }

                    // Trigger them to send a getblocks request for the next batch of inventory
                    if (inv.hash == pfrom->hashContinue) {
                        // Bypass PushInventory, this must send even if redundant,
                        // and we want it right after the last block so they don't
                        // wait for other stuff first.
                        vector<CInv> vInv;
                        vInv.push_back(CInv(MSG_BLOCK, chainActive.Tip()->GetBlockHash()));
                        pfrom->PushMessage("inv", vInv);
                        pfrom->hashContinue = 0;
                    }
                }
            } else if (inv.IsKnownType()) {
                // Send stream from relay memory
                bool pushed = false;
                {
                    LOCK(cs_mapRelay);
                    map<CInv, CDataStream>::iterator mi = mapRelay.find(inv);
                    if (mi != mapRelay.end()) {
                        pfrom->PushMessage(inv.GetCommand(), (*mi).second);
                        pushed = true;
                    }
                }
                if (!pushed && inv.type == MSG_TX) {
                    CTransaction tx;
                    if (mempool.lookup(inv.hash, tx)) {
                        CDataStream ss(SER_NETWORK, PROTOCOL_VERSION);
                        ss.reserve(1000);
                        ss << tx;
                        pfrom->PushMessage("tx", ss);
                        pushed = true;
                    }
                }
                if (!pushed)
                    vNotFound.push_back(inv);
            }

            // Track requests for our stuff.
            g_signals.Inventory(inv.hash);

            if (inv.type == MSG_BLOCK || inv.type == MSG_FILTERED_BLOCK)
                break;
        }
    }

    pfrom->vRecvGetData.erase(pfrom->vRecvGetData.begin(), it);

    if (!vNotFound.empty()) {
        // Let the peer know that we didn't find what it asked for, so it doesn't
        // have to wait around forever. Currently only SPV clients actually care
        // about this message: it's needed when they are recursively walking the
        // dependencies of relevant unconfirmed transactions. SPV clients want to
        // do that because they want to know about (and store and rebroadcast and
        // risk analyze) the dependencies of transactions relevant to them, without
        // having to download the entire memory pool.
        pfrom->PushMessage("notfound", vNotFound);
    }
}

bool static ProcessMessage(CNode* pfrom, string strCommand, CDataStream& vRecv, int64_t nTimeReceived)
{
    RandAddSeedPerfmon();
    LogPrint("net", "received: %s (%u bytes) peer=%d\n", strCommand, vRecv.size(), pfrom->id);
    CNetRecorder::SaveBandwidth(pfrom->addrName, (int64_t)time(NULL), vRecv.size());

    if (mapArgs.count("-dropmessagestest") && GetRand(atoi(mapArgs["-dropmessagestest"])) == 0) {
        LogPrintf("dropmessagestest DROPPING RECV MESSAGE\n");
        return true;
    }

    {
        LOCK(cs_main);
        State(pfrom->GetId())->nLastBlockProcess = GetTimeMicros();
    }



    if (strCommand == "version") {
        // Each connection can only send one version message
        if (pfrom->nVersion != 0) {
            pfrom->PushMessage("reject", strCommand, REJECT_DUPLICATE, string("Duplicate version message"));
            Misbehaving(pfrom->GetId(), 1);
            return false;
        }

        int64_t nTime;
        CAddress addrMe;
        CAddress addrFrom;
        uint64_t nNonce = 1;
        vRecv >> pfrom->nVersion >> pfrom->nServices >> nTime >> addrMe;
        if (pfrom->nVersion < MIN_PEER_PROTO_VERSION) {
            // disconnect from peers older than this proto version
            LogPrintf("peer=%d using obsolete version %i; disconnecting\n", pfrom->id, pfrom->nVersion);
            pfrom->PushMessage("reject", strCommand, REJECT_OBSOLETE,
                               strprintf("Version must be %d or greater", MIN_PEER_PROTO_VERSION));
            pfrom->fDisconnect = true;
            return false;
        }

        if (pfrom->nVersion == 10300)
            pfrom->nVersion = 300;
        if (!vRecv.empty())
            vRecv >> addrFrom >> nNonce;
        if (!vRecv.empty()) {
            vRecv >> LIMITED_STRING(pfrom->strSubVer, 256);
            pfrom->cleanSubVer = SanitizeString(pfrom->strSubVer);
        }
        if (!vRecv.empty())
            vRecv >> pfrom->nStartingHeight;
        if (!vRecv.empty())
            vRecv >> pfrom->fRelayTxes; // set to true after we get the first filter* message
        else
            pfrom->fRelayTxes = true;

        if (pfrom->fInbound && addrMe.IsRoutable()) {
            pfrom->addrLocal = addrMe;
            SeenLocal(addrMe);
        }

        // Disconnect if we connected to ourself
        if (nNonce == nLocalHostNonce && nNonce > 1) {
            LogPrintf("connected to self at %s, disconnecting\n", pfrom->addr.ToString());
            pfrom->fDisconnect = true;
            return true;
        }

        // Be shy and don't send version until we hear
        if (pfrom->fInbound)
            pfrom->PushVersion();

        pfrom->fClient = !(pfrom->nServices & NODE_NETWORK);


        // Change version
        pfrom->PushMessage("verack");
        pfrom->ssSend.SetVersion(std::min(pfrom->nVersion, PROTOCOL_VERSION));

        if (!pfrom->fInbound) {
            // Advertise our address
            if (fListen && !IsInitialBlockDownload()) {
                CAddress addr = GetLocalAddress(&pfrom->addr);
                if (addr.IsRoutable())
                    pfrom->PushAddress(addr);
            }

            // Get recent addresses
            if (pfrom->fOneShot || pfrom->nVersion >= CADDR_TIME_VERSION || addrman.size() < 1000) {
                pfrom->PushMessage("getaddr");
                pfrom->fGetAddr = true;
            }
            addrman.Good(pfrom->addr);
        } else {
            if (((CNetAddr)pfrom->addr) == (CNetAddr)addrFrom) {
                addrman.Add(addrFrom, addrFrom);
                addrman.Good(addrFrom);
            }
        }

        // Relay alerts
        {
            LOCK(cs_mapAlerts);
            BOOST_FOREACH(PAIRTYPE(const uint256, CAlert)& item, mapAlerts)
                item.second.RelayTo(pfrom);
        }

        pfrom->fSuccessfullyConnected = true;

        string remoteAddr;
        if (fLogIPs)
            remoteAddr = ", peeraddr=" + pfrom->addr.ToString();

        LogPrintf("receive version message: %s: version %d, blocks=%d, us=%s, peer=%d%s\n",
                  pfrom->cleanSubVer, pfrom->nVersion,
                  pfrom->nStartingHeight, addrMe.ToString(), pfrom->id,
                  remoteAddr);

        AddTimeData(pfrom->addr, nTime);
    } else if (pfrom->nVersion == 0) {
        // Must have a version message before anything else
        Misbehaving(pfrom->GetId(), 1);
        return false;
    } else if (strCommand == "verack") {
        pfrom->SetRecvVersion(std::min(pfrom->nVersion, PROTOCOL_VERSION));
    } else if (strCommand == "addr") {
        vector<CAddress> vAddr;
        vRecv >> vAddr;

        // Don't want addr from older versions unless seeding
        if (pfrom->nVersion < CADDR_TIME_VERSION && addrman.size() > 1000)
            return true;
        if (vAddr.size() > 1000) {
            Misbehaving(pfrom->GetId(), 20);
            return error("message addr size() = %u", vAddr.size());
        }

        // Store the new addresses
        vector<CAddress> vAddrOk;
        int64_t nNow = GetAdjustedTime();
        int64_t nSince = nNow - 10 * 60;
        BOOST_FOREACH(CAddress& addr, vAddr) {
            boost::this_thread::interruption_point();

            if (addr.nTime <= 100000000 || addr.nTime > nNow + 10 * 60)
                addr.nTime = nNow - 5 * 24 * 60 * 60;
            pfrom->AddAddressKnown(addr);
            bool fReachable = IsReachable(addr);
            if (addr.nTime > nSince && !pfrom->fGetAddr && vAddr.size() <= 10 && addr.IsRoutable()) {
                // Relay to a limited number of other nodes
                {
                    LOCK(cs_vNodes);
                    // Use deterministic randomness to send to the same nodes for 24 hours
                    // at a time so the setAddrKnowns of the chosen nodes prevent repeats
                    static uint256 hashSalt;
                    if (hashSalt == 0)
                        hashSalt = GetRandHash();
                    uint64_t hashAddr = addr.GetHash();
                    uint256 hashRand = hashSalt ^ (hashAddr<<32) ^ ((GetTime()+hashAddr)/(24*60*60));
                    hashRand = Hash(BEGIN(hashRand), END(hashRand));
                    multimap<uint256, CNode*> mapMix;
                    BOOST_FOREACH(CNode* pnode, vNodes) {
                        if (pnode->nVersion < CADDR_TIME_VERSION)
                            continue;
                        unsigned int nPointer;
                        memcpy(&nPointer, &pnode, sizeof(nPointer));
                        uint256 hashKey = hashRand ^ nPointer;
                        hashKey = Hash(BEGIN(hashKey), END(hashKey));
                        mapMix.insert(make_pair(hashKey, pnode));
                    }
                    int nRelayNodes = fReachable ? 2 : 1; // limited relaying of addresses outside our network(s)
                    for (multimap<uint256, CNode*>::iterator mi = mapMix.begin(); mi != mapMix.end() && nRelayNodes-- > 0; ++mi)
                        ((*mi).second)->PushAddress(addr);
                }
            }
            // Do not store addresses outside our network
            if (fReachable)
                vAddrOk.push_back(addr);
        }
        addrman.Add(vAddrOk, pfrom->addr, 2 * 60 * 60);
        if (vAddr.size() < 1000)
            pfrom->fGetAddr = false;
        if (pfrom->fOneShot)
            pfrom->fDisconnect = true;
    } else if (strCommand == "inv") {
        vector<CInv> vInv;
        vRecv >> vInv;
        if (vInv.size() > MAX_INV_SZ) {
            Misbehaving(pfrom->GetId(), 20);
            return error("message inv size() = %u", vInv.size());
        }

        LOCK(cs_main);

        for (unsigned int nInv = 0; nInv < vInv.size(); nInv++) {
            const CInv &inv = vInv[nInv];

            boost::this_thread::interruption_point();
            pfrom->AddInventoryKnown(inv);

            bool fAlreadyHave = AlreadyHave(inv);
            LogPrint("net", "got inv: %s  %s peer=%d\n", inv.ToString(), fAlreadyHave ? "have" : "new", pfrom->id);

            if (!fAlreadyHave) {
                if (!fImporting && !fReindex) {
                    if (inv.type == MSG_BLOCK)
                        AddBlockToQueue(pfrom->GetId(), inv.hash);
                    else
                        pfrom->AskFor(inv);
                }
            } else if (inv.type == MSG_BLOCK && mapOrphanBlocks.count(inv.hash)) {
                PushGetBlocks(pfrom, chainActive.Tip(), GetOrphanRoot(inv.hash));
            }

            if (inv.type == MSG_BLOCK)
                UpdateBlockAvailability(pfrom->GetId(), inv.hash);

            // Track requests for our stuff
            g_signals.Inventory(inv.hash);
        }
    } else if (strCommand == "getdata") {
        vector<CInv> vInv;
        vRecv >> vInv;
        if (vInv.size() > MAX_INV_SZ)
        {
            Misbehaving(pfrom->GetId(), 20);
            return error("message getdata size() = %u", vInv.size());
        }

        if (fDebug || (vInv.size() != 1))
            LogPrint("net", "received getdata (%u invsz) peer=%d\n", vInv.size(), pfrom->id);

        if ((fDebug && vInv.size() > 0) || (vInv.size() == 1))
            LogPrint("net", "received getdata for: %s peer=%d\n", vInv[0].ToString(), pfrom->id);

        pfrom->vRecvGetData.insert(pfrom->vRecvGetData.end(), vInv.begin(), vInv.end());
        ProcessGetData(pfrom);
    } else if (strCommand == "getblocks") {
        CBlockLocator locator;
        uint256 hashStop;
        vRecv >> locator >> hashStop;

        LOCK(cs_main);

        // Find the last block the caller has in the main chain
        CBlockIndex* pindex = chainActive.FindFork(locator);

        // Send the rest of the chain
        if (pindex)
            pindex = chainActive.Next(pindex);
        int nLimit = 500;
        LogPrint("net", "getblocks %d to %s limit %d from peer=%d\n", (pindex ? pindex->nHeight : -1), hashStop==uint256(0) ? "end" : hashStop.ToString(), nLimit, pfrom->id);
        for (; pindex; pindex = chainActive.Next(pindex)) {
            if (pindex->GetBlockHash() == hashStop) {
                LogPrint("net", "  getblocks stopping at %d %s\n", pindex->nHeight, pindex->GetBlockHash().ToString());
                break;
            }
            pfrom->PushInventory(CInv(MSG_BLOCK, pindex->GetBlockHash()));
            if (--nLimit <= 0) {
                // When this block is requested, we'll send an inv that'll make them
                // getblocks the next batch of inventory.
                LogPrint("net", "  getblocks stopping at limit %d %s\n", pindex->nHeight, pindex->GetBlockHash().ToString());
                pfrom->hashContinue = pindex->GetBlockHash();
                break;
            }
        }
    } else if (strCommand == "getheaders") {
        CBlockLocator locator;
        uint256 hashStop;
        vRecv >> locator >> hashStop;

        LOCK(cs_main);

        CBlockIndex* pindex = NULL;
        if (locator.IsNull()) {
            // If locator is null, return the hashStop block
            map<uint256, CBlockIndex*>::iterator mi = mapBlockIndex.find(hashStop);
            if (mi == mapBlockIndex.end())
                return true;
            pindex = (*mi).second;
        } else {
            // Find the last block the caller has in the main chain
            pindex = chainActive.FindFork(locator);
            if (pindex)
                pindex = chainActive.Next(pindex);
        }

        // we must use CBlocks, as CBlockHeaders won't include the 0x00 nTx count at the end
        vector<CBlock> vHeaders;
        int nLimit = 2000;
        LogPrint("net", "getheaders %d to %s\n", (pindex ? pindex->nHeight : -1), hashStop.ToString());
        for (; pindex; pindex = chainActive.Next(pindex)) {
            vHeaders.push_back(pindex->GetBlockHeader());
            if (--nLimit <= 0 || pindex->GetBlockHash() == hashStop)
                break;
        }
        pfrom->PushMessage("headers", vHeaders);
    } else if (strCommand == "tx") {
        vector<uint256> vWorkQueue;
        vector<uint256> vEraseQueue;
        CTransaction tx;
        vRecv >> tx;

        CInv inv(MSG_TX, tx.GetHash());
        pfrom->AddInventoryKnown(inv);

        LOCK(cs_main);

        bool fMissingInputs = false;
        CValidationState state;
        if (AcceptToMemoryPool(mempool, state, tx, true, &fMissingInputs)) {
            mempool.check(pcoinsTip);
            RelayTransaction(tx);
            mapAlreadyAskedFor.erase(inv);
            vWorkQueue.push_back(inv.hash);
            vEraseQueue.push_back(inv.hash);


            LogPrint("mempool", "AcceptToMemoryPool: peer=%d %s : accepted %s (poolsz %u)\n",
                pfrom->id, pfrom->cleanSubVer,
                tx.GetHash().ToString(),
                mempool.mapTx.size());

            // Recursively process any orphan transactions that depended on this one
            for (unsigned int i = 0; i < vWorkQueue.size(); i++) {
                uint256 hashPrev = vWorkQueue[i];
                for (set<uint256>::iterator mi = mapOrphanTransactionsByPrev[hashPrev].begin();
                     mi != mapOrphanTransactionsByPrev[hashPrev].end();
                     ++mi) {
                    const uint256& orphanHash = *mi;
                    const CTransaction& orphanTx = mapOrphanTransactions[orphanHash];
                    bool fMissingInputs2 = false;
                    // Use a dummy CValidationState so someone can't setup nodes to counter-DoS based on orphan
                    // resolution (that is, feeding people an invalid transaction based on LegitTxX in order to get
                    // anyone relaying LegitTxX banned)
                    CValidationState stateDummy;

                    if (AcceptToMemoryPool(mempool, stateDummy, orphanTx, true, &fMissingInputs2)) {
                        LogPrint("mempool", "   accepted orphan tx %s\n", orphanHash.ToString());
                        RelayTransaction(orphanTx);
                        mapAlreadyAskedFor.erase(CInv(MSG_TX, orphanHash));
                        vWorkQueue.push_back(orphanHash);
                        vEraseQueue.push_back(orphanHash);
                    } else if (!fMissingInputs2) {
                        // invalid or too-little-fee orphan
                        vEraseQueue.push_back(orphanHash);
                        LogPrint("mempool", "   removed orphan tx %s\n", orphanHash.ToString());
                    }
                    mempool.check(pcoinsTip);
                }
            }

            BOOST_FOREACH(uint256 hash, vEraseQueue)
                EraseOrphanTx(hash);
        } else if (fMissingInputs) {
            AddOrphanTx(tx);

            // DoS prevention: do not allow mapOrphanTransactions to grow unbounded
            unsigned int nEvicted = LimitOrphanTxSize(MAX_ORPHAN_TRANSACTIONS);
            if (nEvicted > 0)
                LogPrint("mempool", "mapOrphan overflow, removed %u tx\n", nEvicted);
        } else if (pfrom->fWhitelisted) {
            // Always relay transactions received from whitelisted peers, even
            // if they are already in the mempool (allowing the node to function
            // as a gateway for nodes hidden behind it).
            RelayTransaction(tx);
        }
        int nDoS = 0;
        if (state.IsInvalid(nDoS)) {
            LogPrint("mempool", "%s from peer=%d %s was not accepted into the memory pool: %s\n", tx.GetHash().ToString(),
                pfrom->id, pfrom->cleanSubVer,
                state.GetRejectReason());
            pfrom->PushMessage("reject", strCommand, state.GetRejectCode(),
                               state.GetRejectReason(), inv.hash);
            if (nDoS > 0)
                Misbehaving(pfrom->GetId(), nDoS);
        }
    } else if (strCommand == "block" && !fImporting && !fReindex) { // Ignore blocks received while importing
        CBlock block;
        vRecv >> block;

        LogPrint("net", "received block %s peer=%d\n", block.GetHash().ToString(), pfrom->id);

        CInv inv(MSG_BLOCK, block.GetHash());
        pfrom->AddInventoryKnown(inv);

        {
            LOCK(cs_main);
            // Remember who we got this block from.
            mapBlockSource[inv.hash] = pfrom->GetId();
            MarkBlockAsReceived(inv.hash, pfrom->GetId());
        }

        CValidationState state;
        ProcessBlock(state, pfrom, &block);
        int nDoS;
        if (state.IsInvalid(nDoS)) {
            pfrom->PushMessage("reject", strCommand, state.GetRejectCode(),
                               state.GetRejectReason(), inv.hash);
            if (nDoS > 0) {
                LOCK(cs_main);
                Misbehaving(pfrom->GetId(), nDoS);
            }
        }

    } else if (strCommand == "getaddr") {
        pfrom->vAddrToSend.clear();
        vector<CAddress> vAddr = addrman.GetAddr();
        BOOST_FOREACH(const CAddress &addr, vAddr)
            pfrom->PushAddress(addr);
    } else if (strCommand == "mempool") {
        LOCK2(cs_main, pfrom->cs_filter);

        vector<uint256> vtxid;
        mempool.queryHashes(vtxid);
        vector<CInv> vInv;
        BOOST_FOREACH(uint256& hash, vtxid) {
            CInv inv(MSG_TX, hash);
            CTransaction tx;
            bool fInMemPool = mempool.lookup(hash, tx);
            if (!fInMemPool) continue; // another thread removed since queryHashes, maybe...
            if ((pfrom->pfilter && pfrom->pfilter->IsRelevantAndUpdate(tx)) ||
               (!pfrom->pfilter))
                vInv.push_back(inv);
            if (vInv.size() == MAX_INV_SZ) {
                pfrom->PushMessage("inv", vInv);
                vInv.clear();
            }
        }
        if (vInv.size() > 0)
            pfrom->PushMessage("inv", vInv);
    } else if (strCommand == "ping") {
        if (pfrom->nVersion > BIP0031_VERSION) {
            uint64_t nonce = 0;
            vRecv >> nonce;
            // Echo the message back with the nonce. This allows for two useful features:
            //
            // 1) A remote node can quickly check if the connection is operational
            // 2) Remote nodes can measure the latency of the network thread. If this node
            //    is overloaded it won't respond to pings quickly and the remote node can
            //    avoid sending us more work, like chain download requests.
            //
            // The nonce stops the remote getting confused between different pings: without
            // it, if the remote node sends a ping once per second and this node takes 5
            // seconds to respond to each, the 5th ping the remote sends would appear to
            // return very quickly.
            pfrom->PushMessage("pong", nonce);
        }
    } else if (strCommand == "pong") {
        int64_t pingUsecEnd = nTimeReceived;
        uint64_t nonce = 0;
        size_t nAvail = vRecv.in_avail();
        bool bPingFinished = false;
        string sProblem;

        if (nAvail >= sizeof(nonce)) {
            vRecv >> nonce;

            // Only process pong message if there is an outstanding ping (old ping without nonce should never pong)
            if (pfrom->nPingNonceSent != 0) {
                if (nonce == pfrom->nPingNonceSent) {
                    // Matching pong received, this ping is no longer outstanding
                    bPingFinished = true;
                    int64_t pingUsecTime = pingUsecEnd - pfrom->nPingUsecStart;
                    if (pingUsecTime > 0) {
                        // Successful ping time measurement, replace previous
                        pfrom->nPingUsecTime = pingUsecTime;

                        // Write rtt info
                        int64_t curTime = (int64_t) time(NULL);
                        int64_t ping = pingUsecTime / 1000;
                        CNetRecorder::SaveRTT(pfrom->addrName, curTime, ping);
                    } else {
                        // This should never happen
                        sProblem = "Timing mishap";
                    }
                } else {
                    // Nonce mismatches are normal when pings are overlapping
                    sProblem = "Nonce mismatch";
                    if (nonce == 0) {
                        // This is most likely a bug in another implementation somewhere, cancel this ping
                        bPingFinished = true;
                        sProblem = "Nonce zero";
                    }
                }
            } else
                sProblem = "Unsolicited pong without ping";
        } else {
            // This is most likely a bug in another implementation somewhere, cancel this ping
            bPingFinished = true;
            sProblem = "Short payload";
        }

        if (!(sProblem.empty())) {
            LogPrint("net", "pong peer=%d %s: %s, %x expected, %x received, %u bytes\n",
                pfrom->id,
                pfrom->cleanSubVer,
                sProblem,
                pfrom->nPingNonceSent,
                nonce,
                nAvail);
        }
        if (bPingFinished)
            pfrom->nPingNonceSent = 0;
    } else if (strCommand == "alert") {
        CAlert alert;
        vRecv >> alert;

        uint256 alertHash = alert.GetHash();
        if (pfrom->setKnown.count(alertHash) == 0) {
            if (alert.ProcessAlert()) {
                // Relay
                pfrom->setKnown.insert(alertHash);
                {
                    LOCK(cs_vNodes);
                    BOOST_FOREACH(CNode* pnode, vNodes)
                        alert.RelayTo(pnode);
                }
            } else {
                // Small DoS penalty so peers that send us lots of
                // duplicate/expired/invalid-signature/whatever alerts
                // eventually get banned.
                // This isn't a Misbehaving(100) (immediate ban) because the
                // peer might be an older or different implementation with
                // a different signature key, etc.
                Misbehaving(pfrom->GetId(), 10);
            }
        }
    } else if (strCommand == "filterload") {
        CBloomFilter filter;
        vRecv >> filter;

        if (!filter.IsWithinSizeConstraints())
            // There is no excuse for sending a too-large filter
            Misbehaving(pfrom->GetId(), 100);
        else {
            LOCK(pfrom->cs_filter);
            delete pfrom->pfilter;
            pfrom->pfilter = new CBloomFilter(filter);
            pfrom->pfilter->UpdateEmptyFull();
        }
        pfrom->fRelayTxes = true;
    } else if (strCommand == "filteradd") {
        vector<unsigned char> vData;
        vRecv >> vData;

        // Nodes must NEVER send a data item > 520 bytes (the max size for a script data object,
        // and thus, the maximum size any matched object can have) in a filteradd message
        if (vData.size() > MAX_SCRIPT_ELEMENT_SIZE) {
            Misbehaving(pfrom->GetId(), 100);
        } else {
            LOCK(pfrom->cs_filter);
            if (pfrom->pfilter)
                pfrom->pfilter->insert(vData);
            else
                Misbehaving(pfrom->GetId(), 100);
        }
    } else if (strCommand == "filterclear") {
        LOCK(pfrom->cs_filter);
        delete pfrom->pfilter;
        pfrom->pfilter = new CBloomFilter();
        pfrom->fRelayTxes = true;
    } else if (strCommand == "reject") {
        if (fDebug) {
            string strMsg; unsigned char ccode; string strReason;
            vRecv >> LIMITED_STRING(strMsg, CMessageHeader::COMMAND_SIZE) >> ccode >> LIMITED_STRING(strReason, 111);

            std::ostringstream ss;
            ss << strMsg << " code " << itostr(ccode) << ": " << strReason;

            if (strMsg == "block" || strMsg == "tx") {
                uint256 hash;
                vRecv >> hash;
                ss << ": hash " << hash.ToString();
            }
            LogPrint("net", "Reject %s\n", SanitizeString(ss.str()));
        }
    } else {
        // Ignore unknown commands for extensibility
        LogPrint("net", "Unknown command \"%s\" from peer=%d\n", SanitizeString(strCommand), pfrom->id);
    }


    // Update the last seen time for this node's address
    if (pfrom->fNetworkNode)
        if (strCommand == "version" || strCommand == "addr" || strCommand == "inv" || strCommand == "getdata" || strCommand == "ping")
            AddressCurrentlyConnected(pfrom->addr);


    return true;
}

// requires LOCK(cs_vRecvMsg)
bool ProcessMessages(CNode* pfrom)
{
    //if (fDebug)
    //    LogPrintf("ProcessMessages(%u messages)\n", pfrom->vRecvMsg.size());

    //
    // Message format
    //  (4) message start
    //  (12) command
    //  (4) size
    //  (4) checksum
    //  (x) data
    //
    bool fOk = true;

    if (!pfrom->vRecvGetData.empty())
        ProcessGetData(pfrom);

    // this maintains the order of responses
    if (!pfrom->vRecvGetData.empty()) return fOk;

    std::deque<CNetMessage>::iterator it = pfrom->vRecvMsg.begin();
    while (!pfrom->fDisconnect && it != pfrom->vRecvMsg.end()) {
        // Don't bother if send buffer is too full to respond anyway
        if (pfrom->nSendSize >= SendBufferSize())
            break;

        // get next message
        CNetMessage& msg = *it;

        //if (fDebug)
        //    LogPrintf("ProcessMessages(message %u msgsz, %u bytes, complete:%s)\n",
        //            msg.hdr.nMessageSize, msg.vRecv.size(),
        //            msg.complete() ? "Y" : "N");

        // end, if an incomplete message is found
        if (!msg.complete())
            break;

        // at this point, any failure means we can delete the current message
        it++;

        // Scan for message start
        if (memcmp(msg.hdr.pchMessageStart, Params().MessageStart(), MESSAGE_START_SIZE) != 0) {
            LogPrintf("\n\n%s: INVALID MESSAGESTART\n\n", __func__);
            fOk = false;
            break;
        }

        // Read header
        CMessageHeader& hdr = msg.hdr;
        if (!hdr.IsValid()) {
            LogPrintf("\n\n%s: ERRORS IN HEADER %s\n\n\n", __func__, hdr.GetCommand());
            continue;
        }
        string strCommand = hdr.GetCommand();

        // Message size
        unsigned int nMessageSize = hdr.nMessageSize;

        // Checksum
        CDataStream& vRecv = msg.vRecv;
        uint256 hash = Hash(vRecv.begin(), vRecv.begin() + nMessageSize);
        unsigned int nChecksum = 0;
        memcpy(&nChecksum, &hash, sizeof(nChecksum));
        if (nChecksum != hdr.nChecksum) {
            LogPrintf("%s(%s, %u bytes) : CHECKSUM ERROR nChecksum=%08x hdr.nChecksum=%08x\n",
               __func__, strCommand, nMessageSize, nChecksum, hdr.nChecksum);
            continue;
        }

        // Process message
        bool fRet = false;
        try {
            fRet = ProcessMessage(pfrom, strCommand, vRecv, msg.nTime);
            boost::this_thread::interruption_point();
        } catch (std::ios_base::failure& e) {
            pfrom->PushMessage("reject", strCommand, REJECT_MALFORMED, string("error parsing message"));
            if (strstr(e.what(), "end of data")) {
                // Allow exceptions from under-length message on vRecv
                LogPrintf("%s(%s, %u bytes) : Exception '%s' caught, normally caused by a message being shorter than its stated length\n", __func__, strCommand, nMessageSize, e.what());
            } else if (strstr(e.what(), "size too large")) {
                // Allow exceptions from over-long size
                LogPrintf("%s(%s, %u bytes) : Exception '%s' caught\n", __func__, strCommand, nMessageSize, e.what());
            } else {
                PrintExceptionContinue(&e, __func__);
            }
        } catch (boost::thread_interrupted) {
            throw;
        } catch (exception& e) {
            PrintExceptionContinue(&e, __func__);
        } catch (...) {
            PrintExceptionContinue(NULL, __func__);
        }

        if (!fRet)
            LogPrintf("%s(%s, %u bytes) FAILED peer=%d\n", __func__, strCommand, nMessageSize, pfrom->id);

        break;
    }

    // In case the connection got shut down, its receive buffer was wiped
    if (!pfrom->fDisconnect)
        pfrom->vRecvMsg.erase(pfrom->vRecvMsg.begin(), it);

    return fOk;
}


bool SendMessages(CNode* pto, bool fSendTrickle)
{
    {
        // Don't send anything until we get their version message
        if (pto->nVersion == 0)
            return true;

        //
        // Message: ping
        //
        bool pingSend = false;
        if (pto->fPingQueued)
            // RPC ping request by user
            pingSend = true;

        if (pto->nPingNonceSent == 0 && pto->nPingUsecStart + PING_INTERVAL * 1000000 < GetTimeMicros())
            // Ping automatically sent as a latency probe & keepalive.
            pingSend = true;

        if (pingSend) {
            uint64_t nonce = 0;
            while (nonce == 0) {
                GetRandBytes((unsigned char*)&nonce, sizeof(nonce));
            }
            pto->fPingQueued = false;
            pto->nPingUsecStart = GetTimeMicros();
            if (pto->nVersion > BIP0031_VERSION) {
                pto->nPingNonceSent = nonce;
                pto->PushMessage("ping", nonce);
            } else {
                // Peer is too old to support ping command with nonce, pong will never arrive.
                pto->nPingNonceSent = 0;
                pto->PushMessage("ping");
            }
        }

        TRY_LOCK(cs_main, lockMain); // Acquire cs_main for IsInitialBlockDownload() and CNodeState()
        if (!lockMain)
            return true;

        // Address refresh broadcast
        static int64_t nLastRebroadcast;
        if (!IsInitialBlockDownload() && (GetTime() - nLastRebroadcast > 24 * 60 * 60)) {
            {
                LOCK(cs_vNodes);
                BOOST_FOREACH(CNode* pnode, vNodes) {
                    // Periodically clear setAddrKnown to allow refresh broadcasts
                    if (nLastRebroadcast)
                        pnode->setAddrKnown.clear();

                    // Rebroadcast our address
                    if (fListen) {
                        CAddress addr = GetLocalAddress(&pnode->addr);
                        if (addr.IsRoutable())
                            pnode->PushAddress(addr);
                    }
                }
            }
            nLastRebroadcast = GetTime();
        }

        //
        // Message: addr
        //
        if (fSendTrickle) {
            vector<CAddress> vAddr;
            vAddr.reserve(pto->vAddrToSend.size());
            BOOST_FOREACH(const CAddress& addr, pto->vAddrToSend) {
                // returns true if wasn't already contained in the set
                if (pto->setAddrKnown.insert(addr).second) {
                    vAddr.push_back(addr);
                    // receiver rejects addr messages larger than 1000
                    if (vAddr.size() >= 1000) {
                        pto->PushMessage("addr", vAddr);
                        vAddr.clear();
                    }
                }
            }
            pto->vAddrToSend.clear();
            if (!vAddr.empty())
                pto->PushMessage("addr", vAddr);
        }

        CNodeState &state = *State(pto->GetId());
        if (state.fShouldBan) {
            if (pto->fWhitelisted)
                LogPrintf("Warning: not punishing whitelisted peer %s!\n", pto->addr.ToString());
            else {
                pto->fDisconnect = true;
                if (pto->addr.IsLocal())
                    LogPrintf("Warning: not banning local peer %s!\n", pto->addr.ToString());
                else
                    CNode::Ban(pto->addr);
            }
            state.fShouldBan = false;
        }

        BOOST_FOREACH(const CBlockReject& reject, state.rejects)
            pto->PushMessage("reject", (string)"block", reject.chRejectCode, reject.strRejectReason, reject.hashBlock);
        state.rejects.clear();

        // Start block sync
        if (pto->fStartSync && !fImporting && !fReindex) {
            PushGetBlocks(pto, chainActive.Tip(), uint256(0));
            if (chainActive.Tip()->nHeight >= pto->nStartingHeight) {
                pto->PushMessage("mempool");
                pto->fStartSync = false;
            }
        }
        // Resend wallet transactions that haven't gotten in a block yet
        // Except during reindex, importing and IBD, when old wallet
        // transactions become unconfirmed and spams other nodes.
        if (!fReindex && !fImporting && !IsInitialBlockDownload()) {
            g_signals.Broadcast();
        }

        //
        // Message: inventory
        //
        vector<CInv> vInv;
        vector<CInv> vInvWait;
        {
            LOCK(pto->cs_inventory);
            vInv.reserve(pto->vInventoryToSend.size());
            vInvWait.reserve(pto->vInventoryToSend.size());
            BOOST_FOREACH(const CInv& inv, pto->vInventoryToSend) {
                if (pto->setInventoryKnown.count(inv))
                    continue;

                // trickle out tx inv to protect privacy
                if (inv.type == MSG_TX && !fSendTrickle) {
                    // 1/4 of tx invs blast to all immediately
                    static uint256 hashSalt;
                    if (hashSalt == 0)
                        hashSalt = GetRandHash();
                    uint256 hashRand = inv.hash ^ hashSalt;
                    hashRand = Hash(BEGIN(hashRand), END(hashRand));
                    bool fTrickleWait = ((hashRand & 3) != 0);

                    if (fTrickleWait) {
                        vInvWait.push_back(inv);
                        continue;
                    }
                }

                // returns true if wasn't already contained in the set
                if (pto->setInventoryKnown.insert(inv).second) {
                    vInv.push_back(inv);
                    if (vInv.size() >= 1000) {
                        pto->PushMessage("inv", vInv);
                        vInv.clear();
                    }
                }
            }
            pto->vInventoryToSend = vInvWait;
        }
        if (!vInv.empty())
            pto->PushMessage("inv", vInv);


        // Detect stalled peers. Require that blocks are in flight, we haven't
        // received a (requested) block in one minute, and that all blocks are
        // in flight for over two minutes, since we first had a chance to
        // process an incoming block.
        int64_t nNow = GetTimeMicros();
        if (!pto->fDisconnect && state.nBlocksInFlight &&
            state.nLastBlockReceive < state.nLastBlockProcess - BLOCK_DOWNLOAD_TIMEOUT*1000000 &&
            state.vBlocksInFlight.front().nTime < state.nLastBlockProcess - 2*BLOCK_DOWNLOAD_TIMEOUT*1000000) {
            LogPrintf("Peer %s is stalling block download, disconnecting\n", state.name.c_str());
            pto->fDisconnect = true;
        }

        // Update knowledge of peer's block availability.
        ProcessBlockAvailability(pto->GetId());

        //
        // Message: getdata (blocks)
        //
        vector<CInv> vGetData;
        while (!pto->fDisconnect && state.nBlocksToDownload && state.nBlocksInFlight < MAX_BLOCKS_IN_TRANSIT_PER_PEER) {
            uint256 hash = state.vBlocksToDownload.front();
            vGetData.push_back(CInv(MSG_BLOCK, hash));
            MarkBlockAsInFlight(pto->GetId(), hash);
            LogPrint("net", "Requesting block %s peer=%d\n", hash.ToString(), pto->id);
            if (vGetData.size() >= 1000) {
                pto->PushMessage("getdata", vGetData);
                vGetData.clear();
            }
        }

        //
        // Message: getdata (non-blocks)
        //
        while (!pto->fDisconnect && !pto->mapAskFor.empty() && (*pto->mapAskFor.begin()).first <= nNow) {
            const CInv& inv = (*pto->mapAskFor.begin()).second;
            if (!AlreadyHave(inv)) {
                if (fDebug)
                    LogPrint("net", "Requesting %s peer=%d\n", inv.ToString(), pto->id);
                vGetData.push_back(inv);
                if (vGetData.size() >= 1000) {
                    pto->PushMessage("getdata", vGetData);
                    vGetData.clear();
                }
            }
            pto->mapAskFor.erase(pto->mapAskFor.begin());
        }
        if (!vGetData.empty())
            pto->PushMessage("getdata", vGetData);
    }
    return true;
}


bool CBlockUndo::WriteToDisk(CDiskBlockPos &pos, const uint256 &hashBlock)
{
    // Open history file to append
    CAutoFile fileout = CAutoFile(OpenUndoFile(pos), SER_DISK, CLIENT_VERSION);
    if (!fileout)
        return error("CBlockUndo::%s : OpenUndoFile failed", __func__);

    // Write index header
    unsigned int nSize = fileout.GetSerializeSize(*this);
    fileout << FLATDATA(Params().MessageStart()) << nSize;

    // Write undo data
    long fileOutPos = ftell(fileout);
    if (fileOutPos < 0)
        return error("CBlockUndo::%s : ftell failed", __func__);
    pos.nPos = (unsigned int)fileOutPos;
    fileout << *this;

    // calculate & write checksum
    CHashWriter hasher(SER_GETHASH, PROTOCOL_VERSION);
    hasher << hashBlock;
    hasher << *this;
    fileout << hasher.GetHash();

    // Flush stdio buffers and commit to disk before returning
    fflush(fileout);
    if (!IsInitialBlockDownload())
        FileCommit(fileout);

    return true;
}

bool CBlockUndo::ReadFromDisk(const CDiskBlockPos &pos, const uint256 &hashBlock)
{
    // Open history file to read
    CAutoFile filein = CAutoFile(OpenUndoFile(pos, true), SER_DISK, CLIENT_VERSION);
    if (!filein)
        return error("CBlockUndo::%s : OpenBlockFile failed", __func__);

    // Read block
    uint256 hashChecksum;
    try {
        filein >> *this;
        filein >> hashChecksum;
    } catch (exception &e) {
        return error("%s : Deserialize or I/O error - %s", __func__, e.what());
    }

    // Verify checksum
    CHashWriter hasher(SER_GETHASH, PROTOCOL_VERSION);
    hasher << hashBlock;
    hasher << *this;
    if (hashChecksum != hasher.GetHash())
        return error("CBlockUndo::%s : Checksum mismatch", __func__);

    return true;
}

string CBlockFileInfo::ToString() const
{
     return strprintf("CBlockFileInfo(blocks=%u, size=%u, heights=%u...%u, time=%s...%s)",
             nBlocks,
             nSize,
             nHeightFirst,
             nHeightLast,
             DateTimeStrFormat("%Y-%m-%d", nTimeFirst).c_str(),
             DateTimeStrFormat("%Y-%m-%d", nTimeLast).c_str());
 }



class CMainCleanup
{
public:
    CMainCleanup() {}
    ~CMainCleanup()
    {
        // block headers
        map<uint256, CBlockIndex*>::iterator it1 = mapBlockIndex.begin();
        for (; it1 != mapBlockIndex.end(); it1++)
            delete (*it1).second;
        mapBlockIndex.clear();

        // orphan blocks
        map<uint256, COrphanBlock*>::iterator it2 = mapOrphanBlocks.begin();
        for (; it2 != mapOrphanBlocks.end(); it2++)
            delete (*it2).second;
        mapOrphanBlocks.clear();

        // orphan transactions
        mapOrphanTransactions.clear();
    }
} instance_of_cmaincleanup;

bool setChainHeight(int height, vector<CTransaction> &DiscardedTx)
{
    CValidationState state;
    LOCK(cs_main);
    while (chainActive.Tip() != chainActive[height]) {
        if (!DisconnectTip(state))
            return false;
    }
    for (unsigned int i = 0; i < DiscardedTx.size(); i++) {
        // ignore validation errors in resurrected transactions
        list<CTransaction> removed;
        CValidationState stateDummy;
        if (!DiscardedTx[i].IsCoinBase() || DiscardedTx[i].type == MINT)
            mempool.remove(DiscardedTx[i], removed, true);
    }
    mempool.check(pcoinsTip);

    //clear all fork on blockchain
    setBlockIndexValid.clear();
    setBlockIndexValid.insert(chainActive.Tip());
    return true;
}
